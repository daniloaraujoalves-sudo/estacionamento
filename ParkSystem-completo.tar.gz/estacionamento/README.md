# ParkSystem — Sistema de Estacionamento Completo

Atende todos os requisitos: vagas, placas, preços (hora/diária/mensal/anual), clientes, veículos e relatórios.

## Como rodar

```bash
cd backend
npm install          # só na primeira vez
node seed.js         # só na primeira vez (ou para resetar)
node server.js
```

Acesse: http://localhost:3000

## Requisitos atendidos

- Vagas: normal, preferencial, moto, carga
- Controle de placas (validação antiga + Mercosul)
- Preços: hora, diária, mensal, anual (editáveis)
- Cadastro de clientes (com plano avulso/mensal/anual)
- Cadastro de veículos (cor, marca, modelo, tamanho, tipo, ano)
- Relatórios: ocupação, faturamento, ranking, tempo médio, últimos 7 dias
- Entrada/saída com escolha de cobrança e sugestão automática

## Importante

- NÃO rode `node seed.js` depois de cadastrar dados reais (ele apaga tudo)
- Só use `node server.js` no dia a dia
