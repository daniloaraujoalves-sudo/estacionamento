const db = require('./database');

console.log('Inserindo dados iniciais...');

db.exec(`
  DELETE FROM estacionamentos;
  DELETE FROM veiculos;
  DELETE FROM clientes;
  DELETE FROM vagas;
  DELETE FROM precos;
`);

const insertCliente = db.prepare(`
  INSERT INTO clientes (nome, cpf_cnpj, telefone, email, tipo, plano)
  VALUES (?, ?, ?, ?, ?, ?)
`);
insertCliente.run('João Silva', '123.456.789-00', '(11) 99999-1111', 'joao@email.com', 'PF', 'avulso');
insertCliente.run('Maria Oliveira', '987.654.321-00', '(11) 98888-2222', 'maria@email.com', 'PF', 'mensal');
insertCliente.run('Empresa XYZ Ltda', '12.345.678/0001-99', '(11) 3333-4444', 'contato@xyz.com', 'PJ', 'anual');

const insertVeiculo = db.prepare(`
  INSERT INTO veiculos (placa, marca, modelo, cor, ano, tipo, tamanho, cliente_id)
  VALUES (?, ?, ?, ?, ?, ?, ?, ?)
`);
insertVeiculo.run('ABC1D23', 'Toyota', 'Corolla', 'Prata', 2022, 'carro', 'medio', 1);
insertVeiculo.run('XYZ9K87', 'Honda', 'CG 160', 'Vermelha', 2023, 'moto', 'pequeno', 2);
insertVeiculo.run('DEF4G56', 'Volkswagen', 'Gol', 'Branco', 2019, 'carro', 'pequeno', 1);
insertVeiculo.run('GHI7J89', 'Fiat', 'Strada', 'Prata', 2021, 'utilitario', 'medio', 3);

const insertVaga = db.prepare(`INSERT INTO vagas (numero, tipo, status, setor) VALUES (?, ?, ?, ?)`);
for (let i = 1; i <= 10; i++) insertVaga.run(`A${String(i).padStart(2,'0')}`, 'normal', 'livre', 'A');
for (let i = 1; i <= 4; i++) insertVaga.run(`B${String(i).padStart(2,'0')}`, 'preferencial', 'livre', 'B');
for (let i = 1; i <= 6; i++) insertVaga.run(`C${String(i).padStart(2,'0')}`, 'moto', 'livre', 'C');
for (let i = 1; i <= 2; i++) insertVaga.run(`D${String(i).padStart(2,'0')}`, 'carga', 'livre', 'D');

const insertPreco = db.prepare(`
  INSERT INTO precos (descricao, tipo_cobranca, valor, tipo_veiculo) VALUES (?, ?, ?, ?)
`);
insertPreco.run('Hora — Carro', 'hora', 8.00, 'carro');
insertPreco.run('Hora — Moto', 'hora', 4.00, 'moto');
insertPreco.run('Hora — Utilitário', 'hora', 12.00, 'utilitario');
insertPreco.run('Hora — Caminhão', 'hora', 20.00, 'caminhao');
insertPreco.run('Diária — Carro', 'diaria', 40.00, 'carro');
insertPreco.run('Diária — Moto', 'diaria', 20.00, 'moto');
insertPreco.run('Diária — Utilitário', 'diaria', 60.00, 'utilitario');
insertPreco.run('Mensal — Carro', 'mensal', 250.00, 'carro');
insertPreco.run('Mensal — Moto', 'mensal', 120.00, 'moto');
insertPreco.run('Anual — Carro', 'anual', 2500.00, 'carro');
insertPreco.run('Anual — Moto', 'anual', 1200.00, 'moto');

console.log('Dados iniciais inseridos com sucesso!');
console.log('Execute: node server.js');
