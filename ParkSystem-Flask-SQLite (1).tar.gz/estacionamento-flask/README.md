# ParkSystem — Flask + SQLite

Sistema de Estacionamento de Veículos  
**Backend:** Flask (Python) · **Banco:** SQLite · **Frontend:** HTML/CSS/JS

## Requisitos atendidos

- Vagas: normal, preferencial, moto, carga
- Controle de placas (formato antigo + Mercosul)
- Preços: hora, diária, mensal, anual
- Cadastro de clientes (com plano avulso/mensal/anual + cobrança do plano)
- Cadastro de veículos (cor, marca, modelo, tamanho, tipo, ano)
- Entrada / saída com cálculo automático
- Relatórios (ocupação, faturamento, ranking, tempo médio)

## Como rodar

```bash
cd estacionamento-flask

# Criar ambiente virtual (recomendado)
python3 -m venv venv
source venv/bin/activate   # Windows: venv\Scripts\activate

# Instalar dependências
pip install -r requirements.txt

# Iniciar
python app.py
```

Acesse: **http://localhost:5000**

## Estrutura

```
estacionamento-flask/
├── app.py              # Backend Flask + SQLite
├── requirements.txt
├── estacionamento.db   # Criado automaticamente na 1ª execução
├── templates/
│   └── index.html
└── static/
    ├── css/style.css
    └── js/app.js
```

## Observações

- Na primeira execução o banco é criado e preenchido com dados de exemplo
- Placas de teste: `ABC1D23`, `XYZ9K87`, `DEF4G56`
- Cliente mensalista/anual: paga o plano no cadastro e não paga na saída (enquanto válido)

