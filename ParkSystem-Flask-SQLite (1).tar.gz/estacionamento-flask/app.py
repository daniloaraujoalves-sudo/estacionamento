"""
ParkSystem — Sistema de Estacionamento
Flask + SQLite
"""
import sqlite3
import re
from datetime import datetime, timedelta
from math import ceil
from pathlib import Path
from flask import Flask, request, jsonify, send_from_directory

app = Flask(__name__, static_folder='static', template_folder='templates')
DB_PATH = Path(__file__).parent / 'estacionamento.db'


# ============================================
# BANCO DE DADOS
# ============================================
def get_db():
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    conn.execute('PRAGMA foreign_keys = ON')
    return conn


def init_db():
    conn = get_db()
    conn.executescript('''
        CREATE TABLE IF NOT EXISTS clientes (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            nome TEXT NOT NULL,
            cpf_cnpj TEXT UNIQUE,
            telefone TEXT,
            email TEXT,
            tipo TEXT DEFAULT 'PF' CHECK(tipo IN ('PF', 'PJ')),
            plano TEXT DEFAULT 'avulso' CHECK(plano IN ('avulso', 'mensal', 'anual')),
            plano_inicio DATE,
            plano_validade DATE,
            criado_em DATETIME DEFAULT CURRENT_TIMESTAMP
        );

        CREATE TABLE IF NOT EXISTS veiculos (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            placa TEXT NOT NULL UNIQUE,
            marca TEXT,
            modelo TEXT,
            cor TEXT,
            ano INTEGER,
            tipo TEXT DEFAULT 'carro' CHECK(tipo IN ('carro', 'moto', 'utilitario', 'caminhao')),
            tamanho TEXT DEFAULT 'medio' CHECK(tamanho IN ('pequeno', 'medio', 'grande')),
            cliente_id INTEGER,
            FOREIGN KEY (cliente_id) REFERENCES clientes(id) ON DELETE SET NULL
        );

        CREATE TABLE IF NOT EXISTS vagas (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            numero TEXT NOT NULL UNIQUE,
            tipo TEXT DEFAULT 'normal' CHECK(tipo IN ('normal', 'preferencial', 'moto', 'carga')),
            status TEXT DEFAULT 'livre' CHECK(status IN ('livre', 'ocupada', 'reservada', 'bloqueada')),
            setor TEXT DEFAULT 'A'
        );

        CREATE TABLE IF NOT EXISTS precos (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            descricao TEXT NOT NULL,
            tipo_cobranca TEXT NOT NULL CHECK(tipo_cobranca IN ('hora', 'diaria', 'mensal', 'anual')),
            valor REAL NOT NULL,
            tipo_veiculo TEXT DEFAULT 'todos',
            ativo INTEGER DEFAULT 1
        );

        CREATE TABLE IF NOT EXISTS estacionamentos (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            veiculo_id INTEGER NOT NULL,
            vaga_id INTEGER NOT NULL,
            data_hora_entrada DATETIME DEFAULT CURRENT_TIMESTAMP,
            data_hora_saida DATETIME,
            valor_calculado REAL DEFAULT 0,
            tipo_cobranca TEXT DEFAULT 'hora',
            status TEXT DEFAULT 'ativo' CHECK(status IN ('ativo', 'finalizado', 'cancelado')),
            observacao TEXT,
            FOREIGN KEY (veiculo_id) REFERENCES veiculos(id),
            FOREIGN KEY (vaga_id) REFERENCES vagas(id)
        );

        CREATE TABLE IF NOT EXISTS pagamentos_plano (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            cliente_id INTEGER NOT NULL,
            tipo_plano TEXT NOT NULL CHECK(tipo_plano IN ('mensal', 'anual')),
            valor REAL NOT NULL,
            data_pagamento DATETIME DEFAULT CURRENT_TIMESTAMP,
            validade_inicio DATE,
            validade_fim DATE,
            observacao TEXT,
            FOREIGN KEY (cliente_id) REFERENCES clientes(id) ON DELETE CASCADE
        );
    ''')
    conn.commit()
    conn.close()


def seed_db():
    """Insere dados iniciais (só se estiver vazio)."""
    conn = get_db()
    qtd = conn.execute('SELECT COUNT(*) FROM vagas').fetchone()[0]
    if qtd > 0:
        conn.close()
        return

    # Clientes
    conn.execute(
        "INSERT INTO clientes (nome, cpf_cnpj, telefone, email, tipo, plano) VALUES (?,?,?,?,?,?)",
        ('João Silva', '123.456.789-00', '(11) 99999-1111', 'joao@email.com', 'PF', 'avulso')
    )
    conn.execute(
        "INSERT INTO clientes (nome, cpf_cnpj, telefone, email, tipo, plano, plano_inicio, plano_validade) VALUES (?,?,?,?,?,?,?,?)",
        ('Maria Oliveira', '987.654.321-00', '(11) 98888-2222', 'maria@email.com', 'PF', 'mensal',
         datetime.now().strftime('%Y-%m-%d'),
         (datetime.now() + timedelta(days=30)).strftime('%Y-%m-%d'))
    )
    conn.execute(
        "INSERT INTO clientes (nome, cpf_cnpj, telefone, email, tipo, plano, plano_inicio, plano_validade) VALUES (?,?,?,?,?,?,?,?)",
        ('Empresa XYZ Ltda', '12.345.678/0001-99', '(11) 3333-4444', 'contato@xyz.com', 'PJ', 'anual',
         datetime.now().strftime('%Y-%m-%d'),
         (datetime.now() + timedelta(days=365)).strftime('%Y-%m-%d'))
    )

    # Veículos
    conn.execute(
        "INSERT INTO veiculos (placa, marca, modelo, cor, ano, tipo, tamanho, cliente_id) VALUES (?,?,?,?,?,?,?,?)",
        ('ABC1D23', 'Toyota', 'Corolla', 'Prata', 2022, 'carro', 'medio', 1)
    )
    conn.execute(
        "INSERT INTO veiculos (placa, marca, modelo, cor, ano, tipo, tamanho, cliente_id) VALUES (?,?,?,?,?,?,?,?)",
        ('XYZ9K87', 'Honda', 'CG 160', 'Vermelha', 2023, 'moto', 'pequeno', 2)
    )
    conn.execute(
        "INSERT INTO veiculos (placa, marca, modelo, cor, ano, tipo, tamanho, cliente_id) VALUES (?,?,?,?,?,?,?,?)",
        ('DEF4G56', 'Volkswagen', 'Gol', 'Branco', 2019, 'carro', 'pequeno', 1)
    )

    # Vagas
    for i in range(1, 11):
        conn.execute("INSERT INTO vagas (numero, tipo, status, setor) VALUES (?,?,?,?)",
                     (f'A{i:02d}', 'normal', 'livre', 'A'))
    for i in range(1, 5):
        conn.execute("INSERT INTO vagas (numero, tipo, status, setor) VALUES (?,?,?,?)",
                     (f'B{i:02d}', 'preferencial', 'livre', 'B'))
    for i in range(1, 7):
        conn.execute("INSERT INTO vagas (numero, tipo, status, setor) VALUES (?,?,?,?)",
                     (f'C{i:02d}', 'moto', 'livre', 'C'))
    for i in range(1, 3):
        conn.execute("INSERT INTO vagas (numero, tipo, status, setor) VALUES (?,?,?,?)",
                     (f'D{i:02d}', 'carga', 'livre', 'D'))

    # Preços
    precos = [
        ('Hora — Carro', 'hora', 8.00, 'carro'),
        ('Hora — Moto', 'hora', 4.00, 'moto'),
        ('Hora — Utilitário', 'hora', 12.00, 'utilitario'),
        ('Diária — Carro', 'diaria', 40.00, 'carro'),
        ('Diária — Moto', 'diaria', 20.00, 'moto'),
        ('Mensal — Carro', 'mensal', 250.00, 'carro'),
        ('Mensal — Moto', 'mensal', 120.00, 'moto'),
        ('Anual — Carro', 'anual', 2500.00, 'carro'),
        ('Anual — Moto', 'anual', 1200.00, 'moto'),
    ]
    for p in precos:
        conn.execute(
            "INSERT INTO precos (descricao, tipo_cobranca, valor, tipo_veiculo) VALUES (?,?,?,?)", p
        )

    # Pagamentos de plano dos exemplos
    hoje = datetime.now().strftime('%Y-%m-%d')
    fim_m = (datetime.now() + timedelta(days=30)).strftime('%Y-%m-%d')
    fim_a = (datetime.now() + timedelta(days=365)).strftime('%Y-%m-%d')
    conn.execute(
        "INSERT INTO pagamentos_plano (cliente_id, tipo_plano, valor, validade_inicio, validade_fim, observacao) VALUES (?,?,?,?,?,?)",
        (2, 'mensal', 250, hoje, fim_m, 'Seed — plano mensal')
    )
    conn.execute(
        "INSERT INTO pagamentos_plano (cliente_id, tipo_plano, valor, validade_inicio, validade_fim, observacao) VALUES (?,?,?,?,?,?)",
        (3, 'anual', 2500, hoje, fim_a, 'Seed — plano anual')
    )

    conn.commit()
    conn.close()
    print('Dados iniciais inseridos.')


# ============================================
# HELPERS
# ============================================
def ok(data, status=200):
    return jsonify({'success': True, 'data': data}), status


def fail(message, status=400):
    return jsonify({'success': False, 'error': message}), status


def rows_to_list(rows):
    return [dict(r) for r in rows]


def validar_placa(placa):
    if not placa:
        return False
    limpa = re.sub(r'[^A-Za-z0-9]', '', placa).upper()
    # Antigo: ABC1234 | Mercosul: ABC1D23
    return bool(re.match(r'^[A-Z]{3}[0-9]{4}$', limpa) or
                re.match(r'^[A-Z]{3}[0-9][A-Z0-9][0-9]{2}$', limpa))


def buscar_preco(conn, tipo_cobranca, tipo_veiculo='todos'):
    row = conn.execute('''
        SELECT valor FROM precos
        WHERE tipo_cobranca = ? AND ativo = 1
          AND (tipo_veiculo = ? OR tipo_veiculo = 'todos')
        ORDER BY CASE WHEN tipo_veiculo = ? THEN 0 ELSE 1 END
        LIMIT 1
    ''', (tipo_cobranca, tipo_veiculo, tipo_veiculo)).fetchone()
    return row['valor'] if row else None


def plano_ainda_valido(plano_validade):
    if not plano_validade:
        return True
    try:
        fim = datetime.strptime(str(plano_validade)[:10], '%Y-%m-%d')
        return fim.date() >= datetime.now().date()
    except Exception:
        return True


def calcular_valor(conn, entrada_iso, tipo_veiculo, tipo_cobranca='hora',
                   plano_cliente='avulso', plano_validade=None):
    entrada = datetime.fromisoformat(str(entrada_iso).replace('Z', ''))
    saida = datetime.now()
    diff_min = max(1, ceil((saida - entrada).total_seconds() / 60))
    diff_horas = round(diff_min / 60, 2)

    if plano_cliente in ('mensal', 'anual') and plano_ainda_valido(plano_validade):
        return {
            'minutos': diff_min,
            'horas': diff_horas,
            'tipo_cobranca': plano_cliente,
            'valor_unitario': 0,
            'valor': 0,
            'detalhe': f'Cliente com plano {plano_cliente} — sem cobrança na saída'
        }

    if tipo_cobranca == 'diaria':
        valor_diaria = buscar_preco(conn, 'diaria', tipo_veiculo) or 40.0
        return {
            'minutos': diff_min,
            'horas': diff_horas,
            'tipo_cobranca': 'diaria',
            'valor_unitario': valor_diaria,
            'valor': round(valor_diaria, 2),
            'detalhe': f'Diária (R$ {valor_diaria:.2f})'
        }

    valor_hora = buscar_preco(conn, 'hora', tipo_veiculo) or 8.0
    if diff_min <= 60:
        horas_cobradas = 1
    else:
        horas_cobradas = ceil(diff_min / 15) * 0.25
    valor = round(horas_cobradas * valor_hora, 2)
    return {
        'minutos': diff_min,
        'horas': diff_horas,
        'horas_cobradas': horas_cobradas,
        'tipo_cobranca': 'hora',
        'valor_unitario': valor_hora,
        'valor': valor,
        'detalhe': f'{horas_cobradas}h × R$ {valor_hora:.2f}'
    }


# ============================================
# FRONTEND
# ============================================
@app.route('/')
def index():
    return send_from_directory('templates', 'index.html')


# ============================================
# CLIENTES
# ============================================
@app.route('/api/clientes', methods=['GET'])
def listar_clientes():
    conn = get_db()
    rows = conn.execute('SELECT * FROM clientes ORDER BY nome').fetchall()
    conn.close()
    return ok(rows_to_list(rows))


@app.route('/api/clientes', methods=['POST'])
def criar_cliente():
    data = request.get_json() or {}
    nome = (data.get('nome') or '').strip()
    if len(nome) < 2:
        return fail('Nome é obrigatório (mín. 2 caracteres)')

    plano = data.get('plano') if data.get('plano') in ('mensal', 'anual') else 'avulso'
    plano_inicio = plano_validade = None
    valor_plano = 0

    conn = get_db()
    try:
        if plano in ('mensal', 'anual'):
            valor_plano = buscar_preco(conn, plano, 'carro') or buscar_preco(conn, plano, 'todos')
            if valor_plano is None:
                conn.close()
                return fail(f'Não há preço cadastrado para plano {plano}. Cadastre em Preços primeiro.')
            hoje = datetime.now()
            plano_inicio = hoje.strftime('%Y-%m-%d')
            delta = timedelta(days=30) if plano == 'mensal' else timedelta(days=365)
            plano_validade = (hoje + delta).strftime('%Y-%m-%d')

        cur = conn.execute('''
            INSERT INTO clientes (nome, cpf_cnpj, telefone, email, tipo, plano, plano_inicio, plano_validade)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?)
        ''', (
            nome,
            (data.get('cpf_cnpj') or '').strip() or None,
            (data.get('telefone') or '').strip() or None,
            (data.get('email') or '').strip() or None,
            'PJ' if data.get('tipo') == 'PJ' else 'PF',
            plano, plano_inicio, plano_validade
        ))
        cliente_id = cur.lastrowid

        if plano != 'avulso' and valor_plano > 0:
            conn.execute('''
                INSERT INTO pagamentos_plano (cliente_id, tipo_plano, valor, validade_inicio, validade_fim, observacao)
                VALUES (?, ?, ?, ?, ?, ?)
            ''', (cliente_id, plano, valor_plano, plano_inicio, plano_validade, f'Assinatura {plano} no cadastro'))

        conn.commit()
        cliente = dict(conn.execute('SELECT * FROM clientes WHERE id = ?', (cliente_id,)).fetchone())
        conn.close()

        if plano != 'avulso':
            cliente['pagamento_plano'] = {
                'tipo': plano,
                'valor': valor_plano,
                'validade': plano_validade,
                'mensagem': f'Plano {plano} cobrado: R$ {valor_plano:.2f} — válido até {plano_validade}'
            }
        else:
            cliente['pagamento_plano'] = None

        return ok(cliente, 201)
    except sqlite3.IntegrityError:
        conn.close()
        return fail('CPF/CNPJ já cadastrado')
    except Exception as e:
        conn.close()
        return fail(str(e), 500)


# ============================================
# VEÍCULOS
# ============================================
@app.route('/api/veiculos', methods=['GET'])
def listar_veiculos():
    conn = get_db()
    rows = conn.execute('''
        SELECT v.*, c.nome as cliente_nome, c.plano as cliente_plano
        FROM veiculos v
        LEFT JOIN clientes c ON v.cliente_id = c.id
        ORDER BY v.placa
    ''').fetchall()
    conn.close()
    return ok(rows_to_list(rows))


@app.route('/api/veiculos', methods=['POST'])
def criar_veiculo():
    data = request.get_json() or {}
    placa = (data.get('placa') or '').strip()
    if not placa:
        return fail('Placa é obrigatória')
    if not validar_placa(placa):
        return fail('Placa inválida. Use formato ABC1234 ou ABC1D23')

    placa_limpa = re.sub(r'[^A-Za-z0-9]', '', placa).upper()
    tipo = data.get('tipo') if data.get('tipo') in ('carro', 'moto', 'utilitario', 'caminhao') else 'carro'
    tamanho = data.get('tamanho') if data.get('tamanho') in ('pequeno', 'medio', 'grande') else 'medio'

    conn = get_db()
    try:
        cur = conn.execute('''
            INSERT INTO veiculos (placa, marca, modelo, cor, ano, tipo, tamanho, cliente_id)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?)
        ''', (
            placa_limpa,
            (data.get('marca') or '').strip() or None,
            (data.get('modelo') or '').strip() or None,
            (data.get('cor') or '').strip() or None,
            data.get('ano') or None,
            tipo, tamanho,
            data.get('cliente_id') or None
        ))
        conn.commit()
        veiculo = dict(conn.execute('SELECT * FROM veiculos WHERE id = ?', (cur.lastrowid,)).fetchone())
        conn.close()
        return ok(veiculo, 201)
    except sqlite3.IntegrityError:
        conn.close()
        return fail('Placa já cadastrada')
    except Exception as e:
        conn.close()
        return fail(str(e), 500)


# ============================================
# VAGAS
# ============================================
@app.route('/api/vagas', methods=['GET'])
def listar_vagas():
    conn = get_db()
    rows = conn.execute('SELECT * FROM vagas ORDER BY setor, numero').fetchall()
    conn.close()
    return ok(rows_to_list(rows))


@app.route('/api/vagas/livres', methods=['GET'])
def vagas_livres():
    tipo = request.args.get('tipo')
    conn = get_db()
    if tipo:
        rows = conn.execute(
            "SELECT * FROM vagas WHERE status = 'livre' AND tipo = ? ORDER BY setor, numero",
            (tipo,)
        ).fetchall()
    else:
        rows = conn.execute(
            "SELECT * FROM vagas WHERE status = 'livre' ORDER BY setor, numero"
        ).fetchall()
    conn.close()
    return ok(rows_to_list(rows))


@app.route('/api/vagas', methods=['POST'])
def criar_vaga():
    data = request.get_json() or {}
    numero = (data.get('numero') or '').strip().upper()
    if not numero:
        return fail('Número da vaga é obrigatório')
    tipo = data.get('tipo') if data.get('tipo') in ('preferencial', 'moto', 'carga', 'normal') else 'normal'
    setor = (data.get('setor') or 'A').strip().upper() or 'A'
    status = data.get('status') if data.get('status') in ('livre', 'bloqueada', 'reservada') else 'livre'

    conn = get_db()
    try:
        cur = conn.execute(
            "INSERT INTO vagas (numero, tipo, status, setor) VALUES (?, ?, ?, ?)",
            (numero, tipo, status, setor)
        )
        conn.commit()
        vaga = dict(conn.execute('SELECT * FROM vagas WHERE id = ?', (cur.lastrowid,)).fetchone())
        conn.close()
        return ok(vaga, 201)
    except sqlite3.IntegrityError:
        conn.close()
        return fail('Já existe vaga com esse número')
    except Exception as e:
        conn.close()
        return fail(str(e), 500)


@app.route('/api/vagas/<int:vid>/status', methods=['PUT'])
def atualizar_status_vaga(vid):
    data = request.get_json() or {}
    status = data.get('status')
    if status not in ('livre', 'ocupada', 'reservada', 'bloqueada'):
        return fail('Status inválido')
    conn = get_db()
    if status == 'livre':
        ativo = conn.execute(
            "SELECT id FROM estacionamentos WHERE vaga_id = ? AND status = 'ativo'", (vid,)
        ).fetchone()
        if ativo:
            conn.close()
            return fail('Vaga ocupada por veículo. Faça a saída primeiro.')
    cur = conn.execute('UPDATE vagas SET status = ? WHERE id = ?', (status, vid))
    conn.commit()
    conn.close()
    if cur.rowcount == 0:
        return fail('Vaga não encontrada', 404)
    return ok({'mensagem': 'Status atualizado', 'status': status})


@app.route('/api/busca', methods=['GET'])
def busca_global():
    q = (request.args.get('q') or '').strip()
    if len(q) < 1:
        return fail('Informe um termo de busca')

    like = f'%{q}%'
    conn = get_db()

    clientes = rows_to_list(conn.execute(
        "SELECT id, nome, cpf_cnpj, telefone, email, tipo, plano, plano_validade "
        "FROM clientes WHERE nome LIKE ? OR cpf_cnpj LIKE ? OR telefone LIKE ? OR email LIKE ? "
        "ORDER BY nome LIMIT 20",
        (like, like, like, like)
    ).fetchall())

    veiculos = rows_to_list(conn.execute(
        "SELECT v.id, v.placa, v.marca, v.modelo, v.cor, v.ano, v.tipo, v.tamanho, c.nome as cliente_nome "
        "FROM veiculos v LEFT JOIN clientes c ON v.cliente_id = c.id "
        "WHERE v.placa LIKE ? OR v.marca LIKE ? OR v.modelo LIKE ? OR v.cor LIKE ? OR c.nome LIKE ? "
        "ORDER BY v.placa LIMIT 20",
        (like, like, like, like, like)
    ).fetchall())

    vagas = rows_to_list(conn.execute(
        "SELECT id, numero, tipo, status, setor FROM vagas "
        "WHERE numero LIKE ? OR tipo LIKE ? OR setor LIKE ? OR status LIKE ? "
        "ORDER BY setor, numero LIMIT 20",
        (like, like, like, like)
    ).fetchall())

    historico = rows_to_list(conn.execute(
        "SELECT e.id, e.data_hora_entrada, e.data_hora_saida, e.valor_calculado, e.tipo_cobranca, e.status, "
        "v.placa, vg.numero as vaga_numero "
        "FROM estacionamentos e "
        "JOIN veiculos v ON e.veiculo_id = v.id "
        "JOIN vagas vg ON e.vaga_id = vg.id "
        "WHERE v.placa LIKE ? OR vg.numero LIKE ? OR e.status LIKE ? "
        "ORDER BY COALESCE(e.data_hora_saida, e.data_hora_entrada) DESC LIMIT 20",
        (like, like, like)
    ).fetchall())

    conn.close()
    return ok({
        'termo': q,
        'clientes': clientes,
        'veiculos': veiculos,
        'vagas': vagas,
        'historico': historico,
        'total': len(clientes) + len(veiculos) + len(vagas) + len(historico)
    })


# ============================================
# PREÇOS
# ============================================
@app.route('/api/precos', methods=['GET'])
def listar_precos():
    conn = get_db()
    rows = conn.execute(
        "SELECT * FROM precos WHERE ativo = 1 ORDER BY tipo_cobranca, tipo_veiculo"
    ).fetchall()
    conn.close()
    return ok(rows_to_list(rows))


@app.route('/api/precos', methods=['POST'])
def criar_preco():
    data = request.get_json() or {}
    descricao = (data.get('descricao') or '').strip()
    tipo_cobranca = data.get('tipo_cobranca')
    valor = data.get('valor')
    if not descricao or not tipo_cobranca or valor is None:
        return fail('Campos obrigatórios: descricao, tipo_cobranca, valor')
    if tipo_cobranca not in ('hora', 'diaria', 'mensal', 'anual'):
        return fail('tipo_cobranca inválido')

    conn = get_db()
    cur = conn.execute('''
        INSERT INTO precos (descricao, tipo_cobranca, valor, tipo_veiculo)
        VALUES (?, ?, ?, ?)
    ''', (descricao, tipo_cobranca, float(valor), data.get('tipo_veiculo') or 'todos'))
    conn.commit()
    preco = dict(conn.execute('SELECT * FROM precos WHERE id = ?', (cur.lastrowid,)).fetchone())
    conn.close()
    return ok(preco, 201)


@app.route('/api/precos/<int:pid>', methods=['DELETE'])
def desativar_preco(pid):
    conn = get_db()
    cur = conn.execute('UPDATE precos SET ativo = 0 WHERE id = ?', (pid,))
    conn.commit()
    conn.close()
    if cur.rowcount == 0:
        return fail('Preço não encontrado', 404)
    return ok({'mensagem': 'Preço desativado'})


# ============================================
# ESTACIONAMENTO
# ============================================
@app.route('/api/estacionamentos/ativos', methods=['GET'])
def estacionamentos_ativos():
    conn = get_db()
    rows = conn.execute('''
        SELECT e.*,
               v.placa, v.marca, v.modelo, v.cor, v.tipo as tipo_veiculo,
               vg.numero as vaga_numero, vg.tipo as vaga_tipo, vg.setor,
               c.nome as cliente_nome, c.plano as cliente_plano,
               c.plano_validade as cliente_plano_validade
        FROM estacionamentos e
        JOIN veiculos v ON e.veiculo_id = v.id
        JOIN vagas vg ON e.vaga_id = vg.id
        LEFT JOIN clientes c ON v.cliente_id = c.id
        WHERE e.status = 'ativo'
        ORDER BY e.data_hora_entrada DESC
    ''').fetchall()
    conn.close()
    return ok(rows_to_list(rows))


@app.route('/api/estacionamentos/previa/<int:eid>', methods=['GET'])
def previa_saida(eid):
    conn = get_db()
    est = conn.execute('''
        SELECT e.*, v.tipo as tipo_veiculo, v.placa,
               c.plano as cliente_plano, c.plano_validade as cliente_plano_validade
        FROM estacionamentos e
        JOIN veiculos v ON e.veiculo_id = v.id
        LEFT JOIN clientes c ON v.cliente_id = c.id
        WHERE e.id = ? AND e.status = 'ativo'
    ''', (eid,)).fetchone()
    if not est:
        conn.close()
        return fail('Estacionamento ativo não encontrado', 404)

    est = dict(est)
    plano = est.get('cliente_plano') or 'avulso'
    validade = est.get('cliente_plano_validade')
    plano_ok = plano in ('mensal', 'anual') and plano_ainda_valido(validade)

    por_hora = calcular_valor(conn, est['data_hora_entrada'], est['tipo_veiculo'], 'hora')
    por_diaria = calcular_valor(conn, est['data_hora_entrada'], est['tipo_veiculo'], 'diaria')
    sugestao = 'hora' if por_hora['valor'] <= por_diaria['valor'] else 'diaria'
    conn.close()

    return ok({
        'placa': est['placa'],
        'entrada': est['data_hora_entrada'],
        'plano_cliente': plano,
        'plano_validade': validade,
        'plano_valido': plano_ok,
        'opcoes': {'hora': por_hora, 'diaria': por_diaria},
        'sugestao': plano if plano_ok else sugestao
    })


@app.route('/api/estacionamentos/entrada', methods=['POST'])
def entrada():
    data = request.get_json() or {}
    placa = (data.get('placa') or '').strip()
    vaga_id = data.get('vaga_id')
    if not placa or not vaga_id:
        return fail('Placa e vaga são obrigatórios')

    placa_limpa = re.sub(r'[^A-Za-z0-9]', '', placa).upper()
    if not validar_placa(placa_limpa):
        return fail('Placa inválida')

    conn = get_db()
    veiculo = conn.execute(
        'SELECT * FROM veiculos WHERE UPPER(placa) = ?', (placa_limpa,)
    ).fetchone()
    if not veiculo:
        conn.close()
        return fail('Veículo não cadastrado. Cadastre o veículo primeiro.', 404)

    ja = conn.execute(
        "SELECT id FROM estacionamentos WHERE veiculo_id = ? AND status = 'ativo'",
        (veiculo['id'],)
    ).fetchone()
    if ja:
        conn.close()
        return fail('Este veículo já está estacionado')

    vaga = conn.execute('SELECT * FROM vagas WHERE id = ?', (vaga_id,)).fetchone()
    if not vaga:
        conn.close()
        return fail('Vaga não encontrada', 404)
    if vaga['status'] != 'livre':
        conn.close()
        return fail('Vaga não está disponível')

    try:
        cur = conn.execute('''
            INSERT INTO estacionamentos (veiculo_id, vaga_id, observacao)
            VALUES (?, ?, ?)
        ''', (veiculo['id'], vaga_id, (data.get('observacao') or '').strip() or None))
        conn.execute("UPDATE vagas SET status = 'ocupada' WHERE id = ?", (vaga_id,))
        conn.commit()
        registro = conn.execute('''
            SELECT e.*, v.placa, vg.numero as vaga_numero, vg.tipo as vaga_tipo
            FROM estacionamentos e
            JOIN veiculos v ON e.veiculo_id = v.id
            JOIN vagas vg ON e.vaga_id = vg.id
            WHERE e.id = ?
        ''', (cur.lastrowid,)).fetchone()
        conn.close()
        return ok(dict(registro), 201)
    except Exception as e:
        conn.close()
        return fail(str(e), 500)


@app.route('/api/estacionamentos/saida/<int:eid>', methods=['POST'])
def saida(eid):
    data = request.get_json() or {}
    tipo_req = data.get('tipo_cobranca')  # hora | diaria | auto

    conn = get_db()
    est = conn.execute('''
        SELECT e.*, v.tipo as tipo_veiculo, v.placa,
               c.plano as cliente_plano, c.plano_validade as cliente_plano_validade
        FROM estacionamentos e
        JOIN veiculos v ON e.veiculo_id = v.id
        LEFT JOIN clientes c ON v.cliente_id = c.id
        WHERE e.id = ? AND e.status = 'ativo'
    ''', (eid,)).fetchone()
    if not est:
        conn.close()
        return fail('Estacionamento ativo não encontrado', 404)

    est = dict(est)
    plano = est.get('cliente_plano') or 'avulso'
    validade = est.get('cliente_plano_validade')
    plano_ok = plano in ('mensal', 'anual') and plano_ainda_valido(validade)

    if plano_ok:
        tipo_final = plano
    elif not tipo_req or tipo_req == 'auto':
        por_hora = calcular_valor(conn, est['data_hora_entrada'], est['tipo_veiculo'], 'hora')
        por_diaria = calcular_valor(conn, est['data_hora_entrada'], est['tipo_veiculo'], 'diaria')
        tipo_final = 'hora' if por_hora['valor'] <= por_diaria['valor'] else 'diaria'
    else:
        tipo_final = tipo_req

    calc = calcular_valor(conn, est['data_hora_entrada'], est['tipo_veiculo'],
                          tipo_final, plano, validade)

    try:
        conn.execute('''
            UPDATE estacionamentos
            SET data_hora_saida = CURRENT_TIMESTAMP,
                valor_calculado = ?,
                tipo_cobranca = ?,
                status = 'finalizado'
            WHERE id = ?
        ''', (calc['valor'], calc['tipo_cobranca'], eid))
        conn.execute("UPDATE vagas SET status = 'livre' WHERE id = ?", (est['vaga_id'],))
        conn.commit()
        resultado = conn.execute('''
            SELECT e.*, v.placa, vg.numero as vaga_numero
            FROM estacionamentos e
            JOIN veiculos v ON e.veiculo_id = v.id
            JOIN vagas vg ON e.vaga_id = vg.id
            WHERE e.id = ?
        ''', (eid,)).fetchone()
        conn.close()
        out = dict(resultado)
        out.update(calc)
        return ok(out)
    except Exception as e:
        conn.close()
        return fail(str(e), 500)


@app.route('/api/estacionamentos/historico', methods=['GET'])
def historico():
    conn = get_db()
    rows = conn.execute('''
        SELECT e.*, v.placa, v.marca, v.modelo, vg.numero as vaga_numero
        FROM estacionamentos e
        JOIN veiculos v ON e.veiculo_id = v.id
        JOIN vagas vg ON e.vaga_id = vg.id
        WHERE e.status = 'finalizado'
        ORDER BY e.data_hora_saida DESC
        LIMIT 100
    ''').fetchall()
    conn.close()
    return ok(rows_to_list(rows))


# ============================================
# RELATÓRIOS
# ============================================
@app.route('/api/relatorios/ocupacao', methods=['GET'])
def rel_ocupacao():
    conn = get_db()
    total = conn.execute('SELECT COUNT(*) as t FROM vagas').fetchone()['t']
    livres = conn.execute("SELECT COUNT(*) as t FROM vagas WHERE status='livre'").fetchone()['t']
    ocupadas = conn.execute("SELECT COUNT(*) as t FROM vagas WHERE status='ocupada'").fetchone()['t']
    detalhe = rows_to_list(conn.execute(
        'SELECT tipo, status, COUNT(*) as quantidade FROM vagas GROUP BY tipo, status'
    ).fetchall())
    conn.close()
    return ok({
        'total_vagas': total,
        'livres': livres,
        'ocupadas': ocupadas,
        'percentual_ocupacao': round((ocupadas / total) * 100, 1) if total else 0,
        'detalhe': detalhe
    })


@app.route('/api/relatorios/faturamento', methods=['GET'])
def rel_faturamento():
    conn = get_db()
    hoje = conn.execute('''
        SELECT COALESCE(SUM(valor_calculado),0) as total, COUNT(*) as quantidade
        FROM estacionamentos
        WHERE status='finalizado' AND date(data_hora_saida)=date('now')
    ''').fetchone()
    mes = conn.execute('''
        SELECT COALESCE(SUM(valor_calculado),0) as total, COUNT(*) as quantidade
        FROM estacionamentos
        WHERE status='finalizado' AND strftime('%Y-%m', data_hora_saida)=strftime('%Y-%m','now')
    ''').fetchone()
    planos_hoje = conn.execute('''
        SELECT COALESCE(SUM(valor),0) as total FROM pagamentos_plano
        WHERE date(data_pagamento)=date('now')
    ''').fetchone()['total']
    planos_mes = conn.execute('''
        SELECT COALESCE(SUM(valor),0) as total FROM pagamentos_plano
        WHERE strftime('%Y-%m', data_pagamento)=strftime('%Y-%m','now')
    ''').fetchone()['total']
    conn.close()
    return ok({
        'faturamento_hoje': hoje['total'] + planos_hoje,
        'qtd_hoje': hoje['quantidade'],
        'planos_hoje': planos_hoje,
        'faturamento_mes': mes['total'] + planos_mes,
        'qtd_mes': mes['quantidade'],
        'planos_mes': planos_mes
    })


@app.route('/api/relatorios/completo', methods=['GET'])
def rel_completo():
    conn = get_db()
    ocupacao = {
        'total': conn.execute('SELECT COUNT(*) as t FROM vagas').fetchone()['t'],
        'livres': conn.execute("SELECT COUNT(*) as t FROM vagas WHERE status='livre'").fetchone()['t'],
        'ocupadas': conn.execute("SELECT COUNT(*) as t FROM vagas WHERE status='ocupada'").fetchone()['t'],
    }
    faturamento = {
        'hoje': conn.execute(
            "SELECT COALESCE(SUM(valor_calculado),0) as t FROM estacionamentos WHERE status='finalizado' AND date(data_hora_saida)=date('now')"
        ).fetchone()['t'],
        'mes': conn.execute(
            "SELECT COALESCE(SUM(valor_calculado),0) as t FROM estacionamentos WHERE status='finalizado' AND strftime('%Y-%m',data_hora_saida)=strftime('%Y-%m','now')"
        ).fetchone()['t'],
    }
    planos_mes = conn.execute(
        "SELECT COALESCE(SUM(valor),0) as t FROM pagamentos_plano WHERE strftime('%Y-%m',data_pagamento)=strftime('%Y-%m','now')"
    ).fetchone()['t']
    faturamento['mes'] += planos_mes
    faturamento['hoje'] += conn.execute(
        "SELECT COALESCE(SUM(valor),0) as t FROM pagamentos_plano WHERE date(data_pagamento)=date('now')"
    ).fetchone()['t']

    tempo = conn.execute('''
        SELECT AVG((julianday(data_hora_saida) - julianday(data_hora_entrada)) * 24 * 60) as minutos
        FROM estacionamentos WHERE status='finalizado' AND data_hora_saida IS NOT NULL
    ''').fetchone()['minutos']

    ranking = rows_to_list(conn.execute('''
        SELECT v.placa, v.marca, v.modelo, COUNT(*) as visitas,
               COALESCE(SUM(e.valor_calculado),0) as total_pago
        FROM estacionamentos e
        JOIN veiculos v ON e.veiculo_id = v.id
        WHERE e.status = 'finalizado'
        GROUP BY v.id ORDER BY visitas DESC LIMIT 10
    ''').fetchall())

    vagas_uso = rows_to_list(conn.execute('''
        SELECT vg.numero, vg.tipo, COUNT(*) as usos
        FROM estacionamentos e
        JOIN vagas vg ON e.vaga_id = vg.id
        WHERE e.status = 'finalizado'
        GROUP BY vg.id ORDER BY usos DESC LIMIT 10
    ''').fetchall())

    por_dia = rows_to_list(conn.execute('''
        SELECT date(data_hora_saida) as dia, COUNT(*) as quantidade,
               COALESCE(SUM(valor_calculado),0) as total
        FROM estacionamentos
        WHERE status='finalizado' AND data_hora_saida >= date('now','-7 days')
        GROUP BY date(data_hora_saida) ORDER BY dia DESC
    ''').fetchall())

    conn.close()
    return ok({
        'ocupacao': ocupacao,
        'faturamento': faturamento,
        'tempo_medio_minutos': round(tempo) if tempo else 0,
        'ranking_placas': ranking,
        'vagas_mais_usadas': vagas_uso,
        'ultimos_7_dias': por_dia
    })


# ============================================
# START
# ============================================
if __name__ == '__main__':
    init_db()
    seed_db()
    print('\n  🚀  ParkSystem (Flask + SQLite)')
    print('  ➜  http://localhost:5000\n')
    app.run(debug=True, port=5000)
