const API = '/api';

const TITULOS = {
  dashboard: 'Dashboard',
  entrada: 'Entrada de Veículo',
  saida: 'Saída de Veículo',
  vagas: 'Mapa de Vagas',
  veiculos: 'Veículos',
  clientes: 'Clientes',
  precos: 'Tabela de Preços',
  relatorios: 'Relatórios',
  historico: 'Histórico',
  busca: 'Pesquisa',
  usuarios: 'Usuários'
};

let saidaAtualId = null;
let saidaPrevia = null;
let USER = null;

function toast(msg, tipo = 'success') {
  const el = document.getElementById('toast');
  el.textContent = msg;
  el.className = `toast ${tipo} show`;
  setTimeout(() => el.classList.remove('show'), 3500);
}

async function api(path, options = {}) {
  const res = await fetch(`${API}${path}`, {
    credentials: 'same-origin',
    headers: { 'Content-Type': 'application/json', ...(options.headers || {}) },
    ...options
  });
  const json = await res.json();
  if (res.status === 401) {
    mostrarLogin();
    throw new Error(json.error || 'Faça login');
  }
  if (!json.success) throw new Error(json.error || 'Erro desconhecido');
  return json.data;
}

function formatarData(str) {
  if (!str) return '—';
  return new Date(str).toLocaleString('pt-BR', {
    day: '2-digit', month: '2-digit', year: 'numeric',
    hour: '2-digit', minute: '2-digit'
  });
}

function formatarMoeda(v) {
  return 'R$ ' + Number(v || 0).toFixed(2).replace('.', ',');
}

function atualizarRelogio() {
  const el = document.getElementById('clock');
  if (!el) return;
  el.textContent = new Date().toLocaleString('pt-BR', {
    weekday: 'short', day: '2-digit', month: 'short',
    hour: '2-digit', minute: '2-digit', second: '2-digit'
  });
}
setInterval(atualizarRelogio, 1000);
atualizarRelogio();

document.querySelectorAll('.nav-item').forEach(btn => {
  btn.addEventListener('click', () => {
    document.querySelectorAll('.nav-item').forEach(b => b.classList.remove('active'));
    document.querySelectorAll('.page').forEach(p => p.classList.remove('active'));
    btn.classList.add('active');
    const page = btn.dataset.page;
    const pageEl = document.getElementById(page);
    if (pageEl) pageEl.classList.add('active');
    document.getElementById('page-title').textContent = TITULOS[page] || page;
    if (page === 'dashboard') carregarDashboard();
    if (page === 'entrada') carregarVagasLivres();
    if (page === 'saida') carregarAtivosParaSaida();
    if (page === 'vagas') carregarVagas();
    if (page === 'veiculos') carregarVeiculos();
    if (page === 'clientes') carregarClientes();
    if (page === 'precos') carregarPrecos();
    if (page === 'relatorios') carregarRelatorios();
    if (page === 'historico') carregarHistorico();
    if (page === 'usuarios') carregarUsuarios();
    if (page === 'busca') {
      const t = document.getElementById('busca-termo');
      if (t) t.focus();
    }
  });
});

function mostrarLogin() {
  document.getElementById('tela-login').classList.add('open');
  document.getElementById('app-main').style.display = 'none';
}

function esconderLogin() {
  document.getElementById('tela-login').classList.remove('open');
  document.getElementById('app-main').style.display = '';
}

function aplicarPermissoes() {
  if (!USER) return;
  const info = document.getElementById('user-info');
  if (info) info.textContent = USER.nome + ' (' + USER.perfil + ')';
  const isGerente = USER.perfil === 'gerente';
  document.querySelectorAll('[onclick="abrirModalVaga()"]').forEach(el => {
    el.style.display = isGerente ? '' : 'none';
  });
  document.querySelectorAll('#precos .btn-primary').forEach(el => {
    el.style.display = isGerente ? '' : 'none';
  });
  document.querySelectorAll('.only-gerente').forEach(el => {
    el.style.display = isGerente ? '' : 'none';
  });
  document.querySelectorAll('.only-gerente-action').forEach(el => {
    el.style.display = isGerente ? '' : 'none';
  });
}

async function tentarSessao() {
  try {
    const res = await fetch('/api/me', { credentials: 'same-origin' });
    const json = await res.json();
    if (json.success) {
      USER = json.data;
      esconderLogin();
      aplicarPermissoes();
      carregarDashboard();
      return;
    }
  } catch (e) {}
  mostrarLogin();
}

document.getElementById('form-login').addEventListener('submit', async (e) => {
  e.preventDefault();
  const erro = document.getElementById('login-erro');
  if (erro) erro.style.display = 'none';
  try {
    const res = await fetch('/api/login', {
      method: 'POST',
      credentials: 'same-origin',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        login: document.getElementById('login-user').value.trim(),
        senha: document.getElementById('login-senha').value
      })
    });
    const json = await res.json();
    if (!json.success) throw new Error(json.error || 'Falha no login');
    USER = json.data;
    esconderLogin();
    aplicarPermissoes();
    carregarDashboard();
    toast('Bem-vindo, ' + USER.nome);
  } catch (err) {
    if (erro) {
      erro.textContent = err.message;
      erro.style.display = 'block';
    } else {
      toast(err.message, 'error');
    }
  }
});

document.getElementById('btn-logout').addEventListener('click', async () => {
  await fetch('/api/logout', { method: 'POST', credentials: 'same-origin' });
  USER = null;
  mostrarLogin();
});


async function carregarDashboard() {
  try {
    const [ocupacao, faturamento, ativos, alertas] = await Promise.all([
      api('/relatorios/ocupacao'),
      api('/relatorios/faturamento'),
      api('/estacionamentos/ativos'),
      api('/planos/alertas?dias=7').catch(() => ({ vencidos: [], a_vencer: [], total_alertas: 0 }))
    ]);
    document.getElementById('qtd-livres').textContent = ocupacao.livres;
    document.getElementById('qtd-ocupadas').textContent = ocupacao.ocupadas;
    document.getElementById('percentual').textContent = ocupacao.percentual_ocupacao + '%';
    document.getElementById('faturamento-hoje').textContent = formatarMoeda(faturamento.faturamento_hoje);
    document.getElementById('badge-ativos').textContent = ativos.length + ' ativos';
    const tbody = document.getElementById('tbody-ativos');
    if (!ativos.length) {
      tbody.innerHTML = '<tr><td colspan="5" class="empty">Nenhum veículo no pátio</td></tr>';
    } else {
      tbody.innerHTML = ativos.map(e => `
        <tr>
          <td><span class="placa">${e.placa}</span></td>
          <td>${[e.marca, e.modelo].filter(Boolean).join(' ') || '—'} ${e.cor ? '<span style="color:#94a3b8">(' + e.cor + ')</span>' : ''}</td>
          <td>${e.vaga_numero} <span style="color:#94a3b8;font-size:12px">${e.vaga_tipo}</span></td>
          <td>${formatarData(e.data_hora_entrada)}</td>
          <td>${e.cliente_nome || '—'} ${e.cliente_plano && e.cliente_plano !== 'avulso' ? '<span class="badge">' + e.cliente_plano + '</span>' : ''}</td>
        </tr>
      `).join('');
    }
    renderPlanosAlertas(alertas);
  } catch (err) { toast(err.message, 'error'); }
}

function renderPlanosAlertas(alertas) {
  const card = document.getElementById('dashboard-planos-alertas');
  const tbody = document.getElementById('tbody-planos-alertas');
  const badge = document.getElementById('badge-planos-alertas');
  if (!card || !tbody) return;
  const vencidos = alertas.vencidos || [];
  const aVencer = alertas.a_vencer || [];
  const total = vencidos.length + aVencer.length;
  if (!total) {
    card.style.display = 'none';
    return;
  }
  card.style.display = '';
  badge.textContent = total + (total === 1 ? ' alerta' : ' alertas');
  const linhas = [];
  vencidos.forEach(c => {
    const valor = c.valor_renovacao != null ? formatarMoeda(c.valor_renovacao) : '—';
    const dias = Math.abs(c.dias_restantes || 0);
    linhas.push(`
      <tr>
        <td><strong>${c.nome}</strong>${c.telefone ? '<br><small style="color:#64748b">' + c.telefone + '</small>' : ''}</td>
        <td><span class="badge">${c.plano}${c.nivel ? ' · ' + c.nivel : ''}</span></td>
        <td>${c.plano_validade || '—'}</td>
        <td><span style="color:#dc2626;font-weight:600">Vencido há ${dias} dia${dias === 1 ? '' : 's'}</span></td>
        <td><strong>${valor}</strong></td>
        <td style="white-space:nowrap">
          <button class="btn btn-primary btn-sm" onclick="renovarPlanoRapido(${c.id}, '${c.plano}', '${c.nivel || 'sem'}', ${c.valor_renovacao != null ? c.valor_renovacao : 'null'})">Renovar</button>
          <button class="btn btn-ghost btn-sm" onclick="abrirGerenciarPlano(${c.id})">Detalhes</button>
        </td>
      </tr>`);
  });
  aVencer.forEach(c => {
    const valor = c.valor_renovacao != null ? formatarMoeda(c.valor_renovacao) : '—';
    const dias = c.dias_restantes;
    const txt = dias === 0 ? 'Vence hoje' : (dias === 1 ? 'Vence amanhã' : 'Vence em ' + dias + ' dias');
    linhas.push(`
      <tr>
        <td><strong>${c.nome}</strong>${c.telefone ? '<br><small style="color:#64748b">' + c.telefone + '</small>' : ''}</td>
        <td><span class="badge">${c.plano}${c.nivel ? ' · ' + c.nivel : ''}</span></td>
        <td>${c.plano_validade || '—'}</td>
        <td><span style="color:#d97706;font-weight:600">${txt}</span></td>
        <td><strong>${valor}</strong></td>
        <td style="white-space:nowrap">
          <button class="btn btn-primary btn-sm" onclick="renovarPlanoRapido(${c.id}, '${c.plano}', '${c.nivel || 'sem'}', ${c.valor_renovacao != null ? c.valor_renovacao : 'null'})">Renovar</button>
          <button class="btn btn-ghost btn-sm" onclick="abrirGerenciarPlano(${c.id})">Detalhes</button>
        </td>
      </tr>`);
  });
  tbody.innerHTML = linhas.join('');
}

async function renovarPlanoRapido(id, plano, nivel, valor) {
  const valorTxt = valor != null ? formatarMoeda(valor) : '?';
  if (!confirm('Renovar ' + plano + '/' + nivel + ' por ' + valorTxt + '?\nA validade será estendida e o pagamento registrado.')) {
    return;
  }
  try {
    const data = await api('/clientes/' + id + '/plano', {
      method: 'PUT',
      body: JSON.stringify({ plano, nivel, renovar: true })
    });
    if (data.pagamento_plano) toast(data.pagamento_plano.mensagem);
    else toast('Plano renovado');
    carregarDashboard();
    if (document.getElementById('clientes')?.classList.contains('active')) carregarClientes();
  } catch (err) { toast(err.message, 'error'); }
}

async function carregarVagasLivres(preferTipo) {
  const select = document.getElementById('entrada-vaga');
  const atual = select.value;
  select.innerHTML = '<option value="">Carregando...</option>';
  try {
    const vagas = await api('/vagas/livres');
    if (!vagas.length) {
      select.innerHTML = '<option value="">Nenhuma vaga livre</option>';
      return;
    }
    // Ordena sugerindo o tipo preferido (ex: moto) no topo
    let lista = vagas.slice();
    if (preferTipo) {
      const pref = preferTipo === 'moto' ? 'moto'
        : (preferTipo === 'caminhao' || preferTipo === 'utilitario') ? 'carga'
        : null;
      if (pref) {
        lista = lista.filter(v => v.tipo === pref).concat(lista.filter(v => v.tipo !== pref));
      }
    }
    select.innerHTML = '<option value="">Selecione a vaga...</option>' +
      lista.map(v => '<option value="' + v.id + '">' + v.numero + ' — ' + v.tipo + ' (Setor ' + v.setor + ')</option>').join('');
    if (atual && lista.some(v => String(v.id) === String(atual))) {
      select.value = atual;
    }
  } catch {
    select.innerHTML = '<option value="">Erro ao carregar</option>';
  }
}

function limparEntradaVeiculoInfo() {
  const box = document.getElementById('entrada-veiculo-info');
  if (box) {
    box.style.display = 'none';
    box.className = 'entrada-info-box';
    box.innerHTML = '';
  }
  document.querySelectorAll('.entrada-busca-item.selecionado').forEach(el => el.classList.remove('selecionado'));
}

function mostrarCadastroRapido(mostrar) {
  const painel = document.getElementById('entrada-cadastro-rapido');
  if (!painel) return;
  painel.style.display = mostrar ? 'block' : 'none';
  const tipo = document.getElementById('entrada-tipo');
  if (tipo) tipo.required = !!mostrar;
  if (!mostrar) {
    limparClienteEntrada();
  }
}

function limparClienteEntrada() {
  const id = document.getElementById('entrada-cliente-id');
  const busca = document.getElementById('entrada-cliente-busca');
  const sel = document.getElementById('entrada-cliente-sel');
  const lista = document.getElementById('entrada-cliente-lista');
  if (id) id.value = '';
  if (busca) busca.value = '';
  if (sel) sel.innerHTML = '';
  if (lista) lista.style.display = 'none';
}

function preencherEntradaComVeiculo(v) {
  if (!v || !v.placa) return;
  if (v.ja_estacionado) {
    toast('Este veículo já está no pátio (vaga ' + (v.vaga_atual || '?') + ')', 'error');
    return;
  }
  document.getElementById('entrada-placa').value = v.placa;
  mostrarCadastroRapido(false);
  const box = document.getElementById('entrada-veiculo-info');
  const veiculoTxt = [v.marca, v.modelo, v.cor].filter(Boolean).join(' · ') || '—';
  const tipoTxt = (v.tipo || 'carro') + (v.tamanho ? ' / ' + v.tamanho : '');
  let html = '<strong>' + v.placa + '</strong> — ' + veiculoTxt + ' <span style="color:#64748b">(' + tipoTxt + ')</span>';
  if (v.cliente_nome) {
    const plano = v.cliente_plano && v.cliente_plano !== 'avulso'
      ? (v.cliente_plano + (v.cliente_nivel ? '/' + v.cliente_nivel : ''))
      : 'avulso';
    html += '<br>Cliente: <strong>' + v.cliente_nome + '</strong>';
    if (v.cliente_telefone) html += ' · ' + v.cliente_telefone;
    html += ' · plano <strong>' + plano + '</strong>';
    if (v.cliente_plano && v.cliente_plano !== 'avulso') {
      if (v.coberto_plano) {
        html += ' <span style="color:#059669">(coberto — saída grátis)</span>';
      } else {
        html += ' <span style="color:#d97706">(extra / vencido — cobra avulso)</span>';
      }
    }
  } else {
    html += '<br><span style="color:#64748b">Sem cliente vinculado — cobrança avulsa na saída</span>';
  }
  box.innerHTML = html;
  box.className = 'entrada-info-box';
  box.style.display = 'block';

  document.querySelectorAll('.entrada-busca-item.selecionado').forEach(el => el.classList.remove('selecionado'));
  const item = document.querySelector('.entrada-busca-item[data-placa="' + v.placa + '"]');
  if (item) item.classList.add('selecionado');

  carregarVagasLivres(v.tipo);
  document.getElementById('entrada-vaga').focus();
}

async function verificarPlacaEntrada() {
  const placa = (document.getElementById('entrada-placa').value || '').trim();
  const box = document.getElementById('entrada-veiculo-info');
  if (placa.length < 7) {
    // placa incompleta — não força cadastro ainda
    return;
  }
  try {
    const lista = await api('/veiculos/busca?q=' + encodeURIComponent(placa));
    const exact = lista.find(v => String(v.placa).toUpperCase() === placa.toUpperCase());
    if (exact) {
      preencherEntradaComVeiculo(exact);
      return;
    }
    // Não encontrado → cadastro rápido
    limparEntradaVeiculoInfo();
    mostrarCadastroRapido(true);
    if (box) {
      box.style.display = 'block';
      box.className = 'entrada-info-box warn';
      box.innerHTML = 'Placa <strong>' + placa.toUpperCase() + '</strong> não cadastrada. Preencha o tipo abaixo e confirme a entrada — o veículo será criado automaticamente.';
    }
  } catch (_) {}
}

let _entradaBuscaTimer = null;
let _entradaBuscaSeq = 0;

async function buscarVeiculosEntrada(termo) {
  const box = document.getElementById('entrada-busca-resultados');
  const q = (termo || '').trim();
  if (q.length < 1) {
    box.innerHTML = '<div class="empty" style="padding:24px 12px">Digite para buscar veículos cadastrados</div>';
    return;
  }
  const seq = ++_entradaBuscaSeq;
  box.innerHTML = '<div class="empty" style="padding:24px 12px">Buscando...</div>';
  try {
    const lista = await api('/veiculos/busca?q=' + encodeURIComponent(q));
    if (seq !== _entradaBuscaSeq) return;
    if (!lista.length) {
      box.innerHTML = '<div class="empty" style="padding:24px 12px">Nenhum veículo encontrado</div>';
      return;
    }
    box.innerHTML = lista.map(v => {
      const veiculoTxt = [v.marca, v.modelo, v.cor].filter(Boolean).join(' · ') || 'sem descrição';
      const tags = [];
      if (v.ja_estacionado) {
        tags.push('<span class="badge" style="background:#fee2e2;color:#991b1b">no pátio' + (v.vaga_atual ? ' · ' + v.vaga_atual : '') + '</span>');
      }
      if (v.cliente_plano && v.cliente_plano !== 'avulso') {
        const ok = v.coberto_plano;
        tags.push('<span class="badge"' + (ok ? '' : ' style="background:#fef3c7;color:#92400e"') + '>' +
          v.cliente_plano + (v.cliente_nivel ? '/' + v.cliente_nivel : '') +
          (ok ? '' : ' · cobra') + '</span>');
      } else if (!v.cliente_nome) {
        tags.push('<span class="badge" style="background:#f1f5f9;color:#475569">avulso</span>');
      }
      const disabled = v.ja_estacionado ? ' ja-estacionado' : '';
      const onclick = v.ja_estacionado
        ? 'toast(\'Já está no pátio (vaga ' + (v.vaga_atual || '?') + ')\', \'error\')'
        : 'selecionarVeiculoEntrada(' + v.id + ')';
      return '<div class="entrada-busca-item' + disabled + '" data-placa="' + v.placa + '" data-id="' + v.id + '" onclick="' + onclick + '">' +
        '<div><div class="placa-destaque">' + v.placa + '</div>' +
        '<div class="vei-meta">' + veiculoTxt + ' · ' + (v.tipo || 'carro') + '</div>' +
        (v.cliente_nome ? '<div class="vei-cliente">' + v.cliente_nome + '</div>' : '') +
        '</div>' +
        '<div class="vei-tags">' + tags.join('') + '</div>' +
        '</div>';
    }).join('');
    // guarda lista para clique por id
    window._entradaBuscaCache = {};
    lista.forEach(v => { window._entradaBuscaCache[v.id] = v; });
  } catch (err) {
    if (seq !== _entradaBuscaSeq) return;
    box.innerHTML = '<div class="empty" style="padding:24px 12px;color:#dc2626">' + (err.message || 'Erro na busca') + '</div>';
  }
}

function selecionarVeiculoEntrada(id) {
  const v = (window._entradaBuscaCache || {})[id];
  if (!v) return;
  preencherEntradaComVeiculo(v);
}

document.getElementById('entrada-busca').addEventListener('input', (e) => {
  clearTimeout(_entradaBuscaTimer);
  const val = e.target.value;
  _entradaBuscaTimer = setTimeout(() => buscarVeiculosEntrada(val), 220);
});

let _entradaPlacaTimer = null;
document.getElementById('entrada-placa').addEventListener('input', () => {
  limparEntradaVeiculoInfo();
  mostrarCadastroRapido(false);
  clearTimeout(_entradaPlacaTimer);
  _entradaPlacaTimer = setTimeout(verificarPlacaEntrada, 400);
});

document.getElementById('entrada-placa').addEventListener('blur', () => {
  verificarPlacaEntrada();
});

document.getElementById('entrada-tipo')?.addEventListener('change', (e) => {
  carregarVagasLivres(e.target.value);
});

// Busca de cliente no cadastro rápido
let _entradaCliTimer = null;
document.getElementById('entrada-cliente-busca')?.addEventListener('input', (e) => {
  clearTimeout(_entradaCliTimer);
  const q = e.target.value.trim();
  const lista = document.getElementById('entrada-cliente-lista');
  if (q.length < 1) {
    if (lista) lista.style.display = 'none';
    return;
  }
  _entradaCliTimer = setTimeout(async () => {
    try {
      const clientes = await api('/clientes/busca?q=' + encodeURIComponent(q));
      if (!clientes.length) {
        lista.innerHTML = '<div class="cliente-busca-item" style="cursor:default;color:#64748b">Nenhum cliente</div>';
        lista.style.display = 'block';
        return;
      }
      lista.innerHTML = clientes.map(c => {
        const extra = [c.cpf_cnpj, c.plano && c.plano !== 'avulso' ? c.plano : null].filter(Boolean).join(' · ');
        const nomeSafe = String(c.nome || '').replace(/\\/g, '\\\\').replace(/'/g, "\\'");
        return '<div class="cliente-busca-item" onclick="selecionarClienteEntrada(' + c.id + ', \'' + nomeSafe + '\')">' +
          '<strong>' + c.nome + '</strong>' +
          (extra ? '<small>' + extra + '</small>' : '') +
          '</div>';
      }).join('');
      lista.style.display = 'block';
    } catch (_) {
      lista.style.display = 'none';
    }
  }, 220);
});

function selecionarClienteEntrada(id, nome) {
  document.getElementById('entrada-cliente-id').value = id;
  document.getElementById('entrada-cliente-busca').value = nome;
  document.getElementById('entrada-cliente-sel').innerHTML =
    'Vinculado a <strong>' + nome + '</strong> · <a href="#" onclick="limparClienteEntrada();return false;" style="color:#dc2626">remover</a>';
  document.getElementById('entrada-cliente-lista').style.display = 'none';
}

document.getElementById('form-entrada').addEventListener('submit', async (e) => {
  e.preventDefault();
  const btn = e.target.querySelector('[type=submit]');
  btn.disabled = true; btn.textContent = 'Registrando...';
  const cadastroVisivel = document.getElementById('entrada-cadastro-rapido')?.style.display === 'block';
  const payload = {
    placa: document.getElementById('entrada-placa').value.trim(),
    vaga_id: Number(document.getElementById('entrada-vaga').value),
    observacao: document.getElementById('entrada-obs').value.trim()
  };
  if (cadastroVisivel) {
    payload.tipo = document.getElementById('entrada-tipo').value;
    payload.tamanho = document.getElementById('entrada-tamanho').value;
    payload.marca = document.getElementById('entrada-marca').value.trim();
    payload.modelo = document.getElementById('entrada-modelo').value.trim();
    payload.cor = document.getElementById('entrada-cor').value.trim();
    const cid = document.getElementById('entrada-cliente-id').value;
    if (cid) payload.cliente_id = Number(cid);
  }
  try {
    const data = await api('/estacionamentos/entrada', {
      method: 'POST',
      body: JSON.stringify(payload)
    });
    const extra = data.veiculo_criado ? ' (veículo cadastrado agora)' : '';
    toast('Entrada: ' + data.placa + ' → vaga ' + data.vaga_numero + extra);
    e.target.reset();
    limparEntradaVeiculoInfo();
    mostrarCadastroRapido(false);
    limparClienteEntrada();
    document.getElementById('entrada-busca').value = '';
    document.getElementById('entrada-busca-resultados').innerHTML =
      '<div class="empty" style="padding:24px 12px">Digite para buscar veículos cadastrados</div>';
    carregarVagasLivres();
  } catch (err) {
    // Se backend disser não cadastrado, abre cadastro rápido
    if (String(err.message || '').toLowerCase().includes('não cadastrado')) {
      mostrarCadastroRapido(true);
      const box = document.getElementById('entrada-veiculo-info');
      if (box) {
        box.style.display = 'block';
        box.className = 'entrada-info-box warn';
        box.innerHTML = 'Veículo novo: preencha o <strong>tipo</strong> e confirme de novo.';
      }
    }
    toast(err.message, 'error');
  }
  finally { btn.disabled = false; btn.textContent = 'Confirmar Entrada'; }
});

async function carregarAtivosParaSaida() {
  const tbody = document.getElementById('tbody-saida');
  tbody.innerHTML = '<tr><td colspan="6" class="empty">Carregando...</td></tr>';
  try {
    const ativos = await api('/estacionamentos/ativos');
    document.getElementById('badge-saida').textContent = ativos.length + ' veículos';
    if (!ativos.length) {
      tbody.innerHTML = '<tr><td colspan="6" class="empty">Nenhum veículo para saída</td></tr>';
      return;
    }
    tbody.innerHTML = ativos.map(e => `
      <tr>
        <td><span class="placa">${e.placa}</span></td>
        <td>${[e.marca, e.modelo].filter(Boolean).join(' ') || '—'}</td>
        <td>${e.vaga_numero}</td>
        <td>${formatarData(e.data_hora_entrada)}</td>
        <td>${e.cliente_plano && e.cliente_plano !== 'avulso' ? '<span class="badge">' + e.cliente_plano + '</span>' : 'avulso'}</td>
        <td><button class="btn btn-success" onclick="abrirSaida(${e.id})">Finalizar</button></td>
      </tr>
    `).join('');
  } catch { tbody.innerHTML = '<tr><td colspan="6" class="empty">Erro ao carregar</td></tr>'; }
}

async function abrirSaida(id) {
  saidaAtualId = id;
  try {
    saidaPrevia = await api('/estacionamentos/previa/' + id);
    let info = '<strong>' + saidaPrevia.placa + '</strong> — entrada em ' + formatarData(saidaPrevia.entrada);
    if (saidaPrevia.plano_valido && saidaPrevia.coberto_plano) {
      info += '<br><span style="color:#059669">Cliente com plano <strong>' + saidaPrevia.plano_cliente + '</strong> válido até ' + (saidaPrevia.plano_validade || '—') + ' — sem cobrança</span>';
    } else if (saidaPrevia.aviso_extra) {
      info += '<br><span style="color:#d97706">' + saidaPrevia.aviso_extra + '</span>';
    } else if (saidaPrevia.plano_cliente && saidaPrevia.plano_cliente !== 'avulso') {
      info += '<br><span style="color:#dc2626">Plano ' + saidaPrevia.plano_cliente + ' vencido — cobrança normal</span>';
    }
    document.getElementById('saida-info').innerHTML = info;
    const sel = document.getElementById('saida-tipo');
    if (saidaPrevia.plano_valido && saidaPrevia.coberto_plano) {
      sel.innerHTML = '<option value="' + saidaPrevia.plano_cliente + '">Plano ' + saidaPrevia.plano_cliente + ' válido (R$ 0)</option>';
      sel.disabled = true;
    } else {
      sel.disabled = false;
      sel.innerHTML =
        '<option value="auto">Automático (melhor preço)</option>' +
        '<option value="hora">Por hora — ' + formatarMoeda(saidaPrevia.opcoes.hora.valor) + '</option>' +
        '<option value="diaria">Diária — ' + formatarMoeda(saidaPrevia.opcoes.diaria.valor) + '</option>';
    }
    atualizarPreviaSaida();
    document.getElementById('modal-saida').classList.add('open');
  } catch (err) { toast(err.message, 'error'); }
}

function atualizarPreviaSaida() {
  if (!saidaPrevia) return;
  const tipo = document.getElementById('saida-tipo').value;
  let texto = '';
  if (saidaPrevia.plano_valido) {
    texto = 'Valor a pagar: <strong>R$ 0,00</strong> (plano ' + saidaPrevia.plano_cliente + ' válido)';
  } else if (tipo === 'hora') {
    texto = 'Por hora: <strong>' + formatarMoeda(saidaPrevia.opcoes.hora.valor) + '</strong><br><small>' + saidaPrevia.opcoes.hora.detalhe + '</small>';
  } else if (tipo === 'diaria') {
    texto = 'Diária: <strong>' + formatarMoeda(saidaPrevia.opcoes.diaria.valor) + '</strong>';
  } else {
    const s = saidaPrevia.sugestao;
    const v = saidaPrevia.opcoes[s];
    texto = 'Sugestão: <strong>' + s + '</strong> — ' + formatarMoeda(v.valor) +
      '<br><small>Hora: ' + formatarMoeda(saidaPrevia.opcoes.hora.valor) + ' | Diária: ' + formatarMoeda(saidaPrevia.opcoes.diaria.valor) + '</small>';
  }
  document.getElementById('saida-previa').innerHTML = texto;
}

document.getElementById('saida-tipo').addEventListener('change', atualizarPreviaSaida);

document.getElementById('btn-confirmar-saida').addEventListener('click', async () => {
  if (!saidaAtualId) return;
  try {
    const tipo = document.getElementById('saida-tipo').value;
    const data = await api('/estacionamentos/saida/' + saidaAtualId, {
      method: 'POST',
      body: JSON.stringify({ tipo_cobranca: tipo })
    });
    toast('Saída OK — ' + data.placa + ' | ' + data.tipo_cobranca + ' | ' + formatarMoeda(data.valor));
    fecharModal('modal-saida');
    carregarAtivosParaSaida();
  } catch (err) { toast(err.message, 'error'); }
});

let todasVagas = [];
let filtroVagasAtual = 'todos';

async function carregarVagas() {
  try {
    todasVagas = await api('/vagas');
    renderVagas(filtroVagasAtual);
  } catch (err) { toast(err.message, 'error'); }
}

function renderVagas(filtro) {
  filtroVagasAtual = filtro || filtroVagasAtual || 'todos';
  let lista = todasVagas;
  if (filtroVagasAtual === 'livre') lista = todasVagas.filter(v => v.status === 'livre');
  if (filtroVagasAtual === 'ocupada') lista = todasVagas.filter(v => v.status === 'ocupada');
  if (filtroVagasAtual === 'preferencial') lista = todasVagas.filter(v => v.tipo === 'preferencial');
  const isGerente = USER && USER.perfil === 'gerente';
  document.getElementById('grid-vagas').innerHTML = lista.map(v => {
    const statusLabel = v.status === 'bloqueada' ? ' · bloqueada' : (v.status === 'reservada' ? ' · reservada' : '');
    let actions = '';
    if (isGerente) {
      actions = '<div class="vaga-actions">' +
        '<button type="button" class="btn btn-ghost btn-sm" onclick="event.stopPropagation();abrirEditarVaga(' + v.id + ')" title="Editar">✎</button>' +
        (v.status !== 'ocupada'
          ? '<button type="button" class="btn btn-ghost btn-sm" onclick="event.stopPropagation();alternarBloqueioVaga(' + v.id + ',\'' + v.status + '\')" title="Bloquear/Liberar">' + (v.status === 'bloqueada' ? '🔓' : '🔒') + '</button>'
          : '') +
        '</div>';
    }
    const clickAttr = (!isGerente && v.status !== 'ocupada')
      ? ' onclick="alternarBloqueioVaga(' + v.id + ',\'' + v.status + '\')" title="Clique para bloquear/liberar" style="cursor:pointer"'
      : '';
    return '<div class="vaga ' + v.status + (v.tipo === 'preferencial' ? ' preferencial' : '') + '"' + clickAttr + '>' +
      '<span class="vaga-num">' + v.numero + '</span>' +
      '<span class="vaga-tipo">' + v.tipo + statusLabel + '</span>' +
      actions +
      '</div>';
  }).join('');
}

document.querySelectorAll('.chip').forEach(btn => {
  btn.addEventListener('click', () => {
    document.querySelectorAll('.chip').forEach(b => b.classList.remove('active'));
    btn.classList.add('active');
    renderVagas(btn.dataset.filtro);
  });
});

let todosVeiculos = [];

function renderVeiculos(lista) {
  const tbody = document.getElementById('tbody-veiculos');
  if (!lista.length) {
    tbody.innerHTML = '<tr><td colspan="7" class="empty">Nenhum veículo encontrado</td></tr>';
    return;
  }
  tbody.innerHTML = lista.map(v => {
    let clienteCell = v.cliente_nome || '—';
    if (v.cliente_nome && v.cliente_plano && v.cliente_plano !== 'avulso') {
      if (v.coberto_plano) {
        clienteCell += ' <span class="badge">' + v.cliente_plano + '</span>';
      } else {
        clienteCell += ' <span class="badge" style="background:#fef3c7;color:#92400e">avulso (extra)</span>';
      }
    }
    return `
    <tr>
      <td><span class="placa">${v.placa}</span></td>
      <td>${[v.marca, v.modelo].filter(Boolean).join(' ') || '—'}</td>
      <td>${v.cor || '—'}</td>
      <td>${v.ano || '—'}</td>
      <td>${v.tipo}</td>
      <td>${v.tamanho || '—'}</td>
      <td>${clienteCell}</td>
    </tr>`;
  }).join('');
}

function filtrarVeiculos() {
  const q = (document.getElementById('filtro-veiculos')?.value || '').trim().toLowerCase();
  if (!q) {
    renderVeiculos(todosVeiculos);
    return;
  }
  const filtrados = todosVeiculos.filter(v => {
    const texto = [
      v.placa, v.marca, v.modelo, v.cor, v.tipo, v.tamanho,
      v.ano, v.cliente_nome, v.cliente_plano
    ].filter(Boolean).join(' ').toLowerCase();
    return texto.includes(q);
  });
  renderVeiculos(filtrados);
}

async function carregarVeiculos() {
  try {
    todosVeiculos = await api('/veiculos');
    const input = document.getElementById('filtro-veiculos');
    if (input && input.value.trim()) filtrarVeiculos();
    else renderVeiculos(todosVeiculos);
  } catch (err) { toast(err.message, 'error'); }
}

function limparClienteVeiculo() {
  document.getElementById('vei-cliente-id').value = '';
  document.getElementById('vei-cliente-busca').value = '';
  document.getElementById('vei-cliente-busca').style.display = '';
  document.getElementById('vei-cliente-selecionado').style.display = 'none';
  document.getElementById('vei-cliente-resultados').style.display = 'none';
  document.getElementById('vei-cliente-resultados').innerHTML = '';
}

function selecionarClienteVeiculo(id, nome, extra) {
  document.getElementById('vei-cliente-id').value = id;
  document.getElementById('vei-cliente-sel-nome').textContent = nome + (extra ? ' · ' + extra : '');
  document.getElementById('vei-cliente-selecionado').style.display = 'flex';
  document.getElementById('vei-cliente-busca').style.display = 'none';
  document.getElementById('vei-cliente-busca').value = '';
  document.getElementById('vei-cliente-resultados').style.display = 'none';
  document.getElementById('vei-cliente-resultados').innerHTML = '';
}

let _veiBuscaTimer = null;
async function buscarClientesVeiculo(termo) {
  const box = document.getElementById('vei-cliente-resultados');
  termo = (termo || '').trim();
  if (termo.length < 1) {
    box.style.display = 'none';
    box.innerHTML = '';
    return;
  }
  try {
    const lista = await api('/clientes/busca?q=' + encodeURIComponent(termo));
    if (!lista.length) {
      box.innerHTML = '<div class="cliente-busca-item" style="cursor:default;color:#64748b">Nenhum cliente encontrado</div>';
      box.style.display = 'block';
      return;
    }
    box.innerHTML = lista.map(c => {
      const extra = [c.cpf_cnpj, c.plano && c.plano !== 'avulso' ? c.plano + (c.nivel ? '/' + c.nivel : '') : null].filter(Boolean).join(' · ');
      const nomeSafe = String(c.nome || '').replace(/\\/g, '\\\\').replace(/'/g, "\\'");
      const extraSafe = String(extra || '').replace(/\\/g, '\\\\').replace(/'/g, "\\'");
      return '<div class="cliente-busca-item" onclick="selecionarClienteVeiculo(' + c.id + ', \'' + nomeSafe + '\', \'' + extraSafe + '\')">' +
        '<strong>' + c.nome + '</strong>' +
        (extra ? '<small>' + extra + '</small>' : '') +
        '</div>';
    }).join('');
    box.style.display = 'block';
  } catch (err) {
    box.style.display = 'none';
  }
}

function abrirModalVeiculo() {
  document.getElementById('form-veiculo').reset();
  limparClienteVeiculo();
  document.getElementById('modal-veiculo').classList.add('open');
  setTimeout(() => document.getElementById('vei-placa').focus(), 50);
}

document.getElementById('form-veiculo').addEventListener('submit', async (e) => {
  e.preventDefault();
  try {
    const data = await api('/veiculos', {
      method: 'POST',
      body: JSON.stringify({
        placa: document.getElementById('vei-placa').value.trim(),
        marca: document.getElementById('vei-marca').value.trim(),
        modelo: document.getElementById('vei-modelo').value.trim(),
        cor: document.getElementById('vei-cor').value.trim(),
        ano: document.getElementById('vei-ano').value || null,
        tipo: document.getElementById('vei-tipo').value,
        tamanho: document.getElementById('vei-tamanho').value,
        cliente_id: document.getElementById('vei-cliente-id').value || null
      })
    });
    if (data.aviso) toast(data.aviso, 'error');
    else toast('Veículo cadastrado');
    fecharModal('modal-veiculo');
    carregarVeiculos();
  } catch (err) { toast(err.message, 'error'); }
});

const veiClienteBusca = document.getElementById('vei-cliente-busca');
if (veiClienteBusca) {
  veiClienteBusca.addEventListener('input', () => {
    clearTimeout(_veiBuscaTimer);
    _veiBuscaTimer = setTimeout(() => buscarClientesVeiculo(veiClienteBusca.value), 280);
  });
  veiClienteBusca.addEventListener('focus', () => {
    if (veiClienteBusca.value.trim()) buscarClientesVeiculo(veiClienteBusca.value);
  });
}
const veiClienteLimpar = document.getElementById('vei-cliente-limpar');
if (veiClienteLimpar) veiClienteLimpar.addEventListener('click', limparClienteVeiculo);
document.addEventListener('click', (e) => {
  const wrap = document.querySelector('.cliente-busca-wrap');
  if (wrap && !wrap.contains(e.target)) {
    const box = document.getElementById('vei-cliente-resultados');
    if (box) box.style.display = 'none';
  }
});

let todosClientes = [];

function renderClientes(lista) {
  const tbody = document.getElementById('tbody-clientes');
  if (!lista.length) {
    tbody.innerHTML = '<tr><td colspan="7" class="empty">Nenhum cliente encontrado</td></tr>';
    return;
  }
  tbody.innerHTML = lista.map(c => {
    const lav = (c.lavagens_mes_limite > 0)
      ? (c.lavagens_mes_usadas + '/' + c.lavagens_mes_limite)
      : '—';
    const valido = c.plano_valido;
    let planoBadge = '<span class="badge" style="background:#f1f5f9;color:#475569">avulso</span>';
    let validadeHtml = '';
    if (c.plano && c.plano !== 'avulso') {
      let estilo = '';
      let extra = '';
      if (!valido || (c.dias_restantes != null && c.dias_restantes < 0)) {
        estilo = 'background:#fee2e2;color:#991b1b';
        extra = ' (vencido)';
      } else if (c.dias_restantes != null && c.dias_restantes <= 7) {
        estilo = 'background:#fef3c7;color:#92400e';
        extra = c.dias_restantes === 0 ? ' (hoje)' : ' (' + c.dias_restantes + 'd)';
      }
      planoBadge = `<span class="badge" style="${estilo}">${c.plano}${c.nivel ? ' · ' + c.nivel : ''}${extra}</span>`;
      if (c.plano_validade) {
        validadeHtml = '<br><small style="color:#64748b">até ' + c.plano_validade + '</small>';
      }
    }
    return `
    <tr>
      <td><strong>${c.nome}</strong></td>
      <td>${c.cpf_cnpj || '—'}</td>
      <td>${c.telefone || '—'}</td>
      <td>${planoBadge}${validadeHtml}</td>
      <td>${c.qtd_veiculos || 0}/${c.max_veiculos == 99 ? '∞' : c.max_veiculos}${(c.veiculos_extras > 0) ? ' <small style="color:#d97706">+' + c.veiculos_extras + ' avulso</small>' : ''}</td>
      <td>${lav}</td>
      <td style="white-space:nowrap">
        <button class="btn btn-ghost btn-sm" onclick="abrirEditarCliente(${c.id})">Editar</button>
        <button class="btn btn-ghost btn-sm" onclick="abrirGerenciarPlano(${c.id})" style="color:#059669">Plano</button>
        ${(c.lavagens_mes_limite > 0) ? '<button class="btn btn-ghost btn-sm" onclick="abrirLavagens(' + c.id + ')">Lavagem</button>' : ''}
        <button class="btn btn-ghost btn-sm only-gerente-action" style="color:#dc2626" onclick="removerCliente(${c.id}, '${(c.nome || '').replace(/'/g, "\\'")}')">Remover</button>
      </td>
    </tr>`;
  }).join('');
  if (typeof aplicarPermissoes === 'function') aplicarPermissoes();
}

function filtrarClientes() {
  const q = (document.getElementById('filtro-clientes')?.value || '').trim().toLowerCase();
  if (!q) {
    renderClientes(todosClientes);
    return;
  }
  const filtrados = todosClientes.filter(c => {
    const texto = [
      c.nome, c.cpf_cnpj, c.telefone, c.email, c.plano, c.nivel, c.tipo
    ].filter(Boolean).join(' ').toLowerCase();
    return texto.includes(q);
  });
  renderClientes(filtrados);
}

async function carregarClientes() {
  try {
    todosClientes = await api('/clientes');
    const input = document.getElementById('filtro-clientes');
    if (input && input.value.trim()) filtrarClientes();
    else renderClientes(todosClientes);
  } catch (err) { toast(err.message, 'error'); }
}

function abrirModalCliente() {
  document.getElementById('form-cliente').reset();
  const cn = document.getElementById('campo-nivel');
  if (cn) cn.style.display = 'none';
  const pp = document.getElementById('cli-plano-preco');
  if (pp) { pp.style.display = 'none'; pp.textContent = ''; }
  document.getElementById('modal-cliente').classList.add('open');
}

function planoPago(plano) {
  return plano === 'mensal' || plano === 'anual';
}

async function atualizarPrecoPreviewCadastro() {
  const plano = document.getElementById('cli-plano').value;
  const nivel = document.getElementById('cli-nivel').value || 'sem';
  const box = document.getElementById('cli-plano-preco');
  const show = planoPago(plano);
  document.getElementById('campo-nivel').style.display = show ? 'block' : 'none';
  if (!show) {
    box.style.display = 'none';
    box.textContent = '';
    return;
  }
  try {
    const p = await api('/planos/preco?plano=' + plano + '&nivel=' + nivel);
    box.style.display = 'block';
    box.innerHTML = 'Ao salvar será cobrado <strong>' + formatarMoeda(p.valor) + '</strong> (' + p.nivel_label + ', ' + p.dias + ' dias).';
  } catch (err) {
    box.style.display = 'block';
    box.textContent = err.message || 'Sem preço cadastrado para este plano/nível.';
  }
}

document.getElementById('cli-plano').addEventListener('change', atualizarPrecoPreviewCadastro);
document.getElementById('cli-nivel').addEventListener('change', atualizarPrecoPreviewCadastro);

document.getElementById('form-cliente').addEventListener('submit', async (e) => {
  e.preventDefault();
  try {
    const plano = document.getElementById('cli-plano').value;
    if (planoPago(plano)) {
      const nivel = document.getElementById('cli-nivel').value || 'sem';
      let valorTxt = '';
      try {
        const p = await api('/planos/preco?plano=' + plano + '&nivel=' + nivel);
        valorTxt = ' Valor: ' + formatarMoeda(p.valor) + '.';
      } catch (_) {}
      if (!confirm('Confirmar assinatura do plano ' + plano + '/' + nivel + '?' + valorTxt + '\nO pagamento será registrado agora.')) {
        return;
      }
    }
    const data = await api('/clientes', {
      method: 'POST',
      body: JSON.stringify({
        nome: document.getElementById('cli-nome').value.trim(),
        cpf_cnpj: document.getElementById('cli-cpf').value.trim(),
        telefone: document.getElementById('cli-telefone').value.trim(),
        email: document.getElementById('cli-email').value.trim(),
        tipo: document.getElementById('cli-tipo').value,
        plano: plano,
        nivel: document.getElementById('cli-nivel').value
      })
    });
    if (data.pagamento_plano && data.pagamento_plano.cobrado) {
      toast(data.pagamento_plano.mensagem);
    } else {
      toast('Cliente cadastrado (avulso)');
    }
    fecharModal('modal-cliente');
    carregarClientes();
  } catch (err) { toast(err.message, 'error'); }
});

let clienteEditandoId = null;
let clienteLavagemId = null;
let clientePlanoAtual = null;

async function abrirEditarCliente(id) {
  try {
    const c = await api('/clientes/' + id);
    clienteEditandoId = id;
    document.getElementById('edit-cli-id').value = id;
    document.getElementById('edit-cli-nome').value = c.nome || '';
    document.getElementById('edit-cli-cpf').value = c.cpf_cnpj || '';
    document.getElementById('edit-cli-telefone').value = c.telefone || '';
    document.getElementById('edit-cli-email').value = c.email || '';
    document.getElementById('edit-cli-tipo').value = c.tipo || 'PF';
    document.getElementById('modal-editar-cliente').classList.add('open');
  } catch (err) { toast(err.message, 'error'); }
}

document.getElementById('form-editar-cliente').addEventListener('submit', async (e) => {
  e.preventDefault();
  const id = document.getElementById('edit-cli-id').value;
  try {
    await api('/clientes/' + id, {
      method: 'PUT',
      body: JSON.stringify({
        nome: document.getElementById('edit-cli-nome').value.trim(),
        cpf_cnpj: document.getElementById('edit-cli-cpf').value.trim(),
        telefone: document.getElementById('edit-cli-telefone').value.trim(),
        email: document.getElementById('edit-cli-email').value.trim(),
        tipo: document.getElementById('edit-cli-tipo').value
      })
    });
    toast('Dados do cliente atualizados (sem cobrança de plano)');
    fecharModal('modal-editar-cliente');
    carregarClientes();
  } catch (err) { toast(err.message, 'error'); }
});

/* ========== Gerenciar Plano (pagamento separado) ========== */

async function abrirGerenciarPlano(id) {
  try {
    const c = await api('/clientes/' + id);
    clientePlanoAtual = c;
    document.getElementById('plano-cli-id').value = id;

    const valido = c.plano_valido;
    let statusHtml = '<strong>' + (c.nome || '') + '</strong><br>';
    if (!c.plano || c.plano === 'avulso') {
      statusHtml += 'Situação atual: <strong>avulso</strong> (paga por uso na saída)';
    } else {
      statusHtml += 'Plano atual: <strong>' + c.plano + (c.nivel ? ' · ' + c.nivel : '') + '</strong>';
      if (c.nivel_info) statusHtml += ' — ' + c.nivel_info.descricao;
      statusHtml += '<br>Validade: <strong>' + (c.plano_validade || '—') + '</strong>';
      if (c.dias_restantes != null) {
        if (c.dias_restantes < 0) {
          statusHtml += ' <span style="color:#dc2626;font-weight:600">(vencido há ' + Math.abs(c.dias_restantes) + ' dia' + (Math.abs(c.dias_restantes) === 1 ? '' : 's') + ')</span>';
        } else if (c.dias_restantes === 0) {
          statusHtml += ' <span style="color:#d97706;font-weight:600">(vence hoje)</span>';
        } else if (c.dias_restantes <= 7) {
          statusHtml += ' <span style="color:#d97706;font-weight:600">(' + c.dias_restantes + ' dia' + (c.dias_restantes === 1 ? '' : 's') + ' restante' + (c.dias_restantes === 1 ? '' : 's') + ')</span>';
        } else {
          statusHtml += ' <span style="color:#059669">(' + c.dias_restantes + ' dias restantes)</span>';
        }
      } else {
        statusHtml += valido
          ? ' <span style="color:#059669">(válido)</span>'
          : ' <span style="color:#dc2626">(vencido)</span>';
      }
      if (c.valor_renovacao != null) {
        statusHtml += '<br>Valor da renovação: <strong>' + formatarMoeda(c.valor_renovacao) + '</strong>';
      }
    }
    document.getElementById('plano-atual-info').innerHTML = statusHtml;

    document.getElementById('plano-select').value = c.plano || 'avulso';
    document.getElementById('plano-nivel').value = c.nivel || 'sem';
    document.getElementById('plano-historico-box').style.display = 'none';

    const btnRenovar = document.getElementById('btn-plano-renovar');
    if (c.plano && c.plano !== 'avulso') {
      btnRenovar.style.display = 'inline-flex';
      const preco = c.valor_renovacao != null ? ' · ' + formatarMoeda(c.valor_renovacao) : '';
      btnRenovar.textContent = 'Renovar ' + c.plano + (c.nivel ? '/' + c.nivel : '') + preco;
    } else {
      btnRenovar.style.display = 'none';
    }

    await atualizarPrecoPreviewPlano();
    document.getElementById('modal-plano').classList.add('open');
  } catch (err) { toast(err.message, 'error'); }
}

async function atualizarPrecoPreviewPlano() {
  const plano = document.getElementById('plano-select').value;
  const nivel = document.getElementById('plano-nivel').value || 'sem';
  const box = document.getElementById('plano-preco-preview');
  const showNivel = planoPago(plano);
  document.getElementById('plano-campo-nivel').style.display = showNivel ? 'block' : 'none';

  if (!showNivel) {
    box.style.display = 'block';
    box.style.background = '#f1f5f9';
    box.style.color = '#475569';
    box.innerHTML = 'Cancelar o plano (voltar para avulso) <strong>não gera cobrança</strong>.';
    return;
  }

  const atual = clientePlanoAtual;
  const mesmo = atual && atual.plano === plano && (atual.nivel || 'sem') === nivel;

  try {
    const p = await api('/planos/preco?plano=' + plano + '&nivel=' + nivel);
    box.style.display = 'block';
    box.style.background = '#ecfdf5';
    box.style.color = '#065f46';
    if (mesmo) {
      box.innerHTML = 'Já está neste plano. Use <strong>Renovar</strong> para estender a validade e cobrar '
        + formatarMoeda(p.valor) + ', ou escolha outro plano/nível para trocar.';
    } else {
      box.innerHTML = 'Valor a cobrar ao confirmar: <strong>' + formatarMoeda(p.valor) + '</strong> · '
        + p.nivel_label + ' · ' + p.dias + ' dias de validade.';
    }
  } catch (err) {
    box.style.display = 'block';
    box.style.background = '#fef2f2';
    box.style.color = '#991b1b';
    box.textContent = err.message || 'Sem preço cadastrado para este plano/nível.';
  }
}

document.getElementById('plano-select').addEventListener('change', atualizarPrecoPreviewPlano);
document.getElementById('plano-nivel').addEventListener('change', atualizarPrecoPreviewPlano);

document.getElementById('btn-plano-confirmar').addEventListener('click', async () => {
  const id = document.getElementById('plano-cli-id').value;
  const plano = document.getElementById('plano-select').value;
  const nivel = document.getElementById('plano-nivel').value || 'sem';
  const atual = clientePlanoAtual;
  const mesmo = atual && atual.plano === plano && (atual.nivel || 'sem') === nivel;

  if (mesmo && plano !== 'avulso') {
    toast('Já está neste plano. Use "Renovar" para estender e cobrar, ou escolha outro plano.', 'error');
    return;
  }

  if (planoPago(plano)) {
    let valorTxt = '';
    try {
      const p = await api('/planos/preco?plano=' + plano + '&nivel=' + nivel);
      valorTxt = ' Valor: ' + formatarMoeda(p.valor) + '.';
    } catch (_) {}
    if (!confirm('Confirmar plano ' + plano + '/' + nivel + '?' + valorTxt + '\\nO pagamento será registrado agora.')) {
      return;
    }
  } else if (atual && atual.plano && atual.plano !== 'avulso') {
    if (!confirm('Cancelar o plano e voltar para avulso? Não há cobrança.')) return;
  }

  try {
    const data = await api('/clientes/' + id + '/plano', {
      method: 'PUT',
      body: JSON.stringify({ plano, nivel })
    });
    if (data.pagamento_plano && data.pagamento_plano.mensagem) {
      toast(data.pagamento_plano.mensagem);
    } else {
      toast('Plano atualizado');
    }
    fecharModal('modal-plano');
    carregarClientes();
  } catch (err) { toast(err.message, 'error'); }
});

document.getElementById('btn-plano-renovar').addEventListener('click', async () => {
  const id = document.getElementById('plano-cli-id').value;
  const atual = clientePlanoAtual;
  if (!atual || !atual.plano || atual.plano === 'avulso') return;
  const plano = atual.plano;
  const nivel = atual.nivel || 'sem';
  let valorTxt = '';
  try {
    const p = await api('/planos/preco?plano=' + plano + '&nivel=' + nivel);
    valorTxt = formatarMoeda(p.valor);
  } catch (_) { valorTxt = '?'; }
  if (!confirm('Renovar ' + plano + '/' + nivel + ' por ' + valorTxt + '?\\nA validade será estendida a partir do fim atual (ou de hoje se já venceu).')) {
    return;
  }
  try {
    const data = await api('/clientes/' + id + '/plano', {
      method: 'PUT',
      body: JSON.stringify({ plano, nivel, renovar: true })
    });
    if (data.pagamento_plano) toast(data.pagamento_plano.mensagem);
    else toast('Plano renovado');
    fecharModal('modal-plano');
    carregarClientes();
  } catch (err) { toast(err.message, 'error'); }
});

document.getElementById('btn-plano-historico').addEventListener('click', async () => {
  const id = document.getElementById('plano-cli-id').value;
  const box = document.getElementById('plano-historico-box');
  if (box.style.display === 'block') {
    box.style.display = 'none';
    return;
  }
  try {
    const lista = await api('/clientes/' + id + '/pagamentos-plano');
    const tb = document.getElementById('tbody-plano-hist');
    tb.innerHTML = lista.length
      ? lista.map(p => `
        <tr>
          <td>${formatarData(p.data_pagamento)}</td>
          <td>${p.tipo_plano}${p.nivel ? '/' + p.nivel : ''}</td>
          <td><strong>${formatarMoeda(p.valor)}</strong></td>
          <td>${(p.validade_inicio || '—') + ' → ' + (p.validade_fim || '—')}</td>
        </tr>`).join('')
      : '<tr><td colspan="4" class="empty">Nenhum pagamento de plano</td></tr>';
    box.style.display = 'block';
  } catch (err) { toast(err.message, 'error'); }
});

async function removerCliente(id, nome) {
  if (!confirm('Remover cliente "' + nome + '"? Veículos ficam sem vínculo.')) return;
  try {
    await api('/clientes/' + id, { method: 'DELETE' });
    toast('Cliente removido');
    carregarClientes();
  } catch (err) { toast(err.message, 'error'); }
}

async function abrirLavagens(id) {
  clienteLavagemId = id;
  try {
    const data = await api('/clientes/' + id + '/lavagens');
    const c = data.cliente;
    document.getElementById('lavagens-info').innerHTML =
      '<strong>' + c.nome + '</strong> — <span class="badge">' + c.plano + (c.nivel ? ' · ' + c.nivel : '') + '</span><br>' +
      'Lavagens este mês: <strong>' + c.lavagens_mes_usadas + ' / ' + c.lavagens_mes_limite + '</strong>';
    const lista = data.lavagens || [];
    document.getElementById('tbody-lavagens').innerHTML = lista.length
      ? lista.map(l => '<tr><td>' + formatarData(l.data_hora) + '</td><td>' + (l.observacao || '—') + '</td></tr>').join('')
      : '<tr><td colspan="2" class="empty">Nenhuma lavagem registrada</td></tr>';
    document.getElementById('lavagem-obs').value = '';
    document.getElementById('modal-lavagens').classList.add('open');
  } catch (err) { toast(err.message, 'error'); }
}

document.getElementById('btn-reg-lavagem').addEventListener('click', async () => {
  if (!clienteLavagemId) return;
  try {
    const data = await api('/clientes/' + clienteLavagemId + '/lavagens', {
      method: 'POST',
      body: JSON.stringify({ observacao: document.getElementById('lavagem-obs').value.trim() })
    });
    toast(data.mensagem);
    abrirLavagens(clienteLavagemId);
    carregarClientes();
  } catch (err) { toast(err.message, 'error'); }
});

function _btnPreco(p, isGerente) {
  if (!isGerente) return '';
  const descSafe = String(p.descricao || '').replace(/\\/g, '\\\\').replace(/'/g, "\\'");
  return `
    <button class="btn btn-ghost btn-sm" onclick="abrirEditarPreco(${p.id}, '${descSafe}', '${p.tipo_cobranca || ''}', '${p.nivel || ''}', '${p.tipo_veiculo || 'todos'}', ${p.valor})">Editar</button>
    <button class="btn btn-ghost btn-sm" onclick="desativarPreco(${p.id})">Desativar</button>`;
}

async function carregarPrecos() {
  try {
    const precos = await api('/precos');
    const isGerente = USER && USER.perfil === 'gerente';
    const avulsos = precos.filter(p => p.tipo_cobranca === 'hora' || p.tipo_cobranca === 'diaria');
    const planos = precos.filter(p => p.tipo_cobranca === 'mensal' || p.tipo_cobranca === 'anual');

    const tbA = document.getElementById('tbody-precos-avulso');
    tbA.innerHTML = avulsos.length
      ? avulsos.map(p => `
        <tr>
          <td>${p.descricao}</td>
          <td><span class="badge">${p.tipo_cobranca}</span></td>
          <td>${p.tipo_veiculo || 'todos'}</td>
          <td><strong>${formatarMoeda(p.valor)}</strong></td>
          <td style="white-space:nowrap">${_btnPreco(p, isGerente)}</td>
        </tr>`).join('')
      : '<tr><td colspan="5" class="empty">Nenhuma tarifa avulsa</td></tr>';

    const tbP = document.getElementById('tbody-precos-plano');
    tbP.innerHTML = planos.length
      ? planos.map(p => `
        <tr>
          <td>${p.descricao}</td>
          <td><span class="badge">${p.tipo_cobranca}</span></td>
          <td>${p.nivel || '—'}</td>
          <td><strong>${formatarMoeda(p.valor)}</strong></td>
          <td style="white-space:nowrap">${_btnPreco(p, isGerente)}</td>
        </tr>`).join('')
      : '<tr><td colspan="5" class="empty">Nenhum plano cadastrado</td></tr>';

    if (typeof aplicarPermissoes === 'function') aplicarPermissoes();
  } catch (err) { toast(err.message, 'error'); }
}

function abrirModalPreco(modo) {
  document.getElementById('form-preco').reset();
  const titulo = document.getElementById('modal-preco-titulo');
  const tipo = document.getElementById('pre-tipo');
  if (modo === 'plano') {
    titulo.textContent = 'Novo preço de plano';
    tipo.value = 'mensal';
  } else {
    titulo.textContent = 'Nova tarifa avulsa';
    tipo.value = 'hora';
  }
  atualizarCamposPreco();
  document.getElementById('modal-preco').classList.add('open');
}

function atualizarCamposPreco() {
  const tipo = document.getElementById('pre-tipo').value;
  const isPlano = tipo === 'mensal' || tipo === 'anual';
  document.getElementById('pre-campo-nivel').style.display = isPlano ? 'block' : 'none';
  document.getElementById('pre-campo-veiculo').style.display = isPlano ? 'none' : 'block';
  if (isPlano) {
    document.getElementById('pre-veiculo').value = 'todos';
    if (!document.getElementById('pre-nivel').value) document.getElementById('pre-nivel').value = 'sem';
  } else {
    document.getElementById('pre-nivel').value = '';
  }
}

document.getElementById('pre-tipo').addEventListener('change', atualizarCamposPreco);

document.getElementById('form-preco').addEventListener('submit', async (e) => {
  e.preventDefault();
  const tipo = document.getElementById('pre-tipo').value;
  const isPlano = tipo === 'mensal' || tipo === 'anual';
  try {
    await api('/precos', {
      method: 'POST',
      body: JSON.stringify({
        descricao: document.getElementById('pre-desc').value.trim(),
        tipo_cobranca: tipo,
        nivel: isPlano ? (document.getElementById('pre-nivel').value || 'sem') : null,
        tipo_veiculo: isPlano ? 'todos' : document.getElementById('pre-veiculo').value,
        valor: Number(document.getElementById('pre-valor').value)
      })
    });
    toast('Preço cadastrado');
    fecharModal('modal-preco');
    carregarPrecos();
  } catch (err) { toast(err.message, 'error'); }
});

async function desativarPreco(id) {
  if (!confirm('Desativar este preço?')) return;
  try {
    await api('/precos/' + id, { method: 'DELETE' });
    toast('Preço desativado');
    carregarPrecos();
  } catch (err) { toast(err.message, 'error'); }
}

async function carregarRelatorios() {
  try {
    const r = await api('/relatorios/completo');
    const fat = r.faturamento || {};
    document.getElementById('rel-stats').innerHTML =
      '<div class="stat-card"><div class="stat-label">Total hoje</div><div class="stat-value text-primary">' + formatarMoeda(fat.hoje) + '</div>' +
        '<small style="color:#64748b">saídas ' + formatarMoeda(fat.saidas_hoje || 0) + ' · planos ' + formatarMoeda(fat.planos_hoje || 0) + '</small></div>' +
      '<div class="stat-card"><div class="stat-label">Total mês</div><div class="stat-value text-primary">' + formatarMoeda(fat.mes) + '</div>' +
        '<small style="color:#64748b">saídas ' + formatarMoeda(fat.saidas_mes || 0) + ' · planos ' + formatarMoeda(fat.planos_mes || 0) + '</small></div>' +
      '<div class="stat-card"><div class="stat-label">Tempo médio</div><div class="stat-value">' + r.tempo_medio_minutos + ' min</div></div>' +
      '<div class="stat-card"><div class="stat-label">Ocupação</div><div class="stat-value">' + r.ocupacao.ocupadas + '/' + r.ocupacao.total + '</div></div>';

    document.getElementById('tbody-7dias').innerHTML = (r.ultimos_7_dias || []).length
      ? r.ultimos_7_dias.map(d => '<tr><td>' + d.dia + '</td><td>' + d.quantidade + '</td><td>' + formatarMoeda(d.total) + '</td></tr>').join('')
      : '<tr><td colspan="3" class="empty">Sem dados</td></tr>';

    const pags = r.pagamentos_plano_recentes || [];
    const tbPag = document.getElementById('tbody-pag-planos');
    if (tbPag) {
      tbPag.innerHTML = pags.length
        ? pags.map(p => '<tr><td>' + formatarData(p.data_pagamento) + '</td><td>' + (p.cliente_nome || '—') +
            '</td><td>' + p.tipo_plano + (p.nivel ? '/' + p.nivel : '') +
            '</td><td><strong>' + formatarMoeda(p.valor) + '</strong></td><td>' +
            (p.validade_inicio || '—') + ' → ' + (p.validade_fim || '—') +
            '</td><td>' + (p.observacao || '—') + '</td></tr>').join('')
        : '<tr><td colspan="6" class="empty">Nenhum pagamento de plano ainda</td></tr>';
    }

    document.getElementById('tbody-ranking').innerHTML = (r.ranking_placas || []).length
      ? r.ranking_placas.map(p => '<tr><td><span class="placa">' + p.placa + '</span></td><td>' + p.visitas + '</td><td>' + formatarMoeda(p.total_pago) + '</td></tr>').join('')
      : '<tr><td colspan="3" class="empty">Sem dados</td></tr>';
    document.getElementById('tbody-vagas-uso').innerHTML = (r.vagas_mais_usadas || []).length
      ? r.vagas_mais_usadas.map(v => '<tr><td>' + v.numero + '</td><td>' + v.tipo + '</td><td>' + v.usos + '</td></tr>').join('')
      : '<tr><td colspan="3" class="empty">Sem dados</td></tr>';
  } catch (err) { toast(err.message, 'error'); }
}

async function carregarHistorico() {
  try {
    const historico = await api('/estacionamentos/historico');
    document.getElementById('tbody-historico').innerHTML = historico.length ? historico.map(e => `
      <tr>
        <td><span class="placa">${e.placa}</span></td>
        <td>${[e.marca, e.modelo].filter(Boolean).join(' ') || '—'}</td>
        <td>${e.vaga_numero}</td>
        <td>${formatarData(e.data_hora_entrada)}</td>
        <td>${formatarData(e.data_hora_saida)}</td>
        <td><span class="badge">${e.tipo_cobranca || 'hora'}</span></td>
        <td><strong>${formatarMoeda(e.valor_calculado)}</strong></td>
      </tr>
    `).join('') : '<tr><td colspan="7" class="empty">Nenhum registro</td></tr>';
  } catch (err) { toast(err.message, 'error'); }
}

function fecharModal(id) { document.getElementById(id).classList.remove('open'); }
document.querySelectorAll('.modal').forEach(m => {
  m.addEventListener('click', e => { if (e.target === m) m.classList.remove('open'); });
});



// ============================================
// CRIAR / EDITAR VAGA
// ============================================
function abrirModalVaga() {
  document.getElementById('form-vaga').reset();
  document.getElementById('vaga-id').value = '';
  document.getElementById('vaga-setor').value = 'A';
  const sel = document.getElementById('vaga-status');
  sel.disabled = false;
  Array.from(sel.options).forEach(o => {
    if (o.value === 'ocupada') o.remove();
  });
  sel.value = 'livre';
  document.getElementById('modal-vaga-titulo').textContent = 'Nova Vaga';
  document.getElementById('btn-salvar-vaga').textContent = 'Criar Vaga';
  const btnExcluir = document.getElementById('btn-excluir-vaga');
  if (btnExcluir) btnExcluir.style.display = 'none';
  document.getElementById('modal-vaga').classList.add('open');
}

function abrirEditarVaga(id) {
  const v = todasVagas.find(x => x.id === id);
  if (!v) { toast('Vaga não encontrada', 'error'); return; }
  document.getElementById('vaga-id').value = v.id;
  document.getElementById('vaga-numero').value = v.numero || '';
  document.getElementById('vaga-setor').value = v.setor || 'A';
  document.getElementById('vaga-tipo').value = v.tipo || 'normal';
  // Garantir opção ocupada no select se necessário (somente leitura visual)
  const sel = document.getElementById('vaga-status');
  if (v.status === 'ocupada' && !Array.from(sel.options).some(o => o.value === 'ocupada')) {
    const opt = document.createElement('option');
    opt.value = 'ocupada';
    opt.textContent = 'Ocupada';
    sel.appendChild(opt);
  }
  sel.value = v.status || 'livre';
  if (v.status === 'ocupada') sel.disabled = true;
  else sel.disabled = false;
  document.getElementById('modal-vaga-titulo').textContent = 'Editar Vaga ' + v.numero;
  document.getElementById('btn-salvar-vaga').textContent = 'Salvar';
  const btnExcluir = document.getElementById('btn-excluir-vaga');
  if (btnExcluir) {
    btnExcluir.style.display = (USER && USER.perfil === 'gerente' && v.status !== 'ocupada') ? '' : 'none';
  }
  document.getElementById('modal-vaga').classList.add('open');
}

document.getElementById('form-vaga').addEventListener('submit', async (e) => {
  e.preventDefault();
  const id = document.getElementById('vaga-id').value;
  const body = {
    numero: document.getElementById('vaga-numero').value.trim(),
    setor: document.getElementById('vaga-setor').value.trim() || 'A',
    tipo: document.getElementById('vaga-tipo').value,
    status: document.getElementById('vaga-status').value
  };
  try {
    if (id) {
      await api('/vagas/' + id, { method: 'PUT', body: JSON.stringify(body) });
      toast('Vaga atualizada');
    } else {
      await api('/vagas', { method: 'POST', body: JSON.stringify(body) });
      toast('Vaga criada com sucesso');
    }
    document.getElementById('vaga-status').disabled = false;
    fecharModal('modal-vaga');
    carregarVagas();
  } catch (err) { toast(err.message, 'error'); }
});

async function excluirVagaAtual() {
  const id = document.getElementById('vaga-id').value;
  if (!id) return;
  const num = document.getElementById('vaga-numero').value;
  if (!confirm('Excluir a vaga "' + num + '"?')) return;
  try {
    await api('/vagas/' + id, { method: 'DELETE' });
    toast('Vaga removida');
    fecharModal('modal-vaga');
    carregarVagas();
  } catch (err) { toast(err.message, 'error'); }
}

async function alternarBloqueioVaga(id, statusAtual) {
  const novo = statusAtual === 'bloqueada' ? 'livre' : 'bloqueada';
  try {
    await api('/vagas/' + id + '/status', {
      method: 'PUT',
      body: JSON.stringify({ status: novo })
    });
    toast(novo === 'bloqueada' ? 'Vaga bloqueada' : 'Vaga liberada');
    carregarVagas();
  } catch (err) { toast(err.message, 'error'); }
}

// ============================================
// BUSCA GLOBAL
// ============================================
async function executarBusca(termo) {
  termo = (termo || '').trim();
  if (!termo) { toast('Digite algo para buscar', 'error'); return; }

  // Ir para página de busca
  document.querySelectorAll('.nav-item').forEach(b => b.classList.remove('active'));
  document.querySelectorAll('.page').forEach(p => p.classList.remove('active'));
  const navBusca = document.querySelector('.nav-item[data-page="busca"]');
  if (navBusca) navBusca.classList.add('active');
  document.getElementById('busca').classList.add('active');
  document.getElementById('page-title').textContent = 'Pesquisa';
  document.getElementById('busca-termo').value = termo;

  const box = document.getElementById('busca-resultados');
  box.innerHTML = '<div class="card"><div style="padding:24px;text-align:center;color:#64748b">Buscando...</div></div>';

  try {
    const r = await api('/busca?q=' + encodeURIComponent(termo));
    if (!r.total) {
      box.innerHTML = '<div class="card"><div style="padding:24px;text-align:center;color:#64748b">Nenhum resultado para "<strong>' + termo + '</strong>"</div></div>';
      return;
    }

    let html = '';

    if (r.clientes.length) {
      html += '<div class="card" style="margin-bottom:16px"><div class="card-header"><h2>Clientes (' + r.clientes.length + ')</h2></div><div class="table-wrap"><table><thead><tr><th>Nome</th><th>CPF/CNPJ</th><th>Telefone</th><th>Plano</th></tr></thead><tbody>';
      html += r.clientes.map(c => '<tr><td><strong>' + c.nome + '</strong></td><td>' + (c.cpf_cnpj||'—') + '</td><td>' + (c.telefone||'—') + '</td><td><span class="badge">' + (c.plano||'avulso') + '</span></td></tr>').join('');
      html += '</tbody></table></div></div>';
    }

    if (r.veiculos.length) {
      html += '<div class="card" style="margin-bottom:16px"><div class="card-header"><h2>Veículos (' + r.veiculos.length + ')</h2></div><div class="table-wrap"><table><thead><tr><th>Placa</th><th>Marca/Modelo</th><th>Cor</th><th>Tipo</th><th>Cliente</th></tr></thead><tbody>';
      html += r.veiculos.map(v => '<tr><td><span class="placa">' + v.placa + '</span></td><td>' + [v.marca,v.modelo].filter(Boolean).join(' ') + '</td><td>' + (v.cor||'—') + '</td><td>' + v.tipo + '</td><td>' + (v.cliente_nome||'—') + '</td></tr>').join('');
      html += '</tbody></table></div></div>';
    }

    if (r.vagas.length) {
      html += '<div class="card" style="margin-bottom:16px"><div class="card-header"><h2>Vagas (' + r.vagas.length + ')</h2></div><div class="table-wrap"><table><thead><tr><th>Número</th><th>Tipo</th><th>Status</th><th>Setor</th></tr></thead><tbody>';
      html += r.vagas.map(v => '<tr><td><strong>' + v.numero + '</strong></td><td>' + v.tipo + '</td><td>' + v.status + '</td><td>' + v.setor + '</td></tr>').join('');
      html += '</tbody></table></div></div>';
    }

    if (r.historico.length) {
      html += '<div class="card" style="margin-bottom:16px"><div class="card-header"><h2>Movimentações (' + r.historico.length + ')</h2></div><div class="table-wrap"><table><thead><tr><th>Placa</th><th>Vaga</th><th>Entrada</th><th>Saída</th><th>Status</th><th>Valor</th></tr></thead><tbody>';
      html += r.historico.map(e => '<tr><td><span class="placa">' + e.placa + '</span></td><td>' + e.vaga_numero + '</td><td>' + formatarData(e.data_hora_entrada) + '</td><td>' + formatarData(e.data_hora_saida) + '</td><td>' + e.status + '</td><td>' + formatarMoeda(e.valor_calculado) + '</td></tr>').join('');
      html += '</tbody></table></div></div>';
    }

    box.innerHTML = html;
  } catch (err) {
    box.innerHTML = '';
    toast(err.message, 'error');
  }
}

document.getElementById('btn-busca').addEventListener('click', () => {
  executarBusca(document.getElementById('busca-termo').value);
});
document.getElementById('busca-termo').addEventListener('keydown', (e) => {
  if (e.key === 'Enter') executarBusca(document.getElementById('busca-termo').value);
});
document.getElementById('btn-busca-rapida').addEventListener('click', () => {
  executarBusca(document.getElementById('busca-rapida').value);
});
document.getElementById('busca-rapida').addEventListener('keydown', (e) => {
  if (e.key === 'Enter') executarBusca(document.getElementById('busca-rapida').value);
});






// ============================================
// EDITAR PREÇO
// ============================================
function abrirEditarPreco(id, desc, tipo, nivel, veiculo, valor) {
  document.getElementById('edit-pre-id').value = id;
  document.getElementById('edit-pre-desc').value = desc || '';
  document.getElementById('edit-pre-tipo').value = tipo || '';
  document.getElementById('edit-pre-nivel').value = nivel || '—';
  document.getElementById('edit-pre-veiculo').value = veiculo || 'todos';
  document.getElementById('edit-pre-valor').value = valor;
  document.getElementById('modal-editar-preco').classList.add('open');
}

const formEditarPreco = document.getElementById('form-editar-preco');
if (formEditarPreco) formEditarPreco.addEventListener('submit', async (e) => {
  e.preventDefault();
  const id = document.getElementById('edit-pre-id').value;
  try {
    await api('/precos/' + id, {
      method: 'PUT',
      body: JSON.stringify({
        descricao: document.getElementById('edit-pre-desc').value.trim(),
        tipo_veiculo: document.getElementById('edit-pre-veiculo').value,
        valor: Number(document.getElementById('edit-pre-valor').value)
      })
    });
    toast('Preço atualizado');
    fecharModal('modal-editar-preco');
    carregarPrecos();
  } catch (err) { toast(err.message, 'error'); }
});

// ============================================
// USUÁRIOS (gerente)
// ============================================
async function carregarUsuarios() {
  try {
    const lista = await api('/usuarios');
    document.getElementById('tbody-usuarios').innerHTML = lista.length ? lista.map(u => {
      const nomeSafe = String(u.nome || '').replace(/'/g, "\\'");
      return `
      <tr>
        <td><strong>${u.nome}</strong></td>
        <td>${u.login}</td>
        <td><span class="badge">${u.perfil}</span></td>
        <td>${u.ativo ? 'Ativo' : 'Inativo'}</td>
        <td>${formatarData(u.criado_em)}</td>
        <td style="white-space:nowrap">
          <button class="btn btn-ghost btn-sm" onclick="abrirEditarUsuario(${u.id}, '${nomeSafe}', '${u.login}', '${u.perfil}', ${u.ativo ? 1 : 0})">Editar</button>
          <button class="btn btn-ghost btn-sm" style="color:#dc2626" onclick="removerUsuario(${u.id}, '${nomeSafe}')">Remover</button>
        </td>
      </tr>`;
    }).join('') : '<tr><td colspan="6" class="empty">Nenhum usuário</td></tr>';
  } catch (err) { toast(err.message, 'error'); }
}

function abrirModalUsuario() {
  document.getElementById('form-usuario').reset();
  document.getElementById('usr-id').value = '';
  document.getElementById('modal-usuario-titulo').textContent = 'Novo Usuário';
  document.getElementById('usr-login').disabled = false;
  document.getElementById('usr-senha').required = true;
  document.getElementById('usr-senha-hint').textContent = '*';
  document.getElementById('campo-usr-ativo').style.display = 'none';
  document.getElementById('modal-usuario').classList.add('open');
}

function abrirEditarUsuario(id, nome, login, perfil, ativo) {
  document.getElementById('usr-id').value = id;
  document.getElementById('usr-nome').value = nome || '';
  document.getElementById('usr-login').value = login || '';
  document.getElementById('usr-login').disabled = true;
  document.getElementById('usr-perfil').value = perfil || 'funcionario';
  document.getElementById('usr-senha').value = '';
  document.getElementById('usr-senha').required = false;
  document.getElementById('usr-senha-hint').textContent = '(deixe em branco para manter)';
  document.getElementById('usr-ativo').value = String(ativo);
  document.getElementById('campo-usr-ativo').style.display = 'block';
  document.getElementById('modal-usuario-titulo').textContent = 'Editar Usuário';
  document.getElementById('modal-usuario').classList.add('open');
}

const formUsuario = document.getElementById('form-usuario');
if (formUsuario) formUsuario.addEventListener('submit', async (e) => {
  e.preventDefault();
  const id = document.getElementById('usr-id').value;
  try {
    if (id) {
      const body = {
        nome: document.getElementById('usr-nome').value.trim(),
        perfil: document.getElementById('usr-perfil').value,
        ativo: Number(document.getElementById('usr-ativo').value)
      };
      const senha = document.getElementById('usr-senha').value;
      if (senha) body.senha = senha;
      await api('/usuarios/' + id, { method: 'PUT', body: JSON.stringify(body) });
      toast('Usuário atualizado');
    } else {
      await api('/usuarios', {
        method: 'POST',
        body: JSON.stringify({
          nome: document.getElementById('usr-nome').value.trim(),
          login: document.getElementById('usr-login').value.trim(),
          senha: document.getElementById('usr-senha').value,
          perfil: document.getElementById('usr-perfil').value
        })
      });
      toast('Usuário criado');
    }
    fecharModal('modal-usuario');
    carregarUsuarios();
  } catch (err) { toast(err.message, 'error'); }
});

async function removerUsuario(id, nome) {
  if (!confirm('Remover usuário "' + nome + '"?')) return;
  try {
    await api('/usuarios/' + id, { method: 'DELETE' });
    toast('Usuário removido');
    carregarUsuarios();
  } catch (err) { toast(err.message, 'error'); }
}

// Filtros de busca em veículos e clientes
const filtroVeiculos = document.getElementById('filtro-veiculos');
if (filtroVeiculos) {
  filtroVeiculos.addEventListener('input', () => filtrarVeiculos());
}
const filtroClientes = document.getElementById('filtro-clientes');
if (filtroClientes) {
  filtroClientes.addEventListener('input', () => filtrarClientes());
}

// Boot
tentarSessao();
