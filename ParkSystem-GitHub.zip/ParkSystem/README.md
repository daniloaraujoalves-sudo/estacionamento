# ParkSystem

Sistema de gestão de estacionamento com entrada, saída, planos, vagas e relatórios.

[![Python](https://img.shields.io/badge/Python-3.10+-3776AB?logo=python&logoColor=white)](https://www.python.org/)
[![Flask](https://img.shields.io/badge/Flask-3.0-000000?logo=flask)](https://flask.palletsprojects.com/)
[![SQLite](https://img.shields.io/badge/SQLite-3-003B57?logo=sqlite&logoColor=white)](https://www.sqlite.org/)
[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](LICENSE)

**Backend:** Flask (Python) · **Banco:** SQLite · **Frontend:** HTML / CSS / JavaScript

---

## Sumário

- [Como funciona a cobrança](#como-funciona-a-cobrança)
- [Perfis de acesso](#perfis-de-acesso)
- [Como rodar localmente](#como-rodar-localmente)
- [Publicar no GitHub](#publicar-no-github)
- [Variáveis de ambiente](#variáveis-de-ambiente)
- [Estrutura do projeto](#estrutura-do-projeto)
- [Funcionalidades](#funcionalidades)

---

## Como funciona a cobrança

Há **dois fluxos de pagamento distintos**:

1. **Avulso (hora / diária)** — cobrado **na saída** do veículo do pátio.
   Usado por clientes avulsos e por veículos extras de quem tem plano.
2. **Planos (mensal / anual)** — cobrado **na assinatura ou renovação**, na tela do cliente
   (botão **Plano**). Editar nome/telefone **não** gera cobrança.

### Planos e níveis

| Plano | Nível | Veículos | Lavagens/mês | Observação |
|-------|-------|----------|--------------|------------|
| **Avulso** | — | ilimitado* | 0 | Paga hora/diária na saída |
| **Mensal** ou **Anual** | **Sem** | 1 | 0 | Saída grátis |
| | **Inicial** | até 2 | 0 | Saída grátis |
| | **Avançado** | até 3 | 3 | Saída grátis |
| | **Max** | até 4 | 6 | Saída grátis |

\*Avulso não limita cadastro de veículos no cliente, mas cada uso é cobrado na saída.

**Veículos além do limite do plano:** é permitido cadastrar. Os primeiros N (conforme o nível) usam o plano (saída grátis). Os extras ficam vinculados ao cliente, mas são cobrados como **avulso** na saída.

### Valores iniciais (editáveis pelo gerente em Preços)

| | Sem | Inicial | Avançado | Max |
|---|-----|---------|----------|-----|
| **Mensal** | R$ 250 | R$ 320 | R$ 420 | R$ 550 |
| **Anual** | R$ 2.500 | R$ 3.200 | R$ 4.200 | R$ 5.500 |

Avulso (hora/diária): carro R$ 12/h · moto R$ 6/h · utilitário R$ 18/h · caminhão R$ 25/h
Diária carro R$ 50 · moto R$ 25 · utilitário R$ 70

A tela de **Preços** separa tarifas avulsas e planos em tabelas distintas.

---

## Perfis de acesso

### Funcionário (`func` / `func123`)

- Entrada e saída de veículos
- Cadastro de clientes e veículos
- Editar dados do cliente (sem cobrança)
- Assinar / trocar / renovar plano (botão Plano — com confirmação e valor)
- Bloquear / liberar vagas
- Registrar lavagens (dentro do limite do plano)
- Consultar preços, relatórios, histórico e busca

### Gerente (`gerente` / `gerente123`)

- Tudo do funcionário
- Criar, editar e excluir vagas
- Criar, editar e desativar preços (avulso e planos)
- Excluir clientes
- Gerenciar usuários

> Estes logins existem só para demonstração. **Troque as senhas** depois do primeiro acesso.

---

## Como rodar localmente

Requisitos: **Python 3.10+**

```bash
git clone https://github.com/SEU_USUARIO/ParkSystem.git
cd ParkSystem

python3 -m venv venv
source venv/bin/activate          # Windows: venv\Scripts\activate

pip install -r requirements.txt

cp .env.example .env              # opcional, mas recomendado

python app.py
```

Acesse: **http://127.0.0.1:5000**

Na primeira execução o arquivo `estacionamento.db` é criado automaticamente com dados de exemplo.

### Produção (Gunicorn)

```bash
export SECRET_KEY="$(python -c 'import secrets; print(secrets.token_hex(32))')"
export FLASK_DEBUG=0
gunicorn "app:criar_app()" --bind 0.0.0.0:5000
```

---

## Publicar no GitHub

1. Crie um repositório vazio no GitHub (sem README, sem .gitignore e sem licença).
2. No computador:

```bash
cd ParkSystem
git init
git add .
git commit -m "Primeira versão do ParkSystem"
git branch -M main
git remote add origin https://github.com/SEU_USUARIO/ParkSystem.git
git push -u origin main
```

O `.gitignore` já impede o envio de:

- `venv/` e `__pycache__/`
- `estacionamento.db` (banco local)
- `.env` (segredos)

Não commite senhas reais nem o arquivo `.env`.

---

## Variáveis de ambiente

| Variável | Padrão | Descrição |
|----------|--------|-----------|
| `SECRET_KEY` | gerada automaticamente | Chave da sessão Flask |
| `HOST` | `127.0.0.1` | Endereço de escuta |
| `PORT` | `5000` | Porta HTTP |
| `FLASK_DEBUG` | `1` | `1` desenvolvimento / `0` produção |
| `DATABASE_PATH` | `estacionamento.db` | Caminho do SQLite |
| `SESSION_COOKIE_SECURE` | `0` | `1` somente com HTTPS |

Use o arquivo `.env.example` como modelo.

---

## Estrutura do projeto

```
ParkSystem/
├── app.py                 # Backend Flask + SQLite + autenticação
├── requirements.txt
├── Procfile               # Deploy com Gunicorn
├── runtime.txt
├── LICENSE
├── .env.example
├── .gitignore
├── templates/
│   └── index.html
└── static/
    ├── css/style.css
    └── js/app.js
```

---

## Funcionalidades

- Vagas: normal, preferencial, moto, carga (bloquear/liberar; gerente edita)
- Placas: formato antigo (ABC1234) e Mercosul (ABC1D23)
- Preços: hora, diária, mensal, anual (com nível)
- Clientes: PF/PJ, plano + nível, validade, lavagens
- Veículos: cor, marca, modelo, tamanho, tipo, ano
- Entrada / saída com cálculo automático (hora em blocos de 15 min)
- Relatórios: ocupação, faturamento (hoje/mês + planos), ranking, tempo médio
- Busca global (clientes, veículos, vagas, histórico)
- Login com sessão e permissões por perfil

### Dados de exemplo (seed)

- Placas: `ABC1D23`, `XYZ9K87`, `DEF4G56`
- Cliente mensal inicial: Maria Oliveira
- Cliente anual max: Empresa XYZ

---

## Licença

Distribuído sob a licença [MIT](LICENSE).
