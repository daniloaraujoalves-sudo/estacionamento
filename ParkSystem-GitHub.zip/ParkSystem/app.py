"""
ParkSystem — Estacionamento
Flask + SQLite

Planos: avulso | mensal | anual
Níveis (mensal/anual): sem | inicial | avancado | max

Perfis: funcionario | gerente
"""
import os
import sqlite3
import re
import secrets
from datetime import datetime, timedelta
from math import ceil
from functools import wraps
from pathlib import Path
from flask import Flask, request, jsonify, send_from_directory, session
from werkzeug.security import generate_password_hash, check_password_hash

BASE_DIR = Path(__file__).resolve().parent
DB_PATH = Path(os.environ.get('DATABASE_PATH', BASE_DIR / 'estacionamento.db'))

app = Flask(__name__, static_folder='static', template_folder='templates')
app.secret_key = os.environ.get('SECRET_KEY') or secrets.token_hex(32)
app.config.update(
    SESSION_COOKIE_HTTPONLY=True,
    SESSION_COOKIE_SAMESITE='Lax',
    SESSION_COOKIE_SECURE=os.environ.get('SESSION_COOKIE_SECURE', '').lower() in ('1', 'true', 'yes'),
)

NIVEIS = {
    'sem': {'label': 'Sem (básico)', 'max_veiculos': 1, 'lavagens_mes': 0, 'descricao': '1 veículo · saída grátis'},
    'inicial': {'label': 'Inicial', 'max_veiculos': 2, 'lavagens_mes': 0, 'descricao': 'Até 2 veículos · saída grátis'},
    'avancado': {'label': 'Avançado', 'max_veiculos': 3, 'lavagens_mes': 3, 'descricao': 'Até 3 veículos · 3 lavagens/mês · saída grátis'},
    'max': {'label': 'Max', 'max_veiculos': 4, 'lavagens_mes': 6, 'descricao': 'Até 4 veículos · 6 lavagens/mês · saída grátis'},
}

PRECOS_SEED = [
    # Avulso (cobrado na saída — por tipo de veículo)
    # Valores alinhados a estacionamentos urbanos no Brasil
    ('Hora — Carro', 'hora', None, 12.0, 'carro'),
    ('Hora — Moto', 'hora', None, 6.0, 'moto'),
    ('Hora — Utilitário', 'hora', None, 18.0, 'utilitario'),
    ('Hora — Caminhão', 'hora', None, 25.0, 'caminhao'),
    ('Diária — Carro', 'diaria', None, 50.0, 'carro'),
    ('Diária — Moto', 'diaria', None, 25.0, 'moto'),
    ('Diária — Utilitário', 'diaria', None, 70.0, 'utilitario'),
    # Planos: preços progressivos justos (mais veículos/lavagens = valor maior)
    # Anual ≈ 10 mensalidades
    ('Mensal Sem', 'mensal', 'sem', 250.0, 'todos'),
    ('Mensal Inicial', 'mensal', 'inicial', 320.0, 'todos'),
    ('Mensal Avançado', 'mensal', 'avancado', 420.0, 'todos'),
    ('Mensal Max', 'mensal', 'max', 550.0, 'todos'),
    ('Anual Sem', 'anual', 'sem', 2500.0, 'todos'),
    ('Anual Inicial', 'anual', 'inicial', 3200.0, 'todos'),
    ('Anual Avançado', 'anual', 'avancado', 4200.0, 'todos'),
    ('Anual Max', 'anual', 'max', 5500.0, 'todos'),
]


def get_db():
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    conn.execute('PRAGMA foreign_keys = ON')
    return conn


def init_db():
    conn = get_db()
    conn.executescript('''
        CREATE TABLE IF NOT EXISTS usuarios (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            nome TEXT NOT NULL,
            login TEXT NOT NULL UNIQUE,
            senha_hash TEXT NOT NULL,
            perfil TEXT NOT NULL,
            ativo INTEGER DEFAULT 1,
            criado_em DATETIME DEFAULT CURRENT_TIMESTAMP
        );
        CREATE TABLE IF NOT EXISTS clientes (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            nome TEXT NOT NULL,
            cpf_cnpj TEXT UNIQUE,
            telefone TEXT, email TEXT,
            tipo TEXT DEFAULT 'PF',
            plano TEXT DEFAULT 'avulso',
            nivel TEXT,
            plano_inicio DATE, plano_validade DATE,
            criado_em DATETIME DEFAULT CURRENT_TIMESTAMP
        );
        CREATE TABLE IF NOT EXISTS veiculos (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            placa TEXT NOT NULL UNIQUE,
            marca TEXT, modelo TEXT, cor TEXT, ano INTEGER,
            tipo TEXT DEFAULT 'carro', tamanho TEXT DEFAULT 'medio',
            cliente_id INTEGER,
            FOREIGN KEY (cliente_id) REFERENCES clientes(id) ON DELETE SET NULL
        );
        CREATE TABLE IF NOT EXISTS vagas (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            numero TEXT NOT NULL UNIQUE,
            tipo TEXT DEFAULT 'normal', status TEXT DEFAULT 'livre', setor TEXT DEFAULT 'A'
        );
        CREATE TABLE IF NOT EXISTS precos (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            descricao TEXT NOT NULL,
            tipo_cobranca TEXT NOT NULL,
            nivel TEXT,
            valor REAL NOT NULL,
            tipo_veiculo TEXT DEFAULT 'todos',
            ativo INTEGER DEFAULT 1
        );
        CREATE TABLE IF NOT EXISTS estacionamentos (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            veiculo_id INTEGER NOT NULL, vaga_id INTEGER NOT NULL,
            data_hora_entrada DATETIME DEFAULT CURRENT_TIMESTAMP,
            data_hora_saida DATETIME,
            valor_calculado REAL DEFAULT 0,
            tipo_cobranca TEXT DEFAULT 'hora',
            status TEXT DEFAULT 'ativo', observacao TEXT,
            FOREIGN KEY (veiculo_id) REFERENCES veiculos(id),
            FOREIGN KEY (vaga_id) REFERENCES vagas(id)
        );
        CREATE TABLE IF NOT EXISTS pagamentos_plano (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            cliente_id INTEGER NOT NULL,
            tipo_plano TEXT NOT NULL, nivel TEXT, valor REAL NOT NULL,
            data_pagamento DATETIME DEFAULT CURRENT_TIMESTAMP,
            validade_inicio DATE, validade_fim DATE, observacao TEXT,
            FOREIGN KEY (cliente_id) REFERENCES clientes(id) ON DELETE CASCADE
        );
        CREATE TABLE IF NOT EXISTS lavagens (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            cliente_id INTEGER NOT NULL,
            data_hora DATETIME DEFAULT CURRENT_TIMESTAMP,
            observacao TEXT,
            FOREIGN KEY (cliente_id) REFERENCES clientes(id) ON DELETE CASCADE
        );
    ''')
    cols = [r['name'] for r in conn.execute('PRAGMA table_info(clientes)').fetchall()]
    if 'nivel' not in cols:
        try: conn.execute('ALTER TABLE clientes ADD COLUMN nivel TEXT')
        except: pass
    cols_p = [r['name'] for r in conn.execute('PRAGMA table_info(precos)').fetchall()]
    if 'nivel' not in cols_p:
        try: conn.execute('ALTER TABLE precos ADD COLUMN nivel TEXT')
        except: pass
    conn.commit()
    conn.close()


def seed_db():
    conn = get_db()
    if conn.execute('SELECT COUNT(*) FROM usuarios').fetchone()[0] == 0:
        conn.execute('INSERT INTO usuarios (nome,login,senha_hash,perfil) VALUES (?,?,?,?)',
                     ('Gerente', 'gerente', generate_password_hash('gerente123'), 'gerente'))
        conn.execute('INSERT INTO usuarios (nome,login,senha_hash,perfil) VALUES (?,?,?,?)',
                     ('Funcionário', 'func', generate_password_hash('func123'), 'funcionario'))
        print('Usuários: gerente/gerente123 | func/func123')

    # Garante preços padrão atualizados (por descrição) — não sobrescreve se gerente já alterou para valor customizado
    # Inclui valores antigos (com e sem desconto) para migrar automaticamente
    precos_antigos = {
        8.0, 4.0, 12.0, 15.0, 40.0, 20.0, 55.0,
        200.0, 190.0, 240.0, 250.0, 280.0, 350.0, 360.0, 450.0,
        2000.0, 1900.0, 2400.0, 2500.0, 2800.0, 3500.0, 3600.0, 4500.0,
    }
    for desc, cob, nivel, valor, tv in PRECOS_SEED:
        row = conn.execute(
            'SELECT id, valor FROM precos WHERE descricao=? AND tipo_cobranca=? AND ativo=1 LIMIT 1',
            (desc, cob)
        ).fetchone()
        if row is None:
            conn.execute(
                'INSERT INTO precos (descricao,tipo_cobranca,nivel,valor,tipo_veiculo) VALUES (?,?,?,?,?)',
                (desc, cob, nivel, valor, tv)
            )
        elif row['valor'] in precos_antigos:
            conn.execute('UPDATE precos SET valor=?, nivel=?, tipo_veiculo=? WHERE id=?',
                         (valor, nivel, tv, row['id']))

    if conn.execute('SELECT COUNT(*) FROM vagas').fetchone()[0] > 0:
        conn.commit(); conn.close(); return

    hoje = datetime.now()
    ini = hoje.strftime('%Y-%m-%d')
    fim = (hoje + timedelta(days=30)).strftime('%Y-%m-%d')
    conn.execute("INSERT INTO clientes (nome,cpf_cnpj,telefone,email,tipo,plano) VALUES (?,?,?,?,?,?)",
                 ('João Silva', '123.456.789-00', '(11) 99999-1111', 'joao@email.com', 'PF', 'avulso'))
    conn.execute("INSERT INTO clientes (nome,cpf_cnpj,telefone,email,tipo,plano,nivel,plano_inicio,plano_validade) VALUES (?,?,?,?,?,?,?,?,?)",
                 ('Maria Oliveira', '987.654.321-00', '(11) 98888-2222', 'maria@email.com', 'PF', 'mensal', 'inicial', ini, fim))
    conn.execute("INSERT INTO clientes (nome,cpf_cnpj,telefone,email,tipo,plano,nivel,plano_inicio,plano_validade) VALUES (?,?,?,?,?,?,?,?,?)",
                 ('Empresa XYZ', '12.345.678/0001-99', '(11) 3333-4444', 'xyz@email.com', 'PJ', 'anual', 'max', ini, (hoje+timedelta(days=365)).strftime('%Y-%m-%d')))
    conn.execute("INSERT INTO veiculos (placa,marca,modelo,cor,ano,tipo,tamanho,cliente_id) VALUES (?,?,?,?,?,?,?,?)",
                 ('ABC1D23', 'Toyota', 'Corolla', 'Prata', 2022, 'carro', 'medio', 1))
    conn.execute("INSERT INTO veiculos (placa,marca,modelo,cor,ano,tipo,tamanho,cliente_id) VALUES (?,?,?,?,?,?,?,?)",
                 ('XYZ9K87', 'Honda', 'CG 160', 'Vermelha', 2023, 'moto', 'pequeno', 2))
    conn.execute("INSERT INTO veiculos (placa,marca,modelo,cor,ano,tipo,tamanho,cliente_id) VALUES (?,?,?,?,?,?,?,?)",
                 ('DEF4G56', 'VW', 'Gol', 'Branco', 2019, 'carro', 'pequeno', 2))
    for i in range(1, 11):
        conn.execute("INSERT INTO vagas (numero,tipo,status,setor) VALUES (?,?,?,?)", (f'A{i:02d}', 'normal', 'livre', 'A'))
    for i in range(1, 5):
        conn.execute("INSERT INTO vagas (numero,tipo,status,setor) VALUES (?,?,?,?)", (f'B{i:02d}', 'preferencial', 'livre', 'B'))
    for i in range(1, 7):
        conn.execute("INSERT INTO vagas (numero,tipo,status,setor) VALUES (?,?,?,?)", (f'C{i:02d}', 'moto', 'livre', 'C'))
    conn.commit(); conn.close()
    print('Dados iniciais inseridos.')


def ok(data, status=200):
    return jsonify({'success': True, 'data': data}), status

def fail(message, status=400):
    return jsonify({'success': False, 'error': message}), status

def rows_to_list(rows):
    return [dict(r) for r in rows]

def gerente_required(f):
    @wraps(f)
    def wrapped(*args, **kwargs):
        if not session.get('user_id'):
            return fail('Faça login', 401)
        if session.get('perfil') != 'gerente':
            return fail('Apenas gerente', 403)
        return f(*args, **kwargs)
    return wrapped

@app.before_request
def check_auth():
    if not request.path.startswith('/api/'):
        return None
    if request.path in ('/api/login', '/api/planos-config'):
        return None
    if request.method == 'OPTIONS':
        return None
    if not session.get('user_id'):
        return fail('Faça login', 401)

def validar_placa(placa):
    if not placa: return False
    limpa = re.sub(r'[^A-Za-z0-9]', '', placa).upper()
    return bool(re.match(r'^[A-Z]{3}[0-9]{4}$', limpa) or re.match(r'^[A-Z]{3}[0-9][A-Z0-9][0-9]{2}$', limpa))

def buscar_preco(conn, tipo_cobranca, tipo_veiculo='carro', nivel=None):
    if nivel:
        row = conn.execute(
            "SELECT valor FROM precos WHERE tipo_cobranca=? AND ativo=1 AND nivel=? AND (tipo_veiculo=? OR tipo_veiculo='todos') "
            "ORDER BY CASE WHEN tipo_veiculo=? THEN 0 ELSE 1 END LIMIT 1",
            (tipo_cobranca, nivel, tipo_veiculo, tipo_veiculo)).fetchone()
        if row: return row['valor']
    row = conn.execute(
        "SELECT valor FROM precos WHERE tipo_cobranca=? AND ativo=1 AND (nivel IS NULL OR nivel='') "
        "AND (tipo_veiculo=? OR tipo_veiculo='todos') ORDER BY CASE WHEN tipo_veiculo=? THEN 0 ELSE 1 END LIMIT 1",
        (tipo_cobranca, tipo_veiculo, tipo_veiculo)).fetchone()
    return row['valor'] if row else None

def plano_valido(plano, validade):
    if plano == 'avulso': return False
    if not validade: return True
    try: return datetime.strptime(str(validade)[:10], '%Y-%m-%d').date() >= datetime.now().date()
    except: return True

def max_veiculos(plano, nivel):
    if plano == 'avulso': return 99
    return NIVEIS.get(nivel or 'sem', NIVEIS['sem'])['max_veiculos']

def lavagens_limite(plano, nivel):
    if plano == 'avulso': return 0
    return NIVEIS.get(nivel or 'sem', NIVEIS['sem'])['lavagens_mes']

def veiculo_coberto_pelo_plano(conn, veiculo_id, cliente_id, plano, nivel, validade):
    """Os primeiros N veículos do cliente (por ordem de cadastro) usam o plano.
    Qualquer veículo além do limite do nível é cobrado como avulso."""
    if not cliente_id or not veiculo_id:
        return False
    if not plano_valido(plano, validade):
        return False
    lim = max_veiculos(plano, nivel)
    ids = [r['id'] for r in conn.execute(
        'SELECT id FROM veiculos WHERE cliente_id=? ORDER BY id ASC', (cliente_id,)
    ).fetchall()]
    try:
        pos = ids.index(int(veiculo_id))
    except ValueError:
        return False
    return pos < lim

def cliente_extras(conn, cid):
    c = conn.execute('SELECT * FROM clientes WHERE id=?', (cid,)).fetchone()
    if not c: return None
    c = dict(c)
    plano = c.get('plano') or 'avulso'
    nivel = c.get('nivel')
    qtd = conn.execute('SELECT COUNT(*) as t FROM veiculos WHERE cliente_id=?', (cid,)).fetchone()['t']
    lav = conn.execute(
        "SELECT COUNT(*) as t FROM lavagens WHERE cliente_id=? AND strftime('%Y-%m',data_hora)=strftime('%Y-%m','now')",
        (cid,)).fetchone()['t']
    lim = max_veiculos(plano, nivel)
    c['qtd_veiculos'] = qtd
    c['max_veiculos'] = lim
    c['veiculos_extras'] = max(0, qtd - lim) if plano != 'avulso' else 0
    c['lavagens_mes_usadas'] = lav
    c['lavagens_mes_limite'] = lavagens_limite(plano, nivel)
    c['plano_valido'] = plano_valido(plano, c.get('plano_validade'))
    c['nivel_info'] = NIVEIS.get(nivel) if nivel else None
    # Dias restantes do plano (negativo = dias vencido)
    c['dias_restantes'] = None
    c['valor_renovacao'] = None
    if plano != 'avulso' and c.get('plano_validade'):
        fim = _parse_date(c['plano_validade'])
        if fim:
            c['dias_restantes'] = (fim - datetime.now().date()).days
        if nivel:
            c['valor_renovacao'] = buscar_preco_plano(conn, plano, nivel or 'sem')
    return c

def calcular_valor(conn, entrada_iso, tipo_veiculo, tipo_cobranca='hora', plano='avulso', nivel=None, validade=None, coberto_plano=True):
    entrada = datetime.fromisoformat(str(entrada_iso).replace('Z', ''))
    diff_min = max(1, ceil((datetime.now() - entrada).total_seconds() / 60))
    # Só grátis se o plano está válido E este veículo está dentro da cota do nível
    if coberto_plano and plano_valido(plano, validade):
        return {'minutos': diff_min, 'tipo_cobranca': f'{plano}/{nivel or "sem"}', 'valor': 0,
                'valor_unitario': 0, 'detalhe': f'Plano {plano} ({nivel or "sem"}) — grátis',
                'coberto_plano': True}
    if tipo_cobranca == 'diaria':
        v = buscar_preco(conn, 'diaria', tipo_veiculo) or 50
        return {'minutos': diff_min, 'tipo_cobranca': 'diaria', 'valor': round(v, 2), 'valor_unitario': v,
                'detalhe': f'Diária R$ {v:.2f}', 'coberto_plano': False}
    vh = buscar_preco(conn, 'hora', tipo_veiculo) or 12
    horas = 1 if diff_min <= 60 else ceil(diff_min / 15) * 0.25
    return {'minutos': diff_min, 'tipo_cobranca': 'hora', 'horas_cobradas': horas,
            'valor': round(horas * vh, 2), 'valor_unitario': vh, 'detalhe': f'{horas}h × R$ {vh:.2f}',
            'coberto_plano': False}

def buscar_preco_plano(conn, tipo_cobranca, nivel):
    """Preço do plano só por período + nível (sem tipo de veículo)."""
    row = conn.execute(
        "SELECT valor FROM precos WHERE tipo_cobranca=? AND nivel=? AND ativo=1 "
        "ORDER BY CASE WHEN tipo_veiculo='todos' THEN 0 ELSE 1 END, valor ASC LIMIT 1",
        (tipo_cobranca, nivel)
    ).fetchone()
    return row['valor'] if row else None


def _parse_date(s):
    if not s:
        return None
    try:
        return datetime.strptime(str(s)[:10], '%Y-%m-%d').date()
    except Exception:
        return None


def ativar_plano(conn, cliente_id, plano, nivel=None, obs='', renovar=False):
    """Ativa, troca ou renova o plano do cliente.

    - avulso: cancela plano, sem cobrança
    - plano novo / troca de nível: cobra e inicia validade a partir de hoje
    - renovar=True com mesmo plano+nível: estende a validade a partir do fim atual
      (se ainda válido) ou de hoje (se vencido), e registra pagamento
    """
    atual = conn.execute(
        'SELECT plano, nivel, plano_validade FROM clientes WHERE id=?', (cliente_id,)
    ).fetchone()
    if not atual:
        raise ValueError('Cliente não encontrado')

    if plano == 'avulso':
        conn.execute(
            'UPDATE clientes SET plano=?, nivel=NULL, plano_inicio=NULL, plano_validade=NULL WHERE id=?',
            ('avulso', cliente_id)
        )
        return None

    if nivel not in NIVEIS:
        nivel = 'sem'

    mesmo_plano = (
        (atual['plano'] or '') == plano
        and (atual['nivel'] or 'sem') == nivel
    )

    # Se já está no mesmo plano/nível e NÃO é renovação explícita → não cobra de novo
    if mesmo_plano and not renovar:
        validade = atual['plano_validade']
        valor = buscar_preco_plano(conn, plano, nivel)
        return {
            'plano': plano,
            'nivel': nivel,
            'valor': 0,
            'validade': validade,
            'mensagem': (
                f'Plano já ativo ({plano}/{nivel})'
                + (f' até {validade}' if validade else '')
                + ' — nenhuma cobrança'
            ),
            'veiculos_extras': 0,
            'cobrado': False,
        }

    lim = max_veiculos(plano, nivel)
    qtd = conn.execute(
        'SELECT COUNT(*) as t FROM veiculos WHERE cliente_id=?', (cliente_id,)
    ).fetchone()['t']
    valor = buscar_preco_plano(conn, plano, nivel)
    if valor is None:
        raise ValueError(
            f'Sem preço cadastrado para plano {plano} / nível {nivel}. Cadastre em Preços.'
        )

    hoje = datetime.now().date()
    dias = 30 if plano == 'mensal' else 365

    # Renovação: estende a partir do fim atual se ainda válido
    if renovar and mesmo_plano:
        fim_atual = _parse_date(atual['plano_validade'])
        base = fim_atual if (fim_atual and fim_atual >= hoje) else hoje
        inicio = base.strftime('%Y-%m-%d')
        fim = (base + timedelta(days=dias)).strftime('%Y-%m-%d')
        obs = obs or f'Renovação {plano}/{nivel}'
    else:
        inicio = hoje.strftime('%Y-%m-%d')
        fim = (hoje + timedelta(days=dias)).strftime('%Y-%m-%d')
        obs = obs or f'{plano}/{nivel}'

    conn.execute(
        'UPDATE clientes SET plano=?, nivel=?, plano_inicio=?, plano_validade=? WHERE id=?',
        (plano, nivel, inicio, fim, cliente_id)
    )
    conn.execute(
        'INSERT INTO pagamentos_plano '
        '(cliente_id,tipo_plano,nivel,valor,validade_inicio,validade_fim,observacao) '
        'VALUES (?,?,?,?,?,?,?)',
        (cliente_id, plano, nivel, valor, inicio, fim, obs)
    )

    acao = 'Renovado' if (renovar and mesmo_plano) else 'Ativado'
    msg = f'{acao}: {plano.upper()} · {NIVEIS[nivel]["label"]} — R$ {valor:.2f} · válido até {fim}'
    if qtd > lim:
        msg += (
            f' · Atenção: {qtd} veículos cadastrados; o plano cobre {lim}. '
            'Os extras pagam avulso na saída.'
        )
    return {
        'plano': plano,
        'nivel': nivel,
        'valor': valor,
        'validade': fim,
        'mensagem': msg,
        'veiculos_extras': max(0, qtd - lim),
        'cobrado': True,
    }

@app.route('/')
def index():
    return send_from_directory('templates', 'index.html')

@app.route('/api/login', methods=['POST'])
def login():
    data = request.get_json() or {}
    login_ = (data.get('login') or '').strip()
    senha = data.get('senha') or ''
    conn = get_db()
    u = conn.execute('SELECT * FROM usuarios WHERE login=? AND ativo=1', (login_,)).fetchone()
    conn.close()
    if not u or not check_password_hash(u['senha_hash'], senha):
        return fail('Login ou senha inválidos', 401)
    session['user_id'] = u['id']
    session['perfil'] = u['perfil']
    session['nome'] = u['nome']
    return ok({'id': u['id'], 'nome': u['nome'], 'login': u['login'], 'perfil': u['perfil']})

@app.route('/api/logout', methods=['POST'])
def logout():
    session.clear()
    return ok({'mensagem': 'Saiu'})

@app.route('/api/me')
def me():
    if not session.get('user_id'): return fail('Não autenticado', 401)
    return ok({'id': session['user_id'], 'nome': session.get('nome'), 'perfil': session.get('perfil')})

@app.route('/api/planos-config')
def planos_config():
    return ok({'niveis': NIVEIS, 'periodos': ['avulso', 'mensal', 'anual']})

@app.route('/api/clientes')
def listar_clientes():
    conn = get_db()
    ids = [r['id'] for r in conn.execute('SELECT id FROM clientes ORDER BY nome').fetchall()]
    lista = [cliente_extras(conn, i) for i in ids]
    conn.close()
    return ok(lista)

@app.route('/api/clientes/busca')
def buscar_clientes():
    """Busca leve de clientes (nome, CPF/CNPJ, telefone) — para vincular veículo sem carregar lista inteira."""
    q = (request.args.get('q') or '').strip()
    if len(q) < 1:
        return ok([])
    like = f'%{q}%'
    conn = get_db()
    rows = conn.execute(
        "SELECT id, nome, cpf_cnpj, telefone, plano, nivel FROM clientes "
        "WHERE nome LIKE ? OR cpf_cnpj LIKE ? OR telefone LIKE ? OR email LIKE ? "
        "ORDER BY nome LIMIT 20",
        (like, like, like, like)
    ).fetchall()
    conn.close()
    return ok(rows_to_list(rows))

@app.route('/api/clientes/<int:cid>')
def get_cliente(cid):
    conn = get_db()
    c = cliente_extras(conn, cid)
    conn.close()
    return ok(c) if c else fail('Não encontrado', 404)

@app.route('/api/clientes', methods=['POST'])
def criar_cliente():
    data = request.get_json() or {}
    nome = (data.get('nome') or '').strip()
    if len(nome) < 2: return fail('Nome obrigatório')
    plano = data.get('plano') if data.get('plano') in ('avulso', 'mensal', 'anual') else 'avulso'
    nivel = data.get('nivel') if data.get('nivel') in NIVEIS else 'sem'
    conn = get_db()
    try:
        cur = conn.execute("INSERT INTO clientes (nome,cpf_cnpj,telefone,email,tipo,plano) VALUES (?,?,?,?,?,'avulso')",
            (nome, (data.get('cpf_cnpj') or '').strip() or None, (data.get('telefone') or '').strip() or None,
             (data.get('email') or '').strip() or None, 'PJ' if data.get('tipo')=='PJ' else 'PF'))
        cid = cur.lastrowid
        pag = ativar_plano(conn, cid, plano, nivel, 'Cadastro') if plano != 'avulso' else None
        conn.commit()
        c = cliente_extras(conn, cid)
        conn.close()
        c['pagamento_plano'] = pag
        return ok(c, 201)
    except sqlite3.IntegrityError:
        conn.close(); return fail('CPF/CNPJ já cadastrado')
    except ValueError as e:
        conn.close(); return fail(str(e))

@app.route('/api/clientes/<int:cid>', methods=['PUT'])
def editar_cliente(cid):
    data = request.get_json() or {}
    conn = get_db()
    atual = conn.execute('SELECT * FROM clientes WHERE id=?', (cid,)).fetchone()
    if not atual: conn.close(); return fail('Não encontrado', 404)
    nome = (data.get('nome') or atual['nome'] or '').strip()
    if len(nome) < 2: conn.close(); return fail('Nome inválido')
    try:
        conn.execute('UPDATE clientes SET nome=?, cpf_cnpj=?, telefone=?, email=?, tipo=? WHERE id=?',
            (nome, data.get('cpf_cnpj', atual['cpf_cnpj']), data.get('telefone', atual['telefone']),
             data.get('email', atual['email']), data.get('tipo') if data.get('tipo') in ('PF','PJ') else atual['tipo'], cid))
        conn.commit()
        c = cliente_extras(conn, cid); conn.close(); return ok(c)
    except sqlite3.IntegrityError:
        conn.close(); return fail('CPF/CNPJ já cadastrado')

@app.route('/api/clientes/<int:cid>/plano', methods=['PUT'])
def trocar_plano(cid):
    """Assina, troca ou cancela o plano.

    Body:
      plano: avulso | mensal | anual
      nivel: sem | inicial | avancado | max  (ignorado se avulso)
      renovar: true  → estende o plano atual (mesmo plano+nível) e cobra
      forcar: true   → força nova cobrança mesmo se já estiver no mesmo plano
    """
    data = request.get_json() or {}
    plano = data.get('plano')
    if plano not in ('avulso', 'mensal', 'anual'):
        return fail('Plano inválido')
    nivel = data.get('nivel') if data.get('nivel') in NIVEIS else 'sem'
    renovar = bool(data.get('renovar'))
    forcar = bool(data.get('forcar'))
    conn = get_db()
    if not conn.execute('SELECT id FROM clientes WHERE id=?', (cid,)).fetchone():
        conn.close()
        return fail('Não encontrado', 404)
    try:
        obs = 'Renovação' if renovar else ('Troca de plano' if plano != 'avulso' else 'Cancelamento')
        pag = ativar_plano(
            conn, cid, plano, nivel,
            obs=obs,
            renovar=renovar or forcar,
        )
        conn.commit()
        c = cliente_extras(conn, cid)
        conn.close()
        c['pagamento_plano'] = pag
        return ok(c)
    except ValueError as e:
        conn.close()
        return fail(str(e))


@app.route('/api/planos/preco')
@app.route('/api/clientes/<int:cid>/plano/preco')
def preco_plano_preview(cid=0):
    """Retorna o valor que seria cobrado para um plano/nível (preview, sem gravar)."""
    plano = request.args.get('plano')
    nivel = request.args.get('nivel') or 'sem'
    if plano not in ('mensal', 'anual'):
        return fail('Informe plano mensal ou anual')
    if nivel not in NIVEIS:
        nivel = 'sem'
    conn = get_db()
    valor = buscar_preco_plano(conn, plano, nivel)
    conn.close()
    if valor is None:
        return fail(f'Sem preço cadastrado para {plano}/{nivel}')
    return ok({
        'plano': plano,
        'nivel': nivel,
        'nivel_label': NIVEIS[nivel]['label'],
        'valor': valor,
        'descricao': NIVEIS[nivel]['descricao'],
        'dias': 30 if plano == 'mensal' else 365,
    })


@app.route('/api/clientes/<int:cid>/pagamentos-plano')
def listar_pagamentos_cliente(cid):
    conn = get_db()
    if not conn.execute('SELECT id FROM clientes WHERE id=?', (cid,)).fetchone():
        conn.close()
        return fail('Não encontrado', 404)
    rows = rows_to_list(conn.execute(
        'SELECT * FROM pagamentos_plano WHERE cliente_id=? ORDER BY data_pagamento DESC LIMIT 50',
        (cid,)
    ).fetchall())
    conn.close()
    return ok(rows)


@app.route('/api/pagamentos-plano')
def listar_pagamentos_plano():
    """Histórico recente de pagamentos de planos (todos os clientes)."""
    limit = min(int(request.args.get('limit') or 30), 100)
    conn = get_db()
    rows = rows_to_list(conn.execute('''
        SELECT p.*, c.nome as cliente_nome, c.cpf_cnpj
        FROM pagamentos_plano p
        JOIN clientes c ON c.id = p.cliente_id
        ORDER BY p.data_pagamento DESC
        LIMIT ?
    ''', (limit,)).fetchall())
    conn.close()
    return ok(rows)


@app.route('/api/planos/alertas')
def planos_alertas():
    """Planos vencidos e a vencer nos próximos N dias (default 7)."""
    try:
        dias = max(1, min(int(request.args.get('dias') or 7), 90))
    except ValueError:
        dias = 7
    conn = get_db()
    rows = conn.execute(
        "SELECT id, nome, telefone, cpf_cnpj, plano, nivel, plano_validade "
        "FROM clientes WHERE plano IN ('mensal','anual') AND plano_validade IS NOT NULL "
        "ORDER BY plano_validade ASC"
    ).fetchall()
    hoje = datetime.now().date()
    vencidos = []
    a_vencer = []
    for r in rows:
        d = dict(r)
        fim = _parse_date(d.get('plano_validade'))
        if not fim:
            continue
        resto = (fim - hoje).days
        d['dias_restantes'] = resto
        d['nivel_label'] = NIVEIS.get(d.get('nivel') or 'sem', {}).get('label', d.get('nivel'))
        d['valor_renovacao'] = buscar_preco_plano(conn, d['plano'], d.get('nivel') or 'sem')
        if resto < 0:
            vencidos.append(d)
        elif resto <= dias:
            a_vencer.append(d)
    conn.close()
    return ok({
        'dias_janela': dias,
        'vencidos': vencidos,
        'a_vencer': a_vencer,
        'total_alertas': len(vencidos) + len(a_vencer),
    })

@app.route('/api/clientes/<int:cid>', methods=['DELETE'])
@gerente_required
def remover_cliente(cid):
    conn = get_db()
    if not conn.execute('SELECT id FROM clientes WHERE id=?', (cid,)).fetchone():
        conn.close(); return fail('Não encontrado', 404)
    if conn.execute("SELECT e.id FROM estacionamentos e JOIN veiculos v ON e.veiculo_id=v.id WHERE v.cliente_id=? AND e.status='ativo'", (cid,)).fetchone():
        conn.close(); return fail('Cliente tem veículo no pátio')
    conn.execute('UPDATE veiculos SET cliente_id=NULL WHERE cliente_id=?', (cid,))
    conn.execute('DELETE FROM clientes WHERE id=?', (cid,))
    conn.commit(); conn.close()
    return ok({'mensagem': 'Removido'})

@app.route('/api/clientes/<int:cid>/lavagens')
def listar_lavagens(cid):
    conn = get_db()
    c = cliente_extras(conn, cid)
    if not c: conn.close(); return fail('Não encontrado', 404)
    rows = rows_to_list(conn.execute('SELECT * FROM lavagens WHERE cliente_id=? ORDER BY data_hora DESC LIMIT 50', (cid,)).fetchall())
    conn.close(); return ok({'cliente': c, 'lavagens': rows})

@app.route('/api/clientes/<int:cid>/lavagens', methods=['POST'])
def reg_lavagem(cid):
    data = request.get_json() or {}
    conn = get_db()
    c = cliente_extras(conn, cid)
    if not c: conn.close(); return fail('Não encontrado', 404)
    if not c['plano_valido']: conn.close(); return fail('Plano inválido/vencido')
    if c['lavagens_mes_limite'] <= 0: conn.close(); return fail('Sem lavagens neste nível')
    if c['lavagens_mes_usadas'] >= c['lavagens_mes_limite']:
        conn.close(); return fail(f'Limite mensal ({c["lavagens_mes_limite"]}) atingido')
    conn.execute('INSERT INTO lavagens (cliente_id, observacao) VALUES (?,?)',
                 (cid, (data.get('observacao') or '').strip() or None))
    conn.commit()
    c2 = cliente_extras(conn, cid); conn.close()
    return ok({'mensagem': f'Lavagem OK ({c2["lavagens_mes_usadas"]}/{c2["lavagens_mes_limite"]})', 'cliente': c2}, 201)

@app.route('/api/veiculos')
def listar_veiculos():
    conn = get_db()
    rows = conn.execute(
        'SELECT v.*, c.nome as cliente_nome, c.plano as cliente_plano, c.nivel as cliente_nivel, '
        'c.plano_validade as cliente_plano_validade '
        'FROM veiculos v LEFT JOIN clientes c ON v.cliente_id=c.id ORDER BY v.placa'
    ).fetchall()
    lista = []
    for r in rows:
        d = dict(r)
        d['coberto_plano'] = veiculo_coberto_pelo_plano(
            conn, d['id'], d.get('cliente_id'), d.get('cliente_plano') or 'avulso',
            d.get('cliente_nivel'), d.get('cliente_plano_validade')
        )
        lista.append(d)
    conn.close(); return ok(lista)


@app.route('/api/veiculos/busca')
def buscar_veiculos():
    """Busca rápida de veículos (placa, marca, modelo, cliente) — para tela de entrada."""
    q = (request.args.get('q') or '').strip()
    if len(q) < 1:
        return ok([])
    like = f'%{q}%'
    conn = get_db()
    rows = conn.execute(
        '''SELECT v.*, c.nome as cliente_nome, c.plano as cliente_plano, c.nivel as cliente_nivel,
                  c.plano_validade as cliente_plano_validade, c.telefone as cliente_telefone
           FROM veiculos v
           LEFT JOIN clientes c ON v.cliente_id = c.id
           WHERE v.placa LIKE ? OR v.marca LIKE ? OR v.modelo LIKE ?
              OR c.nome LIKE ? OR c.cpf_cnpj LIKE ?
           ORDER BY
             CASE WHEN UPPER(v.placa) = UPPER(?) THEN 0
                  WHEN UPPER(v.placa) LIKE UPPER(?) THEN 1
                  ELSE 2 END,
             v.placa
           LIMIT 25''',
        (like, like, like, like, like, q, f'{q}%')
    ).fetchall()
    lista = []
    for r in rows:
        d = dict(r)
        d['coberto_plano'] = veiculo_coberto_pelo_plano(
            conn, d['id'], d.get('cliente_id'), d.get('cliente_plano') or 'avulso',
            d.get('cliente_nivel'), d.get('cliente_plano_validade')
        )
        ativo = conn.execute(
            "SELECT e.id, vg.numero as vaga_numero FROM estacionamentos e "
            "JOIN vagas vg ON vg.id = e.vaga_id "
            "WHERE e.veiculo_id=? AND e.status='ativo' LIMIT 1",
            (d['id'],)
        ).fetchone()
        d['ja_estacionado'] = bool(ativo)
        d['vaga_atual'] = ativo['vaga_numero'] if ativo else None
        lista.append(d)
    conn.close()
    return ok(lista)

@app.route('/api/veiculos', methods=['POST'])
def criar_veiculo():
    data = request.get_json() or {}
    placa = re.sub(r'[^A-Za-z0-9]', '', (data.get('placa') or '')).upper()
    if not validar_placa(placa): return fail('Placa inválida')
    cliente_id = data.get('cliente_id') or None
    if cliente_id in ('', 'null', 'None'):
        cliente_id = None
    aviso = None
    conn = get_db()
    if cliente_id:
        c = cliente_extras(conn, int(cliente_id))
        if not c:
            conn.close(); return fail('Cliente não encontrado', 404)
        # Permite cadastrar além do limite do plano: o extra é cobrado como avulso na saída
        if c['plano'] != 'avulso' and c['qtd_veiculos'] >= c['max_veiculos']:
            aviso = (
                f'Cliente já tem {c["qtd_veiculos"]}/{c["max_veiculos"]} veículos no plano. '
                f'Este veículo fica vinculado, mas será cobrado como avulso na saída.'
            )
    try:
        cur = conn.execute("INSERT INTO veiculos (placa,marca,modelo,cor,ano,tipo,tamanho,cliente_id) VALUES (?,?,?,?,?,?,?,?)",
            (placa, (data.get('marca') or '').strip() or None, (data.get('modelo') or '').strip() or None,
             (data.get('cor') or '').strip() or None, data.get('ano') or None,
             data.get('tipo') if data.get('tipo') in ('carro','moto','utilitario','caminhao') else 'carro',
             data.get('tamanho') if data.get('tamanho') in ('pequeno','medio','grande') else 'medio', cliente_id))
        conn.commit()
        v = dict(conn.execute('SELECT * FROM veiculos WHERE id=?', (cur.lastrowid,)).fetchone())
        if aviso:
            v['aviso'] = aviso
        conn.close(); return ok(v, 201)
    except sqlite3.IntegrityError:
        conn.close(); return fail('Placa já cadastrada')

@app.route('/api/veiculos/<int:vid>', methods=['DELETE'])
def del_veiculo(vid):
    conn = get_db()
    if conn.execute("SELECT id FROM estacionamentos WHERE veiculo_id=? AND status='ativo'", (vid,)).fetchone():
        conn.close(); return fail('Veículo no pátio')
    cur = conn.execute('DELETE FROM veiculos WHERE id=?', (vid,))
    conn.commit(); conn.close()
    return ok({'mensagem': 'Removido'}) if cur.rowcount else fail('Não encontrado', 404)

@app.route('/api/vagas')
def listar_vagas():
    conn = get_db(); rows = conn.execute('SELECT * FROM vagas ORDER BY setor, numero').fetchall(); conn.close()
    return ok(rows_to_list(rows))

@app.route('/api/vagas/livres')
def vagas_livres():
    conn = get_db(); rows = conn.execute("SELECT * FROM vagas WHERE status='livre' ORDER BY setor, numero").fetchall(); conn.close()
    return ok(rows_to_list(rows))

@app.route('/api/vagas', methods=['POST'])
@gerente_required
def criar_vaga():
    data = request.get_json() or {}
    numero = (data.get('numero') or '').strip().upper()
    if not numero: return fail('Número obrigatório')
    conn = get_db()
    try:
        cur = conn.execute("INSERT INTO vagas (numero,tipo,status,setor) VALUES (?,?,?,?)",
            (numero, data.get('tipo') if data.get('tipo') in ('normal','preferencial','moto','carga') else 'normal',
             data.get('status') if data.get('status') in ('livre','bloqueada','reservada') else 'livre',
             (data.get('setor') or 'A').strip().upper()))
        conn.commit()
        v = dict(conn.execute('SELECT * FROM vagas WHERE id=?', (cur.lastrowid,)).fetchone())
        conn.close(); return ok(v, 201)
    except sqlite3.IntegrityError:
        conn.close(); return fail('Número já existe')

@app.route('/api/vagas/<int:vid>/status', methods=['PUT'])
def status_vaga(vid):
    data = request.get_json() or {}
    status = data.get('status')
    if status not in ('livre','ocupada','reservada','bloqueada'): return fail('Status inválido')
    conn = get_db()
    if status == 'livre' and conn.execute("SELECT id FROM estacionamentos WHERE vaga_id=? AND status='ativo'", (vid,)).fetchone():
        conn.close(); return fail('Vaga com veículo')
    cur = conn.execute('UPDATE vagas SET status=? WHERE id=?', (status, vid))
    conn.commit(); conn.close()
    return ok({'status': status}) if cur.rowcount else fail('Não encontrada', 404)


@app.route('/api/vagas/<int:vid>', methods=['PUT'])
@gerente_required
def editar_vaga(vid):
    """Gerente: edita número, tipo, setor e status da vaga."""
    data = request.get_json() or {}
    conn = get_db()
    v = conn.execute('SELECT * FROM vagas WHERE id=?', (vid,)).fetchone()
    if not v:
        conn.close(); return fail('Vaga não encontrada', 404)
    numero = (data.get('numero') or v['numero'] or '').strip().upper()
    if not numero:
        conn.close(); return fail('Número obrigatório')
    tipo = data.get('tipo') if data.get('tipo') in ('normal', 'preferencial', 'moto', 'carga') else v['tipo']
    setor = (data.get('setor') or v['setor'] or 'A').strip().upper()
    status = data.get('status') if data.get('status') in ('livre', 'ocupada', 'reservada', 'bloqueada') else v['status']
    # Não permitir marcar como livre se há veículo ativo
    if status == 'livre' and conn.execute(
        "SELECT id FROM estacionamentos WHERE vaga_id=? AND status='ativo'", (vid,)
    ).fetchone():
        conn.close(); return fail('Vaga com veículo ativo — finalize a saída antes')
    # Não permitir mudar status de ocupada via edição se ainda há estacionamento ativo
    if v['status'] == 'ocupada' and status != 'ocupada' and conn.execute(
        "SELECT id FROM estacionamentos WHERE vaga_id=? AND status='ativo'", (vid,)
    ).fetchone():
        conn.close(); return fail('Vaga ocupada. Finalize a saída antes de alterar o status.')
    try:
        conn.execute(
            'UPDATE vagas SET numero=?, tipo=?, setor=?, status=? WHERE id=?',
            (numero, tipo, setor, status, vid)
        )
        conn.commit()
        row = dict(conn.execute('SELECT * FROM vagas WHERE id=?', (vid,)).fetchone())
        conn.close()
        return ok(row)
    except sqlite3.IntegrityError:
        conn.close(); return fail('Número de vaga já existe')

@app.route('/api/precos')
def listar_precos():
    conn = get_db()
    rows = conn.execute("SELECT * FROM precos WHERE ativo=1 ORDER BY tipo_cobranca, nivel, tipo_veiculo").fetchall()
    conn.close(); return ok(rows_to_list(rows))

@app.route('/api/precos', methods=['POST'])
@gerente_required
def criar_preco():
    data = request.get_json() or {}
    if not data.get('descricao') or not data.get('tipo_cobranca') or data.get('valor') is None:
        return fail('Campos obrigatórios')
    conn = get_db()
    cur = conn.execute("INSERT INTO precos (descricao,tipo_cobranca,nivel,valor,tipo_veiculo) VALUES (?,?,?,?,?)",
        (data['descricao'], data['tipo_cobranca'], data.get('nivel') or None, float(data['valor']), data.get('tipo_veiculo') or 'todos'))
    conn.commit()
    p = dict(conn.execute('SELECT * FROM precos WHERE id=?', (cur.lastrowid,)).fetchone())
    conn.close(); return ok(p, 201)

@app.route('/api/precos/<int:pid>', methods=['PUT'])
@gerente_required
def editar_preco(pid):
    data = request.get_json() or {}
    conn = get_db()
    cur = conn.execute('UPDATE precos SET descricao=COALESCE(?,descricao), valor=COALESCE(?,valor), tipo_veiculo=COALESCE(?,tipo_veiculo), nivel=COALESCE(?,nivel) WHERE id=?',
        (data.get('descricao'), float(data['valor']) if data.get('valor') is not None else None, data.get('tipo_veiculo'), data.get('nivel'), pid))
    conn.commit()
    if not cur.rowcount: conn.close(); return fail('Não encontrado', 404)
    p = dict(conn.execute('SELECT * FROM precos WHERE id=?', (pid,)).fetchone())
    conn.close(); return ok(p)

@app.route('/api/precos/<int:pid>', methods=['DELETE'])
@gerente_required
def del_preco(pid):
    conn = get_db(); conn.execute('UPDATE precos SET ativo=0 WHERE id=?', (pid,)); conn.commit(); conn.close()
    return ok({'mensagem': 'Desativado'})

@app.route('/api/estacionamentos/ativos')
def ativos():
    conn = get_db()
    rows = conn.execute('''SELECT e.*, v.placa, v.marca, v.modelo, v.cor, v.tipo as tipo_veiculo,
        vg.numero as vaga_numero, vg.tipo as vaga_tipo, c.nome as cliente_nome, c.plano as cliente_plano,
        c.nivel as cliente_nivel, c.plano_validade as cliente_plano_validade
        FROM estacionamentos e JOIN veiculos v ON e.veiculo_id=v.id JOIN vagas vg ON e.vaga_id=vg.id
        LEFT JOIN clientes c ON v.cliente_id=c.id WHERE e.status='ativo' ORDER BY e.data_hora_entrada DESC''').fetchall()
    conn.close(); return ok(rows_to_list(rows))

@app.route('/api/estacionamentos/previa/<int:eid>')
def previa(eid):
    conn = get_db()
    est = conn.execute('''SELECT e.*, v.id as veiculo_id, v.tipo as tipo_veiculo, v.placa, v.cliente_id,
        c.plano as cliente_plano, c.nivel as cliente_nivel, c.plano_validade as cliente_plano_validade
        FROM estacionamentos e JOIN veiculos v ON e.veiculo_id=v.id
        LEFT JOIN clientes c ON v.cliente_id=c.id WHERE e.id=? AND e.status='ativo' ''', (eid,)).fetchone()
    if not est: conn.close(); return fail('Não encontrado', 404)
    est = dict(est)
    plano = est.get('cliente_plano') or 'avulso'
    nivel = est.get('cliente_nivel')
    val = est.get('cliente_plano_validade')
    coberto = veiculo_coberto_pelo_plano(conn, est.get('veiculo_id'), est.get('cliente_id'), plano, nivel, val)
    okp = coberto  # só grátis se coberto pelo plano
    ph = calcular_valor(conn, est['data_hora_entrada'], est['tipo_veiculo'], 'hora')
    pd = calcular_valor(conn, est['data_hora_entrada'], est['tipo_veiculo'], 'diaria')
    extras_info = None
    if plano != 'avulso' and plano_valido(plano, val) and not coberto:
        lim = max_veiculos(plano, nivel)
        extras_info = f'Veículo fora da cota do plano ({lim} vaga(s)). Cobrança avulsa.'
    conn.close()
    return ok({'placa': est['placa'], 'entrada': est['data_hora_entrada'], 'plano_cliente': plano, 'nivel': nivel,
               'plano_validade': val, 'plano_valido': okp, 'coberto_plano': coberto,
               'aviso_extra': extras_info, 'opcoes': {'hora': ph, 'diaria': pd},
               'sugestao': f'{plano}/{nivel}' if okp else ('hora' if ph['valor'] <= pd['valor'] else 'diaria')})

@app.route('/api/estacionamentos/entrada', methods=['POST'])
def entrada():
    """Registra entrada. Se a placa não existir e vierem dados mínimos (tipo),
    cadastra o veículo na hora e estaciona (cadastro rápido)."""
    data = request.get_json() or {}
    placa = re.sub(r'[^A-Za-z0-9]', '', (data.get('placa') or '')).upper()
    vaga_id = data.get('vaga_id')
    if not placa or not vaga_id:
        return fail('Placa e vaga obrigatórios')
    if not validar_placa(placa):
        return fail('Placa inválida')
    conn = get_db()
    veiculo = conn.execute('SELECT * FROM veiculos WHERE UPPER(placa)=?', (placa,)).fetchone()
    criado_agora = False

    if not veiculo:
        # Cadastro rápido: precisa pelo menos do tipo
        tipo = data.get('tipo') if data.get('tipo') in ('carro', 'moto', 'utilitario', 'caminhao') else None
        if not tipo:
            conn.close()
            return fail(
                'Veículo não cadastrado. Informe o tipo para cadastrar na hora, '
                'ou cadastre antes em Veículos.',
                404
            )
        cliente_id = data.get('cliente_id') or None
        if cliente_id in ('', 'null', 'None', 0, '0'):
            cliente_id = None
        if cliente_id:
            if not conn.execute('SELECT id FROM clientes WHERE id=?', (int(cliente_id),)).fetchone():
                conn.close()
                return fail('Cliente informado não existe', 404)
            cliente_id = int(cliente_id)
        tamanho = data.get('tamanho') if data.get('tamanho') in ('pequeno', 'medio', 'grande') else 'medio'
        try:
            cur_v = conn.execute(
                'INSERT INTO veiculos (placa,marca,modelo,cor,ano,tipo,tamanho,cliente_id) '
                'VALUES (?,?,?,?,?,?,?,?)',
                (
                    placa,
                    (data.get('marca') or '').strip() or None,
                    (data.get('modelo') or '').strip() or None,
                    (data.get('cor') or '').strip() or None,
                    data.get('ano') or None,
                    tipo,
                    tamanho,
                    cliente_id,
                )
            )
            veiculo = conn.execute('SELECT * FROM veiculos WHERE id=?', (cur_v.lastrowid,)).fetchone()
            criado_agora = True
        except sqlite3.IntegrityError:
            conn.close()
            return fail('Placa já cadastrada')

    if conn.execute(
        "SELECT id FROM estacionamentos WHERE veiculo_id=? AND status='ativo'",
        (veiculo['id'],)
    ).fetchone():
        conn.close()
        return fail('Já estacionado')

    vaga = conn.execute('SELECT * FROM vagas WHERE id=?', (vaga_id,)).fetchone()
    if not vaga or vaga['status'] != 'livre':
        conn.close()
        return fail('Vaga indisponível')

    cur = conn.execute(
        'INSERT INTO estacionamentos (veiculo_id,vaga_id,observacao) VALUES (?,?,?)',
        (veiculo['id'], vaga_id, (data.get('observacao') or '').strip() or None)
    )
    conn.execute("UPDATE vagas SET status='ocupada' WHERE id=?", (vaga_id,))
    conn.commit()
    reg = dict(conn.execute(
        'SELECT e.*, v.placa, vg.numero as vaga_numero FROM estacionamentos e '
        'JOIN veiculos v ON e.veiculo_id=v.id JOIN vagas vg ON e.vaga_id=vg.id WHERE e.id=?',
        (cur.lastrowid,)
    ).fetchone())
    reg['veiculo_criado'] = criado_agora
    conn.close()
    return ok(reg, 201)

@app.route('/api/estacionamentos/saida/<int:eid>', methods=['POST'])
def saida(eid):
    data = request.get_json() or {}
    tipo_req = data.get('tipo_cobranca')
    conn = get_db()
    est = conn.execute('''SELECT e.*, v.id as veiculo_id, v.tipo as tipo_veiculo, v.placa, v.cliente_id,
        c.plano as cliente_plano, c.nivel as cliente_nivel, c.plano_validade as cliente_plano_validade
        FROM estacionamentos e JOIN veiculos v ON e.veiculo_id=v.id
        LEFT JOIN clientes c ON v.cliente_id=c.id WHERE e.id=? AND e.status='ativo' ''', (eid,)).fetchone()
    if not est: conn.close(); return fail('Não encontrado', 404)
    est = dict(est)
    plano = est.get('cliente_plano') or 'avulso'
    nivel = est.get('cliente_nivel')
    val = est.get('cliente_plano_validade')
    coberto = veiculo_coberto_pelo_plano(conn, est.get('veiculo_id'), est.get('cliente_id'), plano, nivel, val)
    if coberto:
        tipo_final = 'hora'
    elif not tipo_req or tipo_req == 'auto':
        ph = calcular_valor(conn, est['data_hora_entrada'], est['tipo_veiculo'], 'hora')
        pd = calcular_valor(conn, est['data_hora_entrada'], est['tipo_veiculo'], 'diaria')
        tipo_final = 'hora' if ph['valor'] <= pd['valor'] else 'diaria'
    else:
        tipo_final = tipo_req if tipo_req in ('hora', 'diaria') else 'hora'
    calc = calcular_valor(conn, est['data_hora_entrada'], est['tipo_veiculo'], tipo_final, plano, nivel, val, coberto_plano=coberto)
    conn.execute("UPDATE estacionamentos SET data_hora_saida=CURRENT_TIMESTAMP, valor_calculado=?, tipo_cobranca=?, status='finalizado' WHERE id=?",
                 (calc['valor'], calc['tipo_cobranca'], eid))
    conn.execute("UPDATE vagas SET status='livre' WHERE id=?", (est['vaga_id'],))
    conn.commit()
    res = dict(conn.execute("SELECT e.*, v.placa, vg.numero as vaga_numero FROM estacionamentos e JOIN veiculos v ON e.veiculo_id=v.id JOIN vagas vg ON e.vaga_id=vg.id WHERE e.id=?", (eid,)).fetchone())
    conn.close(); res.update(calc); return ok(res)

@app.route('/api/estacionamentos/historico')
def historico():
    conn = get_db()
    rows = conn.execute("SELECT e.*, v.placa, v.marca, v.modelo, vg.numero as vaga_numero FROM estacionamentos e JOIN veiculos v ON e.veiculo_id=v.id JOIN vagas vg ON e.vaga_id=vg.id WHERE e.status='finalizado' ORDER BY e.data_hora_saida DESC LIMIT 100").fetchall()
    conn.close(); return ok(rows_to_list(rows))

@app.route('/api/busca')
def busca():
    q = (request.args.get('q') or '').strip()
    if not q: return fail('Informe o termo')
    like = f'%{q}%'
    conn = get_db()
    data = {
        'termo': q,
        'clientes': rows_to_list(conn.execute("SELECT * FROM clientes WHERE nome LIKE ? OR cpf_cnpj LIKE ? OR telefone LIKE ? OR plano LIKE ? LIMIT 20", (like,like,like,like)).fetchall()),
        'veiculos': rows_to_list(conn.execute("SELECT v.*, c.nome as cliente_nome FROM veiculos v LEFT JOIN clientes c ON v.cliente_id=c.id WHERE v.placa LIKE ? OR v.marca LIKE ? OR v.modelo LIKE ? LIMIT 20", (like,like,like)).fetchall()),
        'vagas': rows_to_list(conn.execute("SELECT * FROM vagas WHERE numero LIKE ? OR tipo LIKE ? OR status LIKE ? LIMIT 20", (like,like,like)).fetchall()),
        'historico': rows_to_list(conn.execute("SELECT e.*, v.placa, vg.numero as vaga_numero FROM estacionamentos e JOIN veiculos v ON e.veiculo_id=v.id JOIN vagas vg ON e.vaga_id=vg.id WHERE v.placa LIKE ? OR vg.numero LIKE ? ORDER BY e.id DESC LIMIT 20", (like,like)).fetchall()),
    }
    data['total'] = sum(len(data[k]) for k in ('clientes','veiculos','vagas','historico'))
    conn.close(); return ok(data)

@app.route('/api/relatorios/ocupacao')
def rel_ocup():
    conn = get_db()
    total = conn.execute('SELECT COUNT(*) as t FROM vagas').fetchone()['t']
    livres = conn.execute("SELECT COUNT(*) as t FROM vagas WHERE status='livre'").fetchone()['t']
    ocupadas = conn.execute("SELECT COUNT(*) as t FROM vagas WHERE status='ocupada'").fetchone()['t']
    conn.close()
    return ok({'total_vagas': total, 'livres': livres, 'ocupadas': ocupadas,
               'percentual_ocupacao': round(ocupadas/total*100,1) if total else 0})

@app.route('/api/relatorios/faturamento')
def rel_fat():
    conn = get_db()
    saidas_hoje = conn.execute(
        "SELECT COALESCE(SUM(valor_calculado),0) as t FROM estacionamentos "
        "WHERE status='finalizado' AND date(data_hora_saida)=date('now')"
    ).fetchone()['t']
    saidas_mes = conn.execute(
        "SELECT COALESCE(SUM(valor_calculado),0) as t FROM estacionamentos "
        "WHERE status='finalizado' AND strftime('%Y-%m',data_hora_saida)=strftime('%Y-%m','now')"
    ).fetchone()['t']
    planos_hoje = conn.execute(
        "SELECT COALESCE(SUM(valor),0) as t FROM pagamentos_plano WHERE date(data_pagamento)=date('now')"
    ).fetchone()['t']
    planos_mes = conn.execute(
        "SELECT COALESCE(SUM(valor),0) as t FROM pagamentos_plano "
        "WHERE strftime('%Y-%m',data_pagamento)=strftime('%Y-%m','now')"
    ).fetchone()['t']
    conn.close()
    return ok({
        'faturamento_hoje': saidas_hoje + planos_hoje,
        'faturamento_mes': saidas_mes + planos_mes,
        'saidas_hoje': saidas_hoje,
        'saidas_mes': saidas_mes,
        'planos_hoje': planos_hoje,
        'planos_mes': planos_mes,
    })

@app.route('/api/relatorios/completo')
def rel_comp():
    conn = get_db()
    ocup = {
        'total': conn.execute('SELECT COUNT(*) as t FROM vagas').fetchone()['t'],
        'livres': conn.execute("SELECT COUNT(*) as t FROM vagas WHERE status='livre'").fetchone()['t'],
        'ocupadas': conn.execute("SELECT COUNT(*) as t FROM vagas WHERE status='ocupada'").fetchone()['t'],
    }
    fat_saidas_h = conn.execute(
        "SELECT COALESCE(SUM(valor_calculado),0) as t FROM estacionamentos "
        "WHERE status='finalizado' AND date(data_hora_saida)=date('now')"
    ).fetchone()['t']
    fat_saidas_m = conn.execute(
        "SELECT COALESCE(SUM(valor_calculado),0) as t FROM estacionamentos "
        "WHERE status='finalizado' AND strftime('%Y-%m',data_hora_saida)=strftime('%Y-%m','now')"
    ).fetchone()['t']
    fat_planos_h = conn.execute(
        "SELECT COALESCE(SUM(valor),0) as t FROM pagamentos_plano WHERE date(data_pagamento)=date('now')"
    ).fetchone()['t']
    fat_planos_m = conn.execute(
        "SELECT COALESCE(SUM(valor),0) as t FROM pagamentos_plano "
        "WHERE strftime('%Y-%m',data_pagamento)=strftime('%Y-%m','now')"
    ).fetchone()['t']
    tempo = conn.execute(
        "SELECT AVG((julianday(data_hora_saida)-julianday(data_hora_entrada))*24*60) as m "
        "FROM estacionamentos WHERE status='finalizado'"
    ).fetchone()['m']
    ranking = rows_to_list(conn.execute(
        "SELECT v.placa, COUNT(*) as visitas, COALESCE(SUM(e.valor_calculado),0) as total_pago "
        "FROM estacionamentos e JOIN veiculos v ON e.veiculo_id=v.id "
        "WHERE e.status='finalizado' GROUP BY v.id ORDER BY visitas DESC LIMIT 10"
    ).fetchall())
    vagas_u = rows_to_list(conn.execute(
        "SELECT vg.numero, vg.tipo, COUNT(*) as usos FROM estacionamentos e "
        "JOIN vagas vg ON e.vaga_id=vg.id WHERE e.status='finalizado' "
        "GROUP BY vg.id ORDER BY usos DESC LIMIT 10"
    ).fetchall())
    dias = rows_to_list(conn.execute(
        "SELECT date(data_hora_saida) as dia, COUNT(*) as quantidade, "
        "COALESCE(SUM(valor_calculado),0) as total FROM estacionamentos "
        "WHERE status='finalizado' AND data_hora_saida>=date('now','-7 days') "
        "GROUP BY date(data_hora_saida) ORDER BY dia DESC"
    ).fetchall())
    pagamentos_recentes = rows_to_list(conn.execute('''
        SELECT p.id, p.tipo_plano, p.nivel, p.valor, p.data_pagamento,
               p.validade_inicio, p.validade_fim, p.observacao, c.nome as cliente_nome
        FROM pagamentos_plano p
        JOIN clientes c ON c.id = p.cliente_id
        ORDER BY p.data_pagamento DESC
        LIMIT 15
    ''').fetchall())
    conn.close()
    return ok({
        'ocupacao': ocup,
        'faturamento': {
            'hoje': fat_saidas_h + fat_planos_h,
            'mes': fat_saidas_m + fat_planos_m,
            'saidas_hoje': fat_saidas_h,
            'saidas_mes': fat_saidas_m,
            'planos_hoje': fat_planos_h,
            'planos_mes': fat_planos_m,
        },
        'tempo_medio_minutos': round(tempo) if tempo else 0,
        'ranking_placas': ranking,
        'vagas_mais_usadas': vagas_u,
        'ultimos_7_dias': dias,
        'pagamentos_plano_recentes': pagamentos_recentes,
    })

@app.route('/api/usuarios')
@gerente_required
def listar_usuarios():
    conn = get_db()
    rows = conn.execute('SELECT id,nome,login,perfil,ativo,criado_em FROM usuarios ORDER BY nome').fetchall()
    conn.close(); return ok(rows_to_list(rows))

@app.route('/api/usuarios', methods=['POST'])
@gerente_required
def criar_usuario():
    data = request.get_json() or {}
    nome = (data.get('nome') or '').strip()
    login_ = (data.get('login') or '').strip()
    senha = data.get('senha') or ''
    perfil = data.get('perfil')
    if not nome or not login_ or len(senha) < 4: return fail('Nome, login e senha (mín 4) obrigatórios')
    if perfil not in ('funcionario', 'gerente'): return fail('Perfil inválido')
    conn = get_db()
    try:
        cur = conn.execute('INSERT INTO usuarios (nome,login,senha_hash,perfil) VALUES (?,?,?,?)',
                           (nome, login_, generate_password_hash(senha), perfil))
        conn.commit()
        u = dict(conn.execute('SELECT id,nome,login,perfil,ativo FROM usuarios WHERE id=?', (cur.lastrowid,)).fetchone())
        conn.close(); return ok(u, 201)
    except sqlite3.IntegrityError:
        conn.close(); return fail('Login já existe')


@app.route('/api/usuarios/<int:uid>', methods=['PUT'])
@gerente_required
def editar_usuario(uid):
    data = request.get_json() or {}
    conn = get_db()
    u = conn.execute('SELECT * FROM usuarios WHERE id=?', (uid,)).fetchone()
    if not u:
        conn.close(); return fail('Usuário não encontrado', 404)
    nome = (data.get('nome') or u['nome'] or '').strip()
    perfil = data.get('perfil') if data.get('perfil') in ('funcionario', 'gerente') else u['perfil']
    ativo = data.get('ativo') if data.get('ativo') is not None else u['ativo']
    senha = data.get('senha')
    try:
        if senha and len(str(senha)) >= 4:
            conn.execute('UPDATE usuarios SET nome=?, perfil=?, ativo=?, senha_hash=? WHERE id=?',
                         (nome, perfil, int(bool(ativo)), generate_password_hash(str(senha)), uid))
        else:
            conn.execute('UPDATE usuarios SET nome=?, perfil=?, ativo=? WHERE id=?',
                         (nome, perfil, int(bool(ativo)), uid))
        conn.commit()
        row = dict(conn.execute('SELECT id,nome,login,perfil,ativo,criado_em FROM usuarios WHERE id=?', (uid,)).fetchone())
        conn.close(); return ok(row)
    except Exception as e:
        conn.close(); return fail(str(e), 500)


@app.route('/api/usuarios/<int:uid>', methods=['DELETE'])
@gerente_required
def remover_usuario(uid):
    if session.get('user_id') == uid:
        return fail('Não é possível remover o próprio usuário logado')
    conn = get_db()
    u = conn.execute('SELECT * FROM usuarios WHERE id=?', (uid,)).fetchone()
    if not u:
        conn.close(); return fail('Usuário não encontrado', 404)
    # não deixar sem nenhum gerente
    if u['perfil'] == 'gerente':
        qtd = conn.execute("SELECT COUNT(*) as t FROM usuarios WHERE perfil='gerente' AND ativo=1 AND id!=?", (uid,)).fetchone()['t']
        if qtd < 1:
            conn.close(); return fail('É necessário manter ao menos um gerente ativo')
    conn.execute('DELETE FROM usuarios WHERE id=?', (uid,))
    conn.commit(); conn.close()
    return ok({'mensagem': 'Usuário removido'})


@app.route('/api/vagas/<int:vid>', methods=['DELETE'])
@gerente_required
def remover_vaga(vid):
    conn = get_db()
    v = conn.execute('SELECT * FROM vagas WHERE id=?', (vid,)).fetchone()
    if not v:
        conn.close(); return fail('Vaga não encontrada', 404)
    if v['status'] == 'ocupada' or conn.execute(
        "SELECT id FROM estacionamentos WHERE vaga_id=? AND status='ativo'", (vid,)
    ).fetchone():
        conn.close(); return fail('Vaga ocupada. Finalize a saída antes de excluir.')
    conn.execute('DELETE FROM vagas WHERE id=?', (vid,))
    conn.commit(); conn.close()
    return ok({'mensagem': 'Vaga removida'})


def criar_app():
    """Factory usada por gunicorn: `gunicorn 'app:criar_app()'`."""
    init_db()
    seed_db()
    return app


init_db()
seed_db()


if __name__ == '__main__':
    debug = os.environ.get('FLASK_DEBUG', '1').lower() in ('1', 'true', 'yes')
    host = os.environ.get('HOST', '127.0.0.1')
    port = int(os.environ.get('PORT', '5000'))
    print('\n  ParkSystem')
    print(f'  http://{host}:{port}')
    if debug:
        print('  Demo: gerente/gerente123  ·  func/func123')
        print('  Altere as senhas após o primeiro login.\n')
    app.run(debug=debug, host=host, port=port)
