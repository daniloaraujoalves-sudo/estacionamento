# Como contribuir

Obrigado por ajudar o ParkSystem.

## Fluxo

1. Faça um fork do repositório.
2. Crie um branch: `git checkout -b feat/minha-ideia`
3. Instale as dependências e rode o app localmente (veja o README).
4. Envie um pull request descrevendo o que mudou.

## Boas práticas

- Não commite `venv/`, `*.db` ou `.env`.
- Mantenha senhas de demonstração só no README e no seed.
- Em produção use `SECRET_KEY` forte e `FLASK_DEBUG=0`.
- Prefira mensagens de commit claras, por exemplo: `fix: cálculo da diária para moto`.
