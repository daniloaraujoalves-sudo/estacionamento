# Segurança

- Não publique o arquivo `.env` nem o banco `estacionamento.db`.
- Em produção defina `SECRET_KEY` forte e `FLASK_DEBUG=0`.
- Os usuários `gerente` / `func` são apenas de demonstração. Troque as senhas no painel.
- Com HTTPS, ative `SESSION_COOKIE_SECURE=1`.
