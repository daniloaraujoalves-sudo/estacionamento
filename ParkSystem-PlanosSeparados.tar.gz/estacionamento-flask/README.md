# ParkSystem — Versão Melhorada (planos separados)

Sistema de Estacionamento de Veículos  
**Backend:** Flask (Python) · **Banco:** SQLite · **Frontend:** HTML/CSS/JS

---

## Como funciona a cobrança (importante)

Há **dois fluxos de pagamento distintos**:

1. **Avulso (hora / diária)** — cobrado **na saída** do veículo do pátio.  
   Usado por clientes avulsos e por veículos extras de quem tem plano.

2. **Planos (mensal / anual)** — cobrado **na assinatura ou renovação**, na tela do cliente  
   (botão **Plano**). Editar nome/telefone **não** gera cobrança.

### Planos e níveis

| Plano | Nível | Veículos | Lavagens/mês | Observação |
|-------|-------|----------|--------------|------------|
| **Avulso** | — | ilimitado* | 0 | Paga hora/diária na saída |
| **Mensal** ou **Anual** | **Sem** | 1 | 0 | Saída grátis |
| | **Inicial** | até 2 | 0 | Saída grátis |
| | **Avançado** | até 3 | 3 | Saída grátis |
| | **Max** | até 4 | 6 | Saída grátis |

\*Avulso não limita cadastro de veículos no cliente, mas cada uso é cobrado na saída.

**Veículos além do limite do plano:** é permitido cadastrar. Os primeiros N (conforme o nível) usam o plano (saída grátis). Os extras ficam vinculados ao cliente, mas são cobrados como **avulso** na saída.

### Valores iniciais (editáveis pelo gerente em Preços)

| | Sem | Inicial | Avançado | Max |
|---|-----|---------|----------|-----|
| **Mensal** | R$ 250 | R$ 320 | R$ 420 | R$ 550 |
| **Anual** | R$ 2.500 | R$ 3.200 | R$ 4.200 | R$ 5.500 |

Avulso (hora/diária): carro R$ 12/h · moto R$ 6/h · utilitário R$ 18/h · caminhão R$ 25/h  
Diária carro R$ 50 · moto R$ 25 · utilitário R$ 70

A tela de **Preços** separa tarifas avulsas e planos em tabelas distintas.

---

## Perfis de acesso

### Funcionário (`func` / `func123`)
- Entrada e saída de veículos
- Cadastro de clientes e veículos
- **Editar dados** do cliente (sem cobrança)
- **Assinar / trocar / renovar plano** (botão Plano — com confirmação e valor)
- Bloquear / liberar vagas
- Registrar lavagens (dentro do limite do plano)
- Consultar preços, relatórios, histórico e busca

### Gerente (`gerente` / `gerente123`)
- Tudo do funcionário
- **Criar, editar e excluir vagas**
- **Criar, editar e desativar preços** (avulso e planos)
- **Excluir clientes**
- **Gerenciar usuários**

---

## Como rodar

```bash
cd estacionamento-flask

python3 -m venv venv
source venv/bin/activate   # Windows: venv\Scripts\activate

pip install -r requirements.txt
python app.py
```

Acesse: **http://localhost:5000**

Logins de exemplo:
- Gerente: `gerente` / `gerente123`
- Funcionário: `func` / `func123`

---

## Estrutura

```
estacionamento-flask/
├── app.py                 # Backend Flask + SQLite + auth
├── requirements.txt
├── estacionamento.db      # Criado na 1ª execução
├── templates/
│   └── index.html
└── static/
    ├── css/style.css
    └── js/app.js
```

---

## Funcionalidades

- Vagas: normal, preferencial, moto, carga (bloquear/liberar; gerente edita)
- Placas: formato antigo (ABC1234) e Mercosul (ABC1D23)
- Preços: hora, diária, mensal, anual (com nível) — progressivos e justos
- Clientes: PF/PJ, plano + nível, validade, lavagens · busca na lista
- Veículos: cor, marca, modelo, tamanho, tipo, ano · limite por plano · busca na lista
- Entrada / saída com cálculo automático (hora em blocos de 15 min)
- Relatórios: ocupação, faturamento (hoje/mês + planos), ranking, tempo médio
- Busca global (clientes, veículos, vagas, histórico)
- Login com sessão e permissões por perfil

### Dados de exemplo (seed)

- Placas: `ABC1D23`, `XYZ9K87`, `DEF4G56`
- Cliente mensal inicial: Maria Oliveira
- Cliente anual max: Empresa XYZ

Na primeira execução o banco é criado e preenchido automaticamente.
