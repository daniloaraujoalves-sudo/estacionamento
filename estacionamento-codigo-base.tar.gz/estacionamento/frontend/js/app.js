const API = 'http://localhost:3000/api';

// ============================================
// NAVEGAÇÃO
// ============================================
document.querySelectorAll('.nav-btn').forEach(btn => {
  btn.addEventListener('click', () => {
    document.querySelectorAll('.nav-btn').forEach(b => b.classList.remove('active'));
    document.querySelectorAll('.page').forEach(p => p.classList.remove('active'));
    btn.classList.add('active');
    document.getElementById(btn.dataset.page).classList.add('active');

    // Carrega dados da página
    const page = btn.dataset.page;
    if (page === 'dashboard') carregarDashboard();
    if (page === 'entrada') carregarVagasLivres();
    if (page === 'saida') carregarAtivosParaSaida();
    if (page === 'vagas') carregarVagas();
    if (page === 'veiculos') carregarVeiculos();
    if (page === 'clientes') carregarClientes();
    if (page === 'historico') carregarHistorico();
  });
});

// ============================================
// DASHBOARD
// ============================================
async function carregarDashboard() {
  try {
    const [ocupacao, faturamento, ativos] = await Promise.all([
      fetch(`${API}/relatorios/ocupacao`).then(r => r.json()),
      fetch(`${API}/relatorios/faturamento`).then(r => r.json()),
      fetch(`${API}/estacionamentos/ativos`).then(r => r.json())
    ]);

    document.getElementById('qtd-livres').textContent = ocupacao.livres;
    document.getElementById('qtd-ocupadas').textContent = ocupacao.ocupadas;
    document.getElementById('percentual').textContent = ocupacao.percentual_ocupacao + '%';
    document.getElementById('faturamento-hoje').textContent = 'R$ ' + Number(faturamento.faturamento_hoje).toFixed(2);

    const tbody = document.querySelector('#tabela-ativos tbody');
    tbody.innerHTML = '';

    if (ativos.length === 0) {
      tbody.innerHTML = '<tr><td colspan="5" style="text-align:center;color:#888">Nenhum veículo estacionado</td></tr>';
      return;
    }

    ativos.forEach(e => {
      const tr = document.createElement('tr');
      tr.innerHTML = `
        <td><strong>${e.placa}</strong></td>
        <td>${e.marca || ''} ${e.modelo || ''} (${e.cor || '-'})</td>
        <td>${e.vaga_numero} (${e.vaga_tipo})</td>
        <td>${formatarData(e.data_hora_entrada)}</td>
        <td>${e.cliente_nome || '-'}</td>
      `;
      tbody.appendChild(tr);
    });
  } catch (err) {
    console.error(err);
  }
}

// ============================================
// ENTRADA
// ============================================
async function carregarVagasLivres() {
  const select = document.getElementById('entrada-vaga');
  select.innerHTML = '<option value="">Carregando...</option>';

  try {
    const vagas = await fetch(`${API}/vagas/livres`).then(r => r.json());
    select.innerHTML = '<option value="">Selecione uma vaga livre...</option>';
    vagas.forEach(v => {
      const opt = document.createElement('option');
      opt.value = v.id;
      opt.textContent = `${v.numero} - ${v.tipo} (Setor ${v.setor})`;
      select.appendChild(opt);
    });
  } catch (err) {
    select.innerHTML = '<option value="">Erro ao carregar vagas</option>';
  }
}

document.getElementById('form-entrada').addEventListener('submit', async (e) => {
  e.preventDefault();
  const msg = document.getElementById('msg-entrada');
  msg.className = 'mensagem';

  const dados = {
    placa: document.getElementById('entrada-placa').value.trim().toUpperCase(),
    vaga_id: Number(document.getElementById('entrada-vaga').value),
    observacao: document.getElementById('entrada-obs').value.trim()
  };

  try {
    const res = await fetch(`${API}/estacionamentos/entrada`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(dados)
    });
    const data = await res.json();

    if (!res.ok) throw new Error(data.erro || 'Erro ao registrar entrada');

    msg.textContent = `Entrada registrada! Placa ${data.placa} na vaga ${data.vaga_numero}`;
    msg.className = 'mensagem sucesso';
    e.target.reset();
    carregarVagasLivres();
  } catch (err) {
    msg.textContent = err.message;
    msg.className = 'mensagem erro';
  }
});

// ============================================
// SAÍDA
// ============================================
async function carregarAtivosParaSaida() {
  const tbody = document.querySelector('#tabela-saida tbody');
  tbody.innerHTML = '<tr><td colspan="5">Carregando...</td></tr>';

  try {
    const ativos = await fetch(`${API}/estacionamentos/ativos`).then(r => r.json());
    tbody.innerHTML = '';

    if (ativos.length === 0) {
      tbody.innerHTML = '<tr><td colspan="5" style="text-align:center;color:#888">Nenhum veículo para saída</td></tr>';
      return;
    }

    ativos.forEach(e => {
      const tr = document.createElement('tr');
      tr.innerHTML = `
        <td><strong>${e.placa}</strong></td>
        <td>${e.marca || ''} ${e.modelo || ''}</td>
        <td>${e.vaga_numero}</td>
        <td>${formatarData(e.data_hora_entrada)}</td>
        <td><button class="btn btn-success" onclick="registrarSaida(${e.id})">Finalizar Saída</button></td>
      `;
      tbody.appendChild(tr);
    });
  } catch (err) {
    tbody.innerHTML = '<tr><td colspan="5">Erro ao carregar</td></tr>';
  }
}

async function registrarSaida(id) {
  const msg = document.getElementById('msg-saida');
  msg.className = 'mensagem';

  if (!confirm('Confirmar saída deste veículo?')) return;

  try {
    const res = await fetch(`${API}/estacionamentos/saida/${id}`, { method: 'POST' });
    const data = await res.json();

    if (!res.ok) throw new Error(data.erro || 'Erro na saída');

    msg.textContent = `Saída OK! Placa ${data.placa} | Permanência: ${data.horas_permanencia}h | Valor: R$ ${Number(data.valor_calculado).toFixed(2)}`;
    msg.className = 'mensagem sucesso';
    carregarAtivosParaSaida();
  } catch (err) {
    msg.textContent = err.message;
    msg.className = 'mensagem erro';
  }
}

// ============================================
// VAGAS
// ============================================
let todasVagas = [];

async function carregarVagas() {
  try {
    todasVagas = await fetch(`${API}/vagas`).then(r => r.json());
    renderVagas('todos');
  } catch (err) {
    console.error(err);
  }
}

function renderVagas(filtro) {
  const grid = document.getElementById('grid-vagas');
  grid.innerHTML = '';

  let lista = todasVagas;
  if (filtro === 'livre') lista = todasVagas.filter(v => v.status === 'livre');
  if (filtro === 'ocupada') lista = todasVagas.filter(v => v.status === 'ocupada');
  if (filtro === 'preferencial') lista = todasVagas.filter(v => v.tipo === 'preferencial');

  lista.forEach(v => {
    const div = document.createElement('div');
    div.className = `vaga-card ${v.status} ${v.tipo === 'preferencial' ? 'preferencial' : ''}`;
    div.innerHTML = `
      <span class="numero-vaga">${v.numero}</span>
      <span class="tipo-vaga">${v.tipo}</span>
    `;
    grid.appendChild(div);
  });
}

document.querySelectorAll('.filtro-btn').forEach(btn => {
  btn.addEventListener('click', () => {
    document.querySelectorAll('.filtro-btn').forEach(b => b.classList.remove('active'));
    btn.classList.add('active');
    renderVagas(btn.dataset.filtro);
  });
});

// ============================================
// VEÍCULOS
// ============================================
async function carregarVeiculos() {
  try {
    const veiculos = await fetch(`${API}/veiculos`).then(r => r.json());
    const tbody = document.querySelector('#tabela-veiculos tbody');
    tbody.innerHTML = '';

    veiculos.forEach(v => {
      const tr = document.createElement('tr');
      tr.innerHTML = `
        <td><strong>${v.placa}</strong></td>
        <td>${v.marca || '-'} ${v.modelo || ''}</td>
        <td>${v.cor || '-'}</td>
        <td>${v.ano || '-'}</td>
        <td>${v.tipo}</td>
        <td>${v.cliente_nome || '-'}</td>
      `;
      tbody.appendChild(tr);
    });

    // Preenche select de clientes no form
    const clientes = await fetch(`${API}/clientes`).then(r => r.json());
    const select = document.getElementById('vei-cliente');
    select.innerHTML = '<option value="">Sem cliente vinculado</option>';
    clientes.forEach(c => {
      const opt = document.createElement('option');
      opt.value = c.id;
      opt.textContent = c.nome;
      select.appendChild(opt);
    });
  } catch (err) {
    console.error(err);
  }
}

function mostrarFormVeiculo() {
  document.getElementById('form-veiculo').classList.remove('hidden');
}

function esconderFormVeiculo() {
  document.getElementById('form-veiculo').classList.add('hidden');
  document.getElementById('form-veiculo').reset();
}

document.getElementById('form-veiculo').addEventListener('submit', async (e) => {
  e.preventDefault();

  const dados = {
    placa: document.getElementById('vei-placa').value.trim().toUpperCase(),
    marca: document.getElementById('vei-marca').value.trim(),
    modelo: document.getElementById('vei-modelo').value.trim(),
    cor: document.getElementById('vei-cor').value.trim(),
    ano: document.getElementById('vei-ano').value ? Number(document.getElementById('vei-ano').value) : null,
    tipo: document.getElementById('vei-tipo').value,
    tamanho: document.getElementById('vei-tamanho').value,
    cliente_id: document.getElementById('vei-cliente').value || null
  };

  try {
    const res = await fetch(`${API}/veiculos`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(dados)
    });
    const data = await res.json();
    if (!res.ok) throw new Error(data.erro || 'Erro ao cadastrar');

    alert('Veículo cadastrado com sucesso!');
    esconderFormVeiculo();
    carregarVeiculos();
  } catch (err) {
    alert(err.message);
  }
});

// ============================================
// CLIENTES
// ============================================
async function carregarClientes() {
  try {
    const clientes = await fetch(`${API}/clientes`).then(r => r.json());
    const tbody = document.querySelector('#tabela-clientes tbody');
    tbody.innerHTML = '';

    clientes.forEach(c => {
      const tr = document.createElement('tr');
      tr.innerHTML = `
        <td>${c.nome}</td>
        <td>${c.cpf_cnpj || '-'}</td>
        <td>${c.telefone || '-'}</td>
        <td>${c.email || '-'}</td>
        <td>${c.tipo}</td>
      `;
      tbody.appendChild(tr);
    });
  } catch (err) {
    console.error(err);
  }
}

function mostrarFormCliente() {
  document.getElementById('form-cliente').classList.remove('hidden');
}

function esconderFormCliente() {
  document.getElementById('form-cliente').classList.add('hidden');
  document.getElementById('form-cliente').reset();
}

document.getElementById('form-cliente').addEventListener('submit', async (e) => {
  e.preventDefault();

  const dados = {
    nome: document.getElementById('cli-nome').value.trim(),
    cpf_cnpj: document.getElementById('cli-cpf').value.trim(),
    telefone: document.getElementById('cli-telefone').value.trim(),
    email: document.getElementById('cli-email').value.trim(),
    tipo: document.getElementById('cli-tipo').value
  };

  try {
    const res = await fetch(`${API}/clientes`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(dados)
    });
    const data = await res.json();
    if (!res.ok) throw new Error(data.erro || 'Erro ao cadastrar');

    alert('Cliente cadastrado com sucesso!');
    esconderFormCliente();
    carregarClientes();
  } catch (err) {
    alert(err.message);
  }
});

// ============================================
// HISTÓRICO
// ============================================
async function carregarHistorico() {
  try {
    const historico = await fetch(`${API}/estacionamentos/historico`).then(r => r.json());
    const tbody = document.querySelector('#tabela-historico tbody');
    tbody.innerHTML = '';

    if (historico.length === 0) {
      tbody.innerHTML = '<tr><td colspan="6" style="text-align:center;color:#888">Nenhum registro</td></tr>';
      return;
    }

    historico.forEach(e => {
      const tr = document.createElement('tr');
      tr.innerHTML = `
        <td><strong>${e.placa}</strong></td>
        <td>${e.marca || ''} ${e.modelo || ''}</td>
        <td>${e.vaga_numero}</td>
        <td>${formatarData(e.data_hora_entrada)}</td>
        <td>${formatarData(e.data_hora_saida)}</td>
        <td>R$ ${Number(e.valor_calculado).toFixed(2)}</td>
      `;
      tbody.appendChild(tr);
    });
  } catch (err) {
    console.error(err);
  }
}

// ============================================
// UTILITÁRIOS
// ============================================
function formatarData(dataStr) {
  if (!dataStr) return '-';
  const d = new Date(dataStr);
  return d.toLocaleString('pt-BR', {
    day: '2-digit',
    month: '2-digit',
    year: 'numeric',
    hour: '2-digit',
    minute: '2-digit'
  });
}

// Carrega dashboard ao iniciar
carregarDashboard();
