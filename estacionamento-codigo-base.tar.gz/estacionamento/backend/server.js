const express = require('express');
const cors = require('cors');
const path = require('path');
const db = require('./database');

const app = express();
const PORT = 3000;

app.use(cors());
app.use(express.json());

// Serve o frontend
app.use(express.static(path.join(__dirname, '../frontend')));

// ============================================
// ROTAS - CLIENTES
// ============================================

app.get('/api/clientes', (req, res) => {
  const clientes = db.prepare('SELECT * FROM clientes ORDER BY nome').all();
  res.json(clientes);
});

app.get('/api/clientes/:id', (req, res) => {
  const cliente = db.prepare('SELECT * FROM clientes WHERE id = ?').get(req.params.id);
  if (!cliente) return res.status(404).json({ erro: 'Cliente não encontrado' });
  res.json(cliente);
});

app.post('/api/clientes', (req, res) => {
  const { nome, cpf_cnpj, telefone, email, tipo } = req.body;
  if (!nome) return res.status(400).json({ erro: 'Nome é obrigatório' });

  try {
    const result = db.prepare(`
      INSERT INTO clientes (nome, cpf_cnpj, telefone, email, tipo)
      VALUES (?, ?, ?, ?, ?)
    `).run(nome, cpf_cnpj || null, telefone || null, email || null, tipo || 'PF');

    const novo = db.prepare('SELECT * FROM clientes WHERE id = ?').get(result.lastInsertRowid);
    res.status(201).json(novo);
  } catch (err) {
    res.status(400).json({ erro: err.message });
  }
});

app.put('/api/clientes/:id', (req, res) => {
  const { nome, cpf_cnpj, telefone, email, tipo } = req.body;
  const result = db.prepare(`
    UPDATE clientes SET nome = ?, cpf_cnpj = ?, telefone = ?, email = ?, tipo = ?
    WHERE id = ?
  `).run(nome, cpf_cnpj, telefone, email, tipo, req.params.id);

  if (result.changes === 0) return res.status(404).json({ erro: 'Cliente não encontrado' });
  res.json({ mensagem: 'Cliente atualizado' });
});

app.delete('/api/clientes/:id', (req, res) => {
  const result = db.prepare('DELETE FROM clientes WHERE id = ?').run(req.params.id);
  if (result.changes === 0) return res.status(404).json({ erro: 'Cliente não encontrado' });
  res.json({ mensagem: 'Cliente removido' });
});

// ============================================
// ROTAS - VEÍCULOS
// ============================================

app.get('/api/veiculos', (req, res) => {
  const veiculos = db.prepare(`
    SELECT v.*, c.nome as cliente_nome
    FROM veiculos v
    LEFT JOIN clientes c ON v.cliente_id = c.id
    ORDER BY v.placa
  `).all();
  res.json(veiculos);
});

app.get('/api/veiculos/:id', (req, res) => {
  const veiculo = db.prepare(`
    SELECT v.*, c.nome as cliente_nome
    FROM veiculos v
    LEFT JOIN clientes c ON v.cliente_id = c.id
    WHERE v.id = ?
  `).get(req.params.id);
  if (!veiculo) return res.status(404).json({ erro: 'Veículo não encontrado' });
  res.json(veiculo);
});

app.get('/api/veiculos/placa/:placa', (req, res) => {
  const veiculo = db.prepare(`
    SELECT v.*, c.nome as cliente_nome
    FROM veiculos v
    LEFT JOIN clientes c ON v.cliente_id = c.id
    WHERE UPPER(v.placa) = UPPER(?)
  `).get(req.params.placa);
  if (!veiculo) return res.status(404).json({ erro: 'Veículo não encontrado' });
  res.json(veiculo);
});

app.post('/api/veiculos', (req, res) => {
  const { placa, marca, modelo, cor, ano, tipo, tamanho, cliente_id } = req.body;
  if (!placa) return res.status(400).json({ erro: 'Placa é obrigatória' });

  try {
    const result = db.prepare(`
      INSERT INTO veiculos (placa, marca, modelo, cor, ano, tipo, tamanho, cliente_id)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?)
    `).run(
      placa.toUpperCase(),
      marca || null,
      modelo || null,
      cor || null,
      ano || null,
      tipo || 'carro',
      tamanho || 'medio',
      cliente_id || null
    );

    const novo = db.prepare('SELECT * FROM veiculos WHERE id = ?').get(result.lastInsertRowid);
    res.status(201).json(novo);
  } catch (err) {
    res.status(400).json({ erro: err.message });
  }
});

// ============================================
// ROTAS - VAGAS
// ============================================

app.get('/api/vagas', (req, res) => {
  const vagas = db.prepare('SELECT * FROM vagas ORDER BY setor, numero').all();
  res.json(vagas);
});

app.get('/api/vagas/livres', (req, res) => {
  const tipo = req.query.tipo;
  let query = `SELECT * FROM vagas WHERE status = 'livre'`;
  if (tipo) query += ` AND tipo = ?`;
  query += ` ORDER BY setor, numero`;

  const vagas = tipo
    ? db.prepare(query).all(tipo)
    : db.prepare(query).all();
  res.json(vagas);
});

app.put('/api/vagas/:id/status', (req, res) => {
  const { status } = req.body;
  if (!['livre', 'ocupada', 'reservada', 'bloqueada'].includes(status)) {
    return res.status(400).json({ erro: 'Status inválido' });
  }
  const result = db.prepare('UPDATE vagas SET status = ? WHERE id = ?').run(status, req.params.id);
  if (result.changes === 0) return res.status(404).json({ erro: 'Vaga não encontrada' });
  res.json({ mensagem: 'Status atualizado' });
});

// ============================================
// ROTAS - PREÇOS
// ============================================

app.get('/api/precos', (req, res) => {
  const precos = db.prepare('SELECT * FROM precos WHERE ativo = 1').all();
  res.json(precos);
});

app.post('/api/precos', (req, res) => {
  const { descricao, tipo_cobranca, valor, tipo_veiculo } = req.body;
  if (!descricao || !tipo_cobranca || valor == null) {
    return res.status(400).json({ erro: 'Campos obrigatórios: descricao, tipo_cobranca, valor' });
  }

  const result = db.prepare(`
    INSERT INTO precos (descricao, tipo_cobranca, valor, tipo_veiculo)
    VALUES (?, ?, ?, ?)
  `).run(descricao, tipo_cobranca, valor, tipo_veiculo || 'todos');

  const novo = db.prepare('SELECT * FROM precos WHERE id = ?').get(result.lastInsertRowid);
  res.status(201).json(novo);
});

// ============================================
// ROTAS - ESTACIONAMENTO (Entrada / Saída)
// ============================================

// Listar estacionamentos ativos
app.get('/api/estacionamentos/ativos', (req, res) => {
  const ativos = db.prepare(`
    SELECT e.*, 
           v.placa, v.marca, v.modelo, v.cor, v.tipo as tipo_veiculo,
           vg.numero as vaga_numero, vg.tipo as vaga_tipo,
           c.nome as cliente_nome
    FROM estacionamentos e
    JOIN veiculos v ON e.veiculo_id = v.id
    JOIN vagas vg ON e.vaga_id = vg.id
    LEFT JOIN clientes c ON v.cliente_id = c.id
    WHERE e.status = 'ativo'
    ORDER BY e.data_hora_entrada DESC
  `).all();
  res.json(ativos);
});

// Entrada de veículo
app.post('/api/estacionamentos/entrada', (req, res) => {
  const { placa, vaga_id, observacao } = req.body;

  if (!placa || !vaga_id) {
    return res.status(400).json({ erro: 'Placa e vaga_id são obrigatórios' });
  }

  // Busca o veículo
  let veiculo = db.prepare('SELECT * FROM veiculos WHERE UPPER(placa) = UPPER(?)').get(placa);
  if (!veiculo) {
    return res.status(404).json({ erro: 'Veículo não cadastrado. Cadastre o veículo primeiro.' });
  }

  // Verifica se já está estacionado
  const jaEstacionado = db.prepare(`
    SELECT id FROM estacionamentos 
    WHERE veiculo_id = ? AND status = 'ativo'
  `).get(veiculo.id);

  if (jaEstacionado) {
    return res.status(400).json({ erro: 'Este veículo já está estacionado' });
  }

  // Verifica se a vaga está livre
  const vaga = db.prepare('SELECT * FROM vagas WHERE id = ?').get(vaga_id);
  if (!vaga) return res.status(404).json({ erro: 'Vaga não encontrada' });
  if (vaga.status !== 'livre') return res.status(400).json({ erro: 'Vaga não está livre' });

  // Inicia transação
  const entrada = db.transaction(() => {
    // Insere o estacionamento
    const result = db.prepare(`
      INSERT INTO estacionamentos (veiculo_id, vaga_id, observacao)
      VALUES (?, ?, ?)
    `).run(veiculo.id, vaga_id, observacao || null);

    // Atualiza status da vaga
    db.prepare(`UPDATE vagas SET status = 'ocupada' WHERE id = ?`).run(vaga_id);

    return result.lastInsertRowid;
  });

  const id = entrada();
  const registro = db.prepare(`
    SELECT e.*, v.placa, vg.numero as vaga_numero
    FROM estacionamentos e
    JOIN veiculos v ON e.veiculo_id = v.id
    JOIN vagas vg ON e.vaga_id = vg.id
    WHERE e.id = ?
  `).get(id);

  res.status(201).json(registro);
});

// Saída de veículo + cálculo de valor
app.post('/api/estacionamentos/saida/:id', (req, res) => {
  const estacionamento = db.prepare(`
    SELECT e.*, v.tipo as tipo_veiculo
    FROM estacionamentos e
    JOIN veiculos v ON e.veiculo_id = v.id
    WHERE e.id = ? AND e.status = 'ativo'
  `).get(req.params.id);

  if (!estacionamento) {
    return res.status(404).json({ erro: 'Estacionamento ativo não encontrado' });
  }

  // Calcula tempo em horas (mínimo 1 hora)
  const entrada = new Date(estacionamento.data_hora_entrada);
  const saida = new Date();
  const diffMs = saida - entrada;
  const horas = Math.max(1, Math.ceil(diffMs / (1000 * 60 * 60)));

  // Busca preço por hora do tipo de veículo
  let preco = db.prepare(`
    SELECT valor FROM precos 
    WHERE tipo_cobranca = 'hora' AND (tipo_veiculo = ? OR tipo_veiculo = 'todos') AND ativo = 1
    ORDER BY CASE WHEN tipo_veiculo = ? THEN 0 ELSE 1 END
    LIMIT 1
  `).get(estacionamento.tipo_veiculo, estacionamento.tipo_veiculo);

  const valorHora = preco ? preco.valor : 8.00; // valor padrão
  const valorCalculado = horas * valorHora;

  // Finaliza
  const finaliza = db.transaction(() => {
    db.prepare(`
      UPDATE estacionamentos 
      SET data_hora_saida = CURRENT_TIMESTAMP,
          valor_calculado = ?,
          status = 'finalizado'
      WHERE id = ?
    `).run(valorCalculado, req.params.id);

    db.prepare(`UPDATE vagas SET status = 'livre' WHERE id = ?`).run(estacionamento.vaga_id);
  });

  finaliza();

  const resultado = db.prepare(`
    SELECT e.*, v.placa, vg.numero as vaga_numero
    FROM estacionamentos e
    JOIN veiculos v ON e.veiculo_id = v.id
    JOIN vagas vg ON e.vaga_id = vg.id
    WHERE e.id = ?
  `).get(req.params.id);

  res.json({
    ...resultado,
    horas_permanencia: horas,
    valor_hora: valorHora
  });
});

// Histórico
app.get('/api/estacionamentos/historico', (req, res) => {
  const historico = db.prepare(`
    SELECT e.*, 
           v.placa, v.marca, v.modelo,
           vg.numero as vaga_numero
    FROM estacionamentos e
    JOIN veiculos v ON e.veiculo_id = v.id
    JOIN vagas vg ON e.vaga_id = vg.id
    WHERE e.status = 'finalizado'
    ORDER BY e.data_hora_saida DESC
    LIMIT 50
  `).all();
  res.json(historico);
});

// ============================================
// RELATÓRIOS
// ============================================

app.get('/api/relatorios/ocupacao', (req, res) => {
  const total = db.prepare(`SELECT COUNT(*) as total FROM vagas`).get().total;
  const livres = db.prepare(`SELECT COUNT(*) as total FROM vagas WHERE status = 'livre'`).get().total;
  const ocupadas = db.prepare(`SELECT COUNT(*) as total FROM vagas WHERE status = 'ocupada'`).get().total;
  const porTipo = db.prepare(`
    SELECT tipo, status, COUNT(*) as quantidade
    FROM vagas
    GROUP BY tipo, status
  `).all();

  res.json({
    total_vagas: total,
    livres,
    ocupadas,
    percentual_ocupacao: total > 0 ? ((ocupadas / total) * 100).toFixed(1) : 0,
    detalhe: porTipo
  });
});

app.get('/api/relatorios/faturamento', (req, res) => {
  const hoje = db.prepare(`
    SELECT COALESCE(SUM(valor_calculado), 0) as total
    FROM estacionamentos
    WHERE status = 'finalizado' 
      AND date(data_hora_saida) = date('now')
  `).get().total;

  const mes = db.prepare(`
    SELECT COALESCE(SUM(valor_calculado), 0) as total
    FROM estacionamentos
    WHERE status = 'finalizado' 
      AND strftime('%Y-%m', data_hora_saida) = strftime('%Y-%m', 'now')
  `).get().total;

  res.json({
    faturamento_hoje: hoje,
    faturamento_mes: mes
  });
});

// Rota padrão - serve o frontend
app.get('/', (req, res) => {
  res.sendFile(path.join(__dirname, '../frontend/index.html'));
});

// Inicia o servidor
app.listen(PORT, () => {
  console.log(`\n🚀 Servidor rodando em http://localhost:${PORT}`);
  console.log(`📁 Banco de dados: backend/estacionamento.db\n`);
});
