const Database = require('better-sqlite3');
const path = require('path');

const dbPath = path.join(__dirname, 'estacionamento.db');
const db = new Database(dbPath);

// Ativa foreign keys
db.pragma('foreign_keys = ON');

// Cria as tabelas se não existirem
db.exec(`
  CREATE TABLE IF NOT EXISTS clientes (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    nome TEXT NOT NULL,
    cpf_cnpj TEXT UNIQUE,
    telefone TEXT,
    email TEXT,
    tipo TEXT DEFAULT 'PF' CHECK(tipo IN ('PF', 'PJ')),
    criado_em DATETIME DEFAULT CURRENT_TIMESTAMP
  );

  CREATE TABLE IF NOT EXISTS veiculos (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    placa TEXT NOT NULL UNIQUE,
    marca TEXT,
    modelo TEXT,
    cor TEXT,
    ano INTEGER,
    tipo TEXT DEFAULT 'carro' CHECK(tipo IN ('carro', 'moto', 'utilitario', 'caminhao')),
    tamanho TEXT DEFAULT 'medio' CHECK(tamanho IN ('pequeno', 'medio', 'grande')),
    cliente_id INTEGER,
    FOREIGN KEY (cliente_id) REFERENCES clientes(id) ON DELETE SET NULL
  );

  CREATE TABLE IF NOT EXISTS vagas (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    numero TEXT NOT NULL UNIQUE,
    tipo TEXT DEFAULT 'normal' CHECK(tipo IN ('normal', 'preferencial', 'moto', 'carga')),
    status TEXT DEFAULT 'livre' CHECK(status IN ('livre', 'ocupada', 'reservada', 'bloqueada')),
    setor TEXT DEFAULT 'A'
  );

  CREATE TABLE IF NOT EXISTS precos (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    descricao TEXT NOT NULL,
    tipo_cobranca TEXT NOT NULL CHECK(tipo_cobranca IN ('hora', 'diaria', 'mensal', 'anual')),
    valor REAL NOT NULL,
    tipo_veiculo TEXT DEFAULT 'todos',
    ativo INTEGER DEFAULT 1
  );

  CREATE TABLE IF NOT EXISTS estacionamentos (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    veiculo_id INTEGER NOT NULL,
    vaga_id INTEGER NOT NULL,
    data_hora_entrada DATETIME DEFAULT CURRENT_TIMESTAMP,
    data_hora_saida DATETIME,
    valor_calculado REAL DEFAULT 0,
    status TEXT DEFAULT 'ativo' CHECK(status IN ('ativo', 'finalizado', 'cancelado')),
    observacao TEXT,
    FOREIGN KEY (veiculo_id) REFERENCES veiculos(id),
    FOREIGN KEY (vaga_id) REFERENCES vagas(id)
  );
`);

console.log('Banco de dados inicializado com sucesso!');

module.exports = db;
