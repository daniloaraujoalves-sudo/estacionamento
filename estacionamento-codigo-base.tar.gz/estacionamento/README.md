# Sistema de Estacionamento de Veículos - Código Base

Mini sistema completo (Back-end + Front-end + Banco de Dados) para controle de estacionamento.

## Tecnologias
- **Backend**: Node.js + Express
- **Banco de Dados**: SQLite (arquivo local `estacionamento.db`)
- **Frontend**: HTML + CSS + JavaScript (vanilla)
- **Driver DB**: better-sqlite3

## Como rodar

### 1. Instalar dependências
```bash
cd backend
npm install
```

### 2. Iniciar o servidor
```bash
node server.js
```

O sistema estará disponível em: **http://localhost:3000**

## Estrutura do Projeto
```
estacionamento/
├── backend/
│   ├── package.json
│   ├── server.js          # Servidor principal + rotas
│   ├── database.js        # Conexão e criação das tabelas
│   └── seed.js            # Dados iniciais (opcional)
├── frontend/
│   ├── index.html
│   ├── css/style.css
│   └── js/app.js
└── README.md
```

## Funcionalidades já implementadas no código base
- Cadastro de Clientes
- Cadastro de Veículos (com placa)
- Controle de Vagas (normal / preferencial)
- Entrada e Saída de veículos
- Cálculo automático de valor (hora)
- Listagem de estacionamentos ativos
- Relatório simples de ocupação

## Próximos passos sugeridos
- Adicionar autenticação (login)
- Mais tipos de preço (diária, mensal, anual)
- Relatórios avançados
- Validação de placa Mercosul
- Dashboard com gráficos
