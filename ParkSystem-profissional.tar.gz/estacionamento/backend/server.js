const express = require('express');
const cors = require('cors');
const path = require('path');
const db = require('./database');

const app = express();
const PORT = 3000;

app.use(cors());
app.use(express.json());
app.use(express.static(path.join(__dirname, '../frontend')));

// ============================================
// HELPERS
// ============================================
function ok(res, data, status = 200) {
  return res.status(status).json({ success: true, data });
}

function fail(res, message, status = 400) {
  return res.status(status).json({ success: false, error: message });
}

function validarPlaca(placa) {
  if (!placa) return false;
  const limpa = placa.replace(/[^A-Za-z0-9]/g, '').toUpperCase();
  // Antigo: ABC1234 | Mercosul: ABC1D23
  return /^[A-Z]{3}[0-9][A-Z0-9][0-9]{2}$/.test(limpa) || /^[A-Z]{3}[0-9]{4}$/.test(limpa);
}

function calcularValor(entradaISO, tipoVeiculo) {
  const entrada = new Date(entradaISO);
  const saida = new Date();
  const diffMin = Math.max(1, Math.ceil((saida - entrada) / (1000 * 60)));

  const preco = db.prepare(`
    SELECT valor FROM precos 
    WHERE tipo_cobranca = 'hora' 
      AND (tipo_veiculo = ? OR tipo_veiculo = 'todos') 
      AND ativo = 1
    ORDER BY CASE WHEN tipo_veiculo = ? THEN 0 ELSE 1 END
    LIMIT 1
  `).get(tipoVeiculo, tipoVeiculo);

  const valorHora = preco ? preco.valor : 8.00;

  // Mínimo 1 hora. Depois cobra em blocos de 15 minutos
  let horasCobradas;
  if (diffMin <= 60) {
    horasCobradas = 1;
  } else {
    horasCobradas = Math.ceil(diffMin / 15) * 0.25;
  }

  const valor = Number((horasCobradas * valorHora).toFixed(2));

  return {
    minutos: diffMin,
    horas_cobradas: horasCobradas,
    valor_hora: valorHora,
    valor
  };
}

// ============================================
// CLIENTES
// ============================================
app.get('/api/clientes', (req, res) => {
  try {
    const clientes = db.prepare('SELECT * FROM clientes ORDER BY nome').all();
    ok(res, clientes);
  } catch (err) {
    fail(res, err.message, 500);
  }
});

app.get('/api/clientes/:id', (req, res) => {
  const cliente = db.prepare('SELECT * FROM clientes WHERE id = ?').get(req.params.id);
  if (!cliente) return fail(res, 'Cliente não encontrado', 404);
  ok(res, cliente);
});

app.post('/api/clientes', (req, res) => {
  const { nome, cpf_cnpj, telefone, email, tipo } = req.body;
  if (!nome || nome.trim().length < 2) return fail(res, 'Nome é obrigatório (mín. 2 caracteres)');

  try {
    const result = db.prepare(`
      INSERT INTO clientes (nome, cpf_cnpj, telefone, email, tipo)
      VALUES (?, ?, ?, ?, ?)
    `).run(
      nome.trim(),
      cpf_cnpj?.trim() || null,
      telefone?.trim() || null,
      email?.trim() || null,
      tipo === 'PJ' ? 'PJ' : 'PF'
    );
    const novo = db.prepare('SELECT * FROM clientes WHERE id = ?').get(result.lastInsertRowid);
    ok(res, novo, 201);
  } catch (err) {
    if (err.message.includes('UNIQUE')) return fail(res, 'CPF/CNPJ já cadastrado');
    fail(res, err.message);
  }
});

app.put('/api/clientes/:id', (req, res) => {
  const { nome, cpf_cnpj, telefone, email, tipo } = req.body;
  const result = db.prepare(`
    UPDATE clientes SET nome = ?, cpf_cnpj = ?, telefone = ?, email = ?, tipo = ?
    WHERE id = ?
  `).run(nome, cpf_cnpj, telefone, email, tipo, req.params.id);

  if (result.changes === 0) return fail(res, 'Cliente não encontrado', 404);
  ok(res, { mensagem: 'Cliente atualizado' });
});

app.delete('/api/clientes/:id', (req, res) => {
  const result = db.prepare('DELETE FROM clientes WHERE id = ?').run(req.params.id);
  if (result.changes === 0) return fail(res, 'Cliente não encontrado', 404);
  ok(res, { mensagem: 'Cliente removido' });
});

// ============================================
// VEÍCULOS
// ============================================
app.get('/api/veiculos', (req, res) => {
  const veiculos = db.prepare(`
    SELECT v.*, c.nome as cliente_nome
    FROM veiculos v
    LEFT JOIN clientes c ON v.cliente_id = c.id
    ORDER BY v.placa
  `).all();
  ok(res, veiculos);
});

app.get('/api/veiculos/:id', (req, res) => {
  const veiculo = db.prepare(`
    SELECT v.*, c.nome as cliente_nome
    FROM veiculos v
    LEFT JOIN clientes c ON v.cliente_id = c.id
    WHERE v.id = ?
  `).get(req.params.id);
  if (!veiculo) return fail(res, 'Veículo não encontrado', 404);
  ok(res, veiculo);
});

app.get('/api/veiculos/placa/:placa', (req, res) => {
  const veiculo = db.prepare(`
    SELECT v.*, c.nome as cliente_nome
    FROM veiculos v
    LEFT JOIN clientes c ON v.cliente_id = c.id
    WHERE UPPER(v.placa) = UPPER(?)
  `).get(req.params.placa);
  if (!veiculo) return fail(res, 'Veículo não encontrado', 404);
  ok(res, veiculo);
});

app.post('/api/veiculos', (req, res) => {
  const { placa, marca, modelo, cor, ano, tipo, tamanho, cliente_id } = req.body;

  if (!placa) return fail(res, 'Placa é obrigatória');
  if (!validarPlaca(placa)) return fail(res, 'Placa inválida. Use formato ABC1234 ou ABC1D23');

  try {
    const result = db.prepare(`
      INSERT INTO veiculos (placa, marca, modelo, cor, ano, tipo, tamanho, cliente_id)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?)
    `).run(
      placa.replace(/[^A-Za-z0-9]/g, '').toUpperCase(),
      marca?.trim() || null,
      modelo?.trim() || null,
      cor?.trim() || null,
      ano || null,
      ['carro', 'moto', 'utilitario', 'caminhao'].includes(tipo) ? tipo : 'carro',
      ['pequeno', 'medio', 'grande'].includes(tamanho) ? tamanho : 'medio',
      cliente_id || null
    );
    const novo = db.prepare('SELECT * FROM veiculos WHERE id = ?').get(result.lastInsertRowid);
    ok(res, novo, 201);
  } catch (err) {
    if (err.message.includes('UNIQUE')) return fail(res, 'Placa já cadastrada');
    fail(res, err.message);
  }
});

// ============================================
// VAGAS
// ============================================
app.get('/api/vagas', (req, res) => {
  const vagas = db.prepare('SELECT * FROM vagas ORDER BY setor, numero').all();
  ok(res, vagas);
});

app.get('/api/vagas/livres', (req, res) => {
  const tipo = req.query.tipo;
  let query = `SELECT * FROM vagas WHERE status = 'livre'`;
  if (tipo) query += ` AND tipo = ?`;
  query += ` ORDER BY setor, numero`;

  const vagas = tipo ? db.prepare(query).all(tipo) : db.prepare(query).all();
  ok(res, vagas);
});

app.put('/api/vagas/:id/status', (req, res) => {
  const { status } = req.body;
  if (!['livre', 'ocupada', 'reservada', 'bloqueada'].includes(status)) {
    return fail(res, 'Status inválido');
  }
  const result = db.prepare('UPDATE vagas SET status = ? WHERE id = ?').run(status, req.params.id);
  if (result.changes === 0) return fail(res, 'Vaga não encontrada', 404);
  ok(res, { mensagem: 'Status atualizado' });
});

// ============================================
// PREÇOS
// ============================================
app.get('/api/precos', (req, res) => {
  const precos = db.prepare('SELECT * FROM precos WHERE ativo = 1 ORDER BY tipo_cobranca, tipo_veiculo').all();
  ok(res, precos);
});

app.post('/api/precos', (req, res) => {
  const { descricao, tipo_cobranca, valor, tipo_veiculo } = req.body;
  if (!descricao || !tipo_cobranca || valor == null) {
    return fail(res, 'Campos obrigatórios: descricao, tipo_cobranca, valor');
  }
  if (!['hora', 'diaria', 'mensal', 'anual'].includes(tipo_cobranca)) {
    return fail(res, 'tipo_cobranca inválido');
  }

  const result = db.prepare(`
    INSERT INTO precos (descricao, tipo_cobranca, valor, tipo_veiculo)
    VALUES (?, ?, ?, ?)
  `).run(descricao, tipo_cobranca, Number(valor), tipo_veiculo || 'todos');

  const novo = db.prepare('SELECT * FROM precos WHERE id = ?').get(result.lastInsertRowid);
  ok(res, novo, 201);
});

// ============================================
// ESTACIONAMENTO
// ============================================
app.get('/api/estacionamentos/ativos', (req, res) => {
  const ativos = db.prepare(`
    SELECT e.*, 
           v.placa, v.marca, v.modelo, v.cor, v.tipo as tipo_veiculo,
           vg.numero as vaga_numero, vg.tipo as vaga_tipo, vg.setor,
           c.nome as cliente_nome
    FROM estacionamentos e
    JOIN veiculos v ON e.veiculo_id = v.id
    JOIN vagas vg ON e.vaga_id = vg.id
    LEFT JOIN clientes c ON v.cliente_id = c.id
    WHERE e.status = 'ativo'
    ORDER BY e.data_hora_entrada DESC
  `).all();
  ok(res, ativos);
});

app.post('/api/estacionamentos/entrada', (req, res) => {
  const { placa, vaga_id, observacao } = req.body;

  if (!placa || !vaga_id) return fail(res, 'Placa e vaga são obrigatórios');

  const placaLimpa = placa.replace(/[^A-Za-z0-9]/g, '').toUpperCase();
  if (!validarPlaca(placaLimpa)) return fail(res, 'Placa inválida');

  const veiculo = db.prepare('SELECT * FROM veiculos WHERE UPPER(placa) = ?').get(placaLimpa);
  if (!veiculo) return fail(res, 'Veículo não cadastrado. Cadastre o veículo primeiro.', 404);

  const jaEstacionado = db.prepare(`
    SELECT id FROM estacionamentos WHERE veiculo_id = ? AND status = 'ativo'
  `).get(veiculo.id);
  if (jaEstacionado) return fail(res, 'Este veículo já está estacionado');

  const vaga = db.prepare('SELECT * FROM vagas WHERE id = ?').get(vaga_id);
  if (!vaga) return fail(res, 'Vaga não encontrada', 404);
  if (vaga.status !== 'livre') return fail(res, 'Vaga não está disponível');

  try {
    const id = db.transaction(() => {
      const result = db.prepare(`
        INSERT INTO estacionamentos (veiculo_id, vaga_id, observacao)
        VALUES (?, ?, ?)
      `).run(veiculo.id, vaga_id, observacao?.trim() || null);

      db.prepare(`UPDATE vagas SET status = 'ocupada' WHERE id = ?`).run(vaga_id);
      return result.lastInsertRowid;
    })();

    const registro = db.prepare(`
      SELECT e.*, v.placa, vg.numero as vaga_numero, vg.tipo as vaga_tipo
      FROM estacionamentos e
      JOIN veiculos v ON e.veiculo_id = v.id
      JOIN vagas vg ON e.vaga_id = vg.id
      WHERE e.id = ?
    `).get(id);

    ok(res, registro, 201);
  } catch (err) {
    fail(res, err.message, 500);
  }
});

app.post('/api/estacionamentos/saida/:id', (req, res) => {
  const estacionamento = db.prepare(`
    SELECT e.*, v.tipo as tipo_veiculo, v.placa
    FROM estacionamentos e
    JOIN veiculos v ON e.veiculo_id = v.id
    WHERE e.id = ? AND e.status = 'ativo'
  `).get(req.params.id);

  if (!estacionamento) return fail(res, 'Estacionamento ativo não encontrado', 404);

  const calc = calcularValor(estacionamento.data_hora_entrada, estacionamento.tipo_veiculo);

  try {
    db.transaction(() => {
      db.prepare(`
        UPDATE estacionamentos 
        SET data_hora_saida = CURRENT_TIMESTAMP,
            valor_calculado = ?,
            status = 'finalizado'
        WHERE id = ?
      `).run(calc.valor, req.params.id);

      db.prepare(`UPDATE vagas SET status = 'livre' WHERE id = ?`).run(estacionamento.vaga_id);
    })();

    const resultado = db.prepare(`
      SELECT e.*, v.placa, vg.numero as vaga_numero
      FROM estacionamentos e
      JOIN veiculos v ON e.veiculo_id = v.id
      JOIN vagas vg ON e.vaga_id = vg.id
      WHERE e.id = ?
    `).get(req.params.id);

    ok(res, {
      ...resultado,
      minutos_permanencia: calc.minutos,
      horas_cobradas: calc.horas_cobradas,
      valor_hora: calc.valor_hora
    });
  } catch (err) {
    fail(res, err.message, 500);
  }
});

app.get('/api/estacionamentos/historico', (req, res) => {
  const historico = db.prepare(`
    SELECT e.*, 
           v.placa, v.marca, v.modelo,
           vg.numero as vaga_numero
    FROM estacionamentos e
    JOIN veiculos v ON e.veiculo_id = v.id
    JOIN vagas vg ON e.vaga_id = vg.id
    WHERE e.status = 'finalizado'
    ORDER BY e.data_hora_saida DESC
    LIMIT 100
  `).all();
  ok(res, historico);
});

// ============================================
// RELATÓRIOS
// ============================================
app.get('/api/relatorios/ocupacao', (req, res) => {
  const total = db.prepare(`SELECT COUNT(*) as total FROM vagas`).get().total;
  const livres = db.prepare(`SELECT COUNT(*) as total FROM vagas WHERE status = 'livre'`).get().total;
  const ocupadas = db.prepare(`SELECT COUNT(*) as total FROM vagas WHERE status = 'ocupada'`).get().total;
  const porTipo = db.prepare(`
    SELECT tipo, status, COUNT(*) as quantidade
    FROM vagas
    GROUP BY tipo, status
    ORDER BY tipo, status
  `).all();

  ok(res, {
    total_vagas: total,
    livres,
    ocupadas,
    percentual_ocupacao: total > 0 ? Number(((ocupadas / total) * 100).toFixed(1)) : 0,
    detalhe: porTipo
  });
});

app.get('/api/relatorios/faturamento', (req, res) => {
  const hoje = db.prepare(`
    SELECT COALESCE(SUM(valor_calculado), 0) as total,
           COUNT(*) as quantidade
    FROM estacionamentos
    WHERE status = 'finalizado' AND date(data_hora_saida) = date('now')
  `).get();

  const mes = db.prepare(`
    SELECT COALESCE(SUM(valor_calculado), 0) as total,
           COUNT(*) as quantidade
    FROM estacionamentos
    WHERE status = 'finalizado' AND strftime('%Y-%m', data_hora_saida) = strftime('%Y-%m', 'now')
  `).get();

  ok(res, {
    faturamento_hoje: hoje.total,
    qtd_hoje: hoje.quantidade,
    faturamento_mes: mes.total,
    qtd_mes: mes.quantidade
  });
});

// ============================================
// FRONTEND + START
// ============================================
app.get('/', (req, res) => {
  res.sendFile(path.join(__dirname, '../frontend/index.html'));
});

app.use((req, res) => {
  fail(res, 'Rota não encontrada', 404);
});

app.listen(PORT, () => {
  console.log(`\n  🚀  Sistema de Estacionamento`);
  console.log(`  ➜  Local:   http://localhost:${PORT}`);
  console.log(`  ➜  Banco:   backend/estacionamento.db\n`);
});
