# ParkSystem — Sistema de Estacionamento

Sistema profissional de gestão de estacionamento (Back-end + Front-end + Banco de Dados).

## Tecnologias
- **Backend**: Node.js + Express
- **Banco de Dados**: SQLite (better-sqlite3)
- **Frontend**: HTML + CSS + JavaScript (vanilla, interface moderna)

## Como rodar

```bash
cd backend
npm install
node seed.js      # carrega dados de exemplo
node server.js
```

Acesse: **http://localhost:3000**

## Funcionalidades

- Dashboard com ocupação e faturamento em tempo real
- Entrada e saída de veículos com cálculo automático de valor
- Validação de placa (formato antigo e Mercosul)
- Controle visual de vagas (normal, preferencial, moto)
- Cadastro de clientes e veículos
- Histórico de movimentações
- Cobrança por hora com fração de 15 minutos (mínimo 1h)
- Interface responsiva com sidebar profissional

## Estrutura

```
estacionamento/
├── backend/
│   ├── package.json
│   ├── database.js
│   ├── seed.js
│   └── server.js
├── frontend/
│   ├── index.html
│   ├── css/style.css
│   └── js/app.js
└── README.md
```

## Placas de exemplo (seed)

- `ABC1D23` — Toyota Corolla
- `XYZ9K87` — Honda CG 160
- `DEF4G56` — Volkswagen Gol

## Fluxo de uso

1. Cadastre o **cliente** (opcional)
2. Cadastre o **veículo** (obrigatório)
3. Faça a **entrada** escolhendo uma vaga livre
4. Na **saída**, o valor é calculado automaticamente
