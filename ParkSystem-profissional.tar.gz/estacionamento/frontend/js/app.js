const API = 'http://localhost:3000/api';

const TITULOS = {
  dashboard: 'Dashboard',
  entrada: 'Entrada de Veículo',
  saida: 'Saída de Veículo',
  vagas: 'Mapa de Vagas',
  veiculos: 'Veículos',
  clientes: 'Clientes',
  historico: 'Histórico'
};

// ============================================
// UTILITÁRIOS
// ============================================
function toast(msg, tipo = 'success') {
  const el = document.getElementById('toast');
  el.textContent = msg;
  el.className = `toast ${tipo} show`;
  setTimeout(() => el.classList.remove('show'), 3500);
}

async function api(path, options = {}) {
  const res = await fetch(`${API}${path}`, {
    headers: { 'Content-Type': 'application/json', ...options.headers },
    ...options
  });
  const json = await res.json();
  if (!json.success) throw new Error(json.error || 'Erro desconhecido');
  return json.data;
}

function formatarData(str) {
  if (!str) return '—';
  return new Date(str).toLocaleString('pt-BR', {
    day: '2-digit', month: '2-digit', year: 'numeric',
    hour: '2-digit', minute: '2-digit'
  });
}

function formatarMoeda(v) {
  return 'R$ ' + Number(v || 0).toFixed(2).replace('.', ',');
}

function atualizarRelogio() {
  const agora = new Date();
  document.getElementById('clock').textContent = agora.toLocaleString('pt-BR', {
    weekday: 'short', day: '2-digit', month: 'short',
    hour: '2-digit', minute: '2-digit', second: '2-digit'
  });
}
setInterval(atualizarRelogio, 1000);
atualizarRelogio();

// ============================================
// NAVEGAÇÃO
// ============================================
document.querySelectorAll('.nav-item').forEach(btn => {
  btn.addEventListener('click', () => {
    document.querySelectorAll('.nav-item').forEach(b => b.classList.remove('active'));
    document.querySelectorAll('.page').forEach(p => p.classList.remove('active'));
    btn.classList.add('active');
    const page = btn.dataset.page;
    document.getElementById(page).classList.add('active');
    document.getElementById('page-title').textContent = TITULOS[page] || page;

    if (page === 'dashboard') carregarDashboard();
    if (page === 'entrada') carregarVagasLivres();
    if (page === 'saida') carregarAtivosParaSaida();
    if (page === 'vagas') carregarVagas();
    if (page === 'veiculos') carregarVeiculos();
    if (page === 'clientes') carregarClientes();
    if (page === 'historico') carregarHistorico();
  });
});

// ============================================
// DASHBOARD
// ============================================
async function carregarDashboard() {
  try {
    const [ocupacao, faturamento, ativos] = await Promise.all([
      api('/relatorios/ocupacao'),
      api('/relatorios/faturamento'),
      api('/estacionamentos/ativos')
    ]);

    document.getElementById('qtd-livres').textContent = ocupacao.livres;
    document.getElementById('qtd-ocupadas').textContent = ocupacao.ocupadas;
    document.getElementById('percentual').textContent = ocupacao.percentual_ocupacao + '%';
    document.getElementById('faturamento-hoje').textContent = formatarMoeda(faturamento.faturamento_hoje);
    document.getElementById('badge-ativos').textContent = ativos.length + ' ativos';

    const tbody = document.getElementById('tbody-ativos');
    if (ativos.length === 0) {
      tbody.innerHTML = '<tr><td colspan="5" class="empty">Nenhum veículo no pátio no momento</td></tr>';
      return;
    }

    tbody.innerHTML = ativos.map(e => `
      <tr>
        <td><span class="placa">${e.placa}</span></td>
        <td>${[e.marca, e.modelo].filter(Boolean).join(' ') || '—'} ${e.cor ? `<span style="color:#94a3b8">(${e.cor})</span>` : ''}</td>
        <td>${e.vaga_numero} <span style="color:#94a3b8;font-size:12px">${e.vaga_tipo}</span></td>
        <td>${formatarData(e.data_hora_entrada)}</td>
        <td>${e.cliente_nome || '—'}</td>
      </tr>
    `).join('');
  } catch (err) {
    console.error(err);
    toast(err.message, 'error');
  }
}

// ============================================
// ENTRADA
// ============================================
async function carregarVagasLivres() {
  const select = document.getElementById('entrada-vaga');
  select.innerHTML = '<option value="">Carregando...</option>';
  try {
    const vagas = await api('/vagas/livres');
    if (vagas.length === 0) {
      select.innerHTML = '<option value="">Nenhuma vaga livre</option>';
      return;
    }
    select.innerHTML = '<option value="">Selecione a vaga...</option>' +
      vagas.map(v => `<option value="${v.id}">${v.numero} — ${v.tipo} (Setor ${v.setor})</option>`).join('');
  } catch {
    select.innerHTML = '<option value="">Erro ao carregar</option>';
  }
}

document.getElementById('form-entrada').addEventListener('submit', async (e) => {
  e.preventDefault();
  const btn = e.target.querySelector('button[type=submit]');
  btn.disabled = true;
  btn.textContent = 'Registrando...';

  try {
    const data = await api('/estacionamentos/entrada', {
      method: 'POST',
      body: JSON.stringify({
        placa: document.getElementById('entrada-placa').value.trim(),
        vaga_id: Number(document.getElementById('entrada-vaga').value),
        observacao: document.getElementById('entrada-obs').value.trim()
      })
    });
    toast(`Entrada registrada: ${data.placa} → vaga ${data.vaga_numero}`);
    e.target.reset();
    carregarVagasLivres();
  } catch (err) {
    toast(err.message, 'error');
  } finally {
    btn.disabled = false;
    btn.textContent = 'Confirmar Entrada';
  }
});

// ============================================
// SAÍDA
// ============================================
async function carregarAtivosParaSaida() {
  const tbody = document.getElementById('tbody-saida');
  tbody.innerHTML = '<tr><td colspan="5" class="empty">Carregando...</td></tr>';

  try {
    const ativos = await api('/estacionamentos/ativos');
    document.getElementById('badge-saida').textContent = ativos.length + ' veículos';

    if (ativos.length === 0) {
      tbody.innerHTML = '<tr><td colspan="5" class="empty">Nenhum veículo para saída</td></tr>';
      return;
    }

    tbody.innerHTML = ativos.map(e => `
      <tr>
        <td><span class="placa">${e.placa}</span></td>
        <td>${[e.marca, e.modelo].filter(Boolean).join(' ') || '—'}</td>
        <td>${e.vaga_numero}</td>
        <td>${formatarData(e.data_hora_entrada)}</td>
        <td><button class="btn btn-success" onclick="registrarSaida(${e.id})">Finalizar</button></td>
      </tr>
    `).join('');
  } catch (err) {
    tbody.innerHTML = '<tr><td colspan="5" class="empty">Erro ao carregar</td></tr>';
  }
}

async function registrarSaida(id) {
  if (!confirm('Confirmar saída deste veículo?')) return;
  try {
    const data = await api(`/estacionamentos/saida/${id}`, { method: 'POST' });
    toast(`Saída OK — ${data.placa} | ${data.horas_cobradas}h | ${formatarMoeda(data.valor_calculado)}`);
    carregarAtivosParaSaida();
  } catch (err) {
    toast(err.message, 'error');
  }
}

// ============================================
// VAGAS
// ============================================
let todasVagas = [];

async function carregarVagas() {
  try {
    todasVagas = await api('/vagas');
    renderVagas('todos');
  } catch (err) {
    toast(err.message, 'error');
  }
}

function renderVagas(filtro) {
  let lista = todasVagas;
  if (filtro === 'livre') lista = todasVagas.filter(v => v.status === 'livre');
  if (filtro === 'ocupada') lista = todasVagas.filter(v => v.status === 'ocupada');
  if (filtro === 'preferencial') lista = todasVagas.filter(v => v.tipo === 'preferencial');

  const grid = document.getElementById('grid-vagas');
  grid.innerHTML = lista.map(v => `
    <div class="vaga ${v.status} ${v.tipo === 'preferencial' ? 'preferencial' : ''}">
      <span class="vaga-num">${v.numero}</span>
      <span class="vaga-tipo">${v.tipo}</span>
    </div>
  `).join('');
}

document.querySelectorAll('.chip').forEach(btn => {
  btn.addEventListener('click', () => {
    document.querySelectorAll('.chip').forEach(b => b.classList.remove('active'));
    btn.classList.add('active');
    renderVagas(btn.dataset.filtro);
  });
});

// ============================================
// VEÍCULOS
// ============================================
async function carregarVeiculos() {
  try {
    const [veiculos, clientes] = await Promise.all([
      api('/veiculos'),
      api('/clientes')
    ]);

    const tbody = document.getElementById('tbody-veiculos');
    if (veiculos.length === 0) {
      tbody.innerHTML = '<tr><td colspan="6" class="empty">Nenhum veículo cadastrado</td></tr>';
    } else {
      tbody.innerHTML = veiculos.map(v => `
        <tr>
          <td><span class="placa">${v.placa}</span></td>
          <td>${[v.marca, v.modelo].filter(Boolean).join(' ') || '—'}</td>
          <td>${v.cor || '—'}</td>
          <td>${v.ano || '—'}</td>
          <td>${v.tipo}</td>
          <td>${v.cliente_nome || '—'}</td>
        </tr>
      `).join('');
    }

    const select = document.getElementById('vei-cliente');
    select.innerHTML = '<option value="">Sem vínculo</option>' +
      clientes.map(c => `<option value="${c.id}">${c.nome}</option>`).join('');
  } catch (err) {
    toast(err.message, 'error');
  }
}

function abrirModalVeiculo() {
  document.getElementById('form-veiculo').reset();
  document.getElementById('modal-veiculo').classList.add('open');
}

document.getElementById('form-veiculo').addEventListener('submit', async (e) => {
  e.preventDefault();
  try {
    await api('/veiculos', {
      method: 'POST',
      body: JSON.stringify({
        placa: document.getElementById('vei-placa').value.trim(),
        marca: document.getElementById('vei-marca').value.trim(),
        modelo: document.getElementById('vei-modelo').value.trim(),
        cor: document.getElementById('vei-cor').value.trim(),
        ano: document.getElementById('vei-ano').value || null,
        tipo: document.getElementById('vei-tipo').value,
        tamanho: document.getElementById('vei-tamanho').value,
        cliente_id: document.getElementById('vei-cliente').value || null
      })
    });
    toast('Veículo cadastrado com sucesso');
    fecharModal('modal-veiculo');
    carregarVeiculos();
  } catch (err) {
    toast(err.message, 'error');
  }
});

// ============================================
// CLIENTES
// ============================================
async function carregarClientes() {
  try {
    const clientes = await api('/clientes');
    const tbody = document.getElementById('tbody-clientes');
    if (clientes.length === 0) {
      tbody.innerHTML = '<tr><td colspan="5" class="empty">Nenhum cliente cadastrado</td></tr>';
      return;
    }
    tbody.innerHTML = clientes.map(c => `
      <tr>
        <td><strong>${c.nome}</strong></td>
        <td>${c.cpf_cnpj || '—'}</td>
        <td>${c.telefone || '—'}</td>
        <td>${c.email || '—'}</td>
        <td>${c.tipo}</td>
      </tr>
    `).join('');
  } catch (err) {
    toast(err.message, 'error');
  }
}

function abrirModalCliente() {
  document.getElementById('form-cliente').reset();
  document.getElementById('modal-cliente').classList.add('open');
}

document.getElementById('form-cliente').addEventListener('submit', async (e) => {
  e.preventDefault();
  try {
    await api('/clientes', {
      method: 'POST',
      body: JSON.stringify({
        nome: document.getElementById('cli-nome').value.trim(),
        cpf_cnpj: document.getElementById('cli-cpf').value.trim(),
        telefone: document.getElementById('cli-telefone').value.trim(),
        email: document.getElementById('cli-email').value.trim(),
        tipo: document.getElementById('cli-tipo').value
      })
    });
    toast('Cliente cadastrado com sucesso');
    fecharModal('modal-cliente');
    carregarClientes();
  } catch (err) {
    toast(err.message, 'error');
  }
});

// ============================================
// HISTÓRICO
// ============================================
async function carregarHistorico() {
  try {
    const historico = await api('/estacionamentos/historico');
    const tbody = document.getElementById('tbody-historico');
    if (historico.length === 0) {
      tbody.innerHTML = '<tr><td colspan="6" class="empty">Nenhum registro ainda</td></tr>';
      return;
    }
    tbody.innerHTML = historico.map(e => `
      <tr>
        <td><span class="placa">${e.placa}</span></td>
        <td>${[e.marca, e.modelo].filter(Boolean).join(' ') || '—'}</td>
        <td>${e.vaga_numero}</td>
        <td>${formatarData(e.data_hora_entrada)}</td>
        <td>${formatarData(e.data_hora_saida)}</td>
        <td><strong>${formatarMoeda(e.valor_calculado)}</strong></td>
      </tr>
    `).join('');
  } catch (err) {
    toast(err.message, 'error');
  }
}

// ============================================
// MODAIS
// ============================================
function fecharModal(id) {
  document.getElementById(id).classList.remove('open');
}

document.querySelectorAll('.modal').forEach(m => {
  m.addEventListener('click', (e) => {
    if (e.target === m) m.classList.remove('open');
  });
});

// Inicia
carregarDashboard();
