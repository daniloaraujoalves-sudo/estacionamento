const Database = require('better-sqlite3');
const path = require('path');

const dbPath = path.join(__dirname, 'estacionamento.db');
const db = new Database(dbPath);

db.pragma('foreign_keys = ON');

db.exec(`
  CREATE TABLE IF NOT EXISTS clientes (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    nome TEXT NOT NULL,
    cpf_cnpj TEXT UNIQUE,
    telefone TEXT,
    email TEXT,
    tipo TEXT DEFAULT 'PF' CHECK(tipo IN ('PF', 'PJ')),
    plano TEXT DEFAULT 'avulso' CHECK(plano IN ('avulso', 'mensal', 'anual')),
    plano_inicio DATE,
    plano_validade DATE,
    criado_em DATETIME DEFAULT CURRENT_TIMESTAMP
  );

  CREATE TABLE IF NOT EXISTS veiculos (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    placa TEXT NOT NULL UNIQUE,
    marca TEXT,
    modelo TEXT,
    cor TEXT,
    ano INTEGER,
    tipo TEXT DEFAULT 'carro' CHECK(tipo IN ('carro', 'moto', 'utilitario', 'caminhao')),
    tamanho TEXT DEFAULT 'medio' CHECK(tamanho IN ('pequeno', 'medio', 'grande')),
    cliente_id INTEGER,
    FOREIGN KEY (cliente_id) REFERENCES clientes(id) ON DELETE SET NULL
  );

  CREATE TABLE IF NOT EXISTS vagas (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    numero TEXT NOT NULL UNIQUE,
    tipo TEXT DEFAULT 'normal' CHECK(tipo IN ('normal', 'preferencial', 'moto', 'carga')),
    status TEXT DEFAULT 'livre' CHECK(status IN ('livre', 'ocupada', 'reservada', 'bloqueada')),
    setor TEXT DEFAULT 'A'
  );

  CREATE TABLE IF NOT EXISTS precos (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    descricao TEXT NOT NULL,
    tipo_cobranca TEXT NOT NULL CHECK(tipo_cobranca IN ('hora', 'diaria', 'mensal', 'anual')),
    valor REAL NOT NULL,
    tipo_veiculo TEXT DEFAULT 'todos',
    ativo INTEGER DEFAULT 1
  );

  CREATE TABLE IF NOT EXISTS estacionamentos (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    veiculo_id INTEGER NOT NULL,
    vaga_id INTEGER NOT NULL,
    data_hora_entrada DATETIME DEFAULT CURRENT_TIMESTAMP,
    data_hora_saida DATETIME,
    valor_calculado REAL DEFAULT 0,
    tipo_cobranca TEXT DEFAULT 'hora',
    status TEXT DEFAULT 'ativo' CHECK(status IN ('ativo', 'finalizado', 'cancelado')),
    observacao TEXT,
    FOREIGN KEY (veiculo_id) REFERENCES veiculos(id),
    FOREIGN KEY (vaga_id) REFERENCES vagas(id)
  );

  CREATE TABLE IF NOT EXISTS pagamentos_plano (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    cliente_id INTEGER NOT NULL,
    tipo_plano TEXT NOT NULL CHECK(tipo_plano IN ('mensal', 'anual')),
    valor REAL NOT NULL,
    data_pagamento DATETIME DEFAULT CURRENT_TIMESTAMP,
    validade_inicio DATE,
    validade_fim DATE,
    observacao TEXT,
    FOREIGN KEY (cliente_id) REFERENCES clientes(id) ON DELETE CASCADE
  );
`);

// Migrações suaves
const colsClientes = db.prepare(`PRAGMA table_info(clientes)`).all().map(c => c.name);
if (!colsClientes.includes('plano')) {
  db.exec(`ALTER TABLE clientes ADD COLUMN plano TEXT DEFAULT 'avulso'`);
}
if (!colsClientes.includes('plano_inicio')) {
  db.exec(`ALTER TABLE clientes ADD COLUMN plano_inicio DATE`);
}
if (!colsClientes.includes('plano_validade')) {
  db.exec(`ALTER TABLE clientes ADD COLUMN plano_validade DATE`);
}

const colsEst = db.prepare(`PRAGMA table_info(estacionamentos)`).all().map(c => c.name);
if (!colsEst.includes('tipo_cobranca')) {
  db.exec(`ALTER TABLE estacionamentos ADD COLUMN tipo_cobranca TEXT DEFAULT 'hora'`);
}

console.log('Banco de dados inicializado com sucesso!');

module.exports = db;
