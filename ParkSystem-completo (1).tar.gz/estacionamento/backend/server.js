const express = require('express');
const cors = require('cors');
const path = require('path');
const db = require('./database');

const app = express();
const PORT = 3000;

app.use(cors());
app.use(express.json());
app.use(express.static(path.join(__dirname, '../frontend')));

// ============================================
// HELPERS
// ============================================
function ok(res, data, status = 200) {
  return res.status(status).json({ success: true, data });
}
function fail(res, message, status = 400) {
  return res.status(status).json({ success: false, error: message });
}

function validarPlaca(placa) {
  if (!placa) return false;
  const limpa = placa.replace(/[^A-Za-z0-9]/g, '').toUpperCase();
  return /^[A-Z]{3}[0-9][A-Z0-9][0-9]{2}$/.test(limpa) || /^[A-Z]{3}[0-9]{4}$/.test(limpa);
}

function buscarPreco(tipoCobranca, tipoVeiculo) {
  const row = db.prepare(`
    SELECT valor FROM precos
    WHERE tipo_cobranca = ? AND ativo = 1
      AND (tipo_veiculo = ? OR tipo_veiculo = 'todos')
    ORDER BY CASE WHEN tipo_veiculo = ? THEN 0 ELSE 1 END
    LIMIT 1
  `).get(tipoCobranca, tipoVeiculo, tipoVeiculo);
  return row ? row.valor : null;
}

/**
 * Calcula valor de acordo com o tipo de cobrança.
 * x = preço unitário | t = minutos
 *
 * hora:   mínimo 1h, depois blocos de 15 min
 * diaria: valor fixo da diária
 * mensal/anual: R$ 0 (cliente assinante)
 */
function planoAindaValido(planoValidade) {
  if (!planoValidade) return true; // sem data = considera válido
  const hoje = new Date();
  hoje.setHours(0,0,0,0);
  const fim = new Date(planoValidade + 'T23:59:59');
  return fim >= hoje;
}

function calcularValor(entradaISO, tipoVeiculo, tipoCobranca = 'hora', planoCliente = 'avulso', planoValidade = null) {
  const entrada = new Date(entradaISO);
  const saida = new Date();
  const diffMin = Math.max(1, Math.ceil((saida - entrada) / (1000 * 60)));
  const diffHoras = diffMin / 60;

  // Cliente com plano mensal/anual válido não paga na saída
  if ((planoCliente === 'mensal' || planoCliente === 'anual') && planoAindaValido(planoValidade)) {
    return {
      minutos: diffMin,
      horas: Number(diffHoras.toFixed(2)),
      tipo_cobranca: planoCliente,
      valor_unitario: 0,
      valor: 0,
      detalhe: `Cliente com plano ${planoCliente} válido até ${planoValidade || '—'} — sem cobrança na saída`
    };
  }

  if (tipoCobranca === 'diaria') {
    const valorDiaria = buscarPreco('diaria', tipoVeiculo) ?? 40;
    return {
      minutos: diffMin,
      horas: Number(diffHoras.toFixed(2)),
      tipo_cobranca: 'diaria',
      valor_unitario: valorDiaria,
      valor: Number(valorDiaria.toFixed(2)),
      detalhe: `Diária (R$ ${valorDiaria.toFixed(2)})`
    };
  }

  // Padrão: hora
  const valorHora = buscarPreco('hora', tipoVeiculo) ?? 8;
  let horasCobradas;
  if (diffMin <= 60) {
    horasCobradas = 1;
  } else {
    horasCobradas = Math.ceil(diffMin / 15) * 0.25;
  }
  const valor = Number((horasCobradas * valorHora).toFixed(2));

  return {
    minutos: diffMin,
    horas: Number(diffHoras.toFixed(2)),
    horas_cobradas: horasCobradas,
    tipo_cobranca: 'hora',
    valor_unitario: valorHora,
    valor,
    detalhe: `${horasCobradas}h × R$ ${valorHora.toFixed(2)}`
  };
}

// Sugere a melhor cobrança (hora vs diária)
function sugerirCobranca(entradaISO, tipoVeiculo) {
  const porHora = calcularValor(entradaISO, tipoVeiculo, 'hora');
  const porDiaria = calcularValor(entradaISO, tipoVeiculo, 'diaria');
  const sugestao = porHora.valor <= porDiaria.valor ? 'hora' : 'diaria';
  return { porHora, porDiaria, sugestao };
}

// ============================================
// CLIENTES
// ============================================
app.get('/api/clientes', (req, res) => {
  try {
    ok(res, db.prepare('SELECT * FROM clientes ORDER BY nome').all());
  } catch (err) {
    fail(res, err.message, 500);
  }
});

app.get('/api/clientes/:id', (req, res) => {
  const c = db.prepare('SELECT * FROM clientes WHERE id = ?').get(req.params.id);
  if (!c) return fail(res, 'Cliente não encontrado', 404);
  ok(res, c);
});

app.post('/api/clientes', (req, res) => {
  const { nome, cpf_cnpj, telefone, email, tipo, plano } = req.body;
  if (!nome || nome.trim().length < 2) return fail(res, 'Nome é obrigatório (mín. 2 caracteres)');

  const planoFinal = ['mensal', 'anual'].includes(plano) ? plano : 'avulso';
  let planoInicio = null;
  let planoValidade = null;
  let valorPlano = 0;

  if (planoFinal === 'mensal' || planoFinal === 'anual') {
    valorPlano = buscarPreco(planoFinal, 'carro') ?? buscarPreco(planoFinal, 'todos');
    if (valorPlano == null) {
      return fail(res, `Não há preço cadastrado para plano ${planoFinal}. Cadastre em Preços primeiro.`);
    }
    const hoje = new Date();
    planoInicio = hoje.toISOString().slice(0, 10);
    const fim = new Date(hoje);
    if (planoFinal === 'mensal') fim.setMonth(fim.getMonth() + 1);
    else fim.setFullYear(fim.getFullYear() + 1);
    planoValidade = fim.toISOString().slice(0, 10);
  }

  try {
    const cliente = db.transaction(() => {
      const result = db.prepare(`
        INSERT INTO clientes (nome, cpf_cnpj, telefone, email, tipo, plano, plano_inicio, plano_validade)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?)
      `).run(
        nome.trim(),
        cpf_cnpj?.trim() || null,
        telefone?.trim() || null,
        email?.trim() || null,
        tipo === 'PJ' ? 'PJ' : 'PF',
        planoFinal,
        planoInicio,
        planoValidade
      );
      const id = result.lastInsertRowid;

      if (planoFinal !== 'avulso' && valorPlano > 0) {
        db.prepare(`
          INSERT INTO pagamentos_plano (cliente_id, tipo_plano, valor, validade_inicio, validade_fim, observacao)
          VALUES (?, ?, ?, ?, ?, ?)
        `).run(id, planoFinal, valorPlano, planoInicio, planoValidade, `Assinatura ${planoFinal} no cadastro`);
      }

      return db.prepare('SELECT * FROM clientes WHERE id = ?').get(id);
    })();

    ok(res, {
      ...cliente,
      pagamento_plano: planoFinal !== 'avulso' ? {
        tipo: planoFinal,
        valor: valorPlano,
        validade: planoValidade,
        mensagem: `Plano ${planoFinal} cobrado: R$ ${Number(valorPlano).toFixed(2)} — válido até ${planoValidade}`
      } : null
    }, 201);
  } catch (err) {
    if (err.message.includes('UNIQUE')) return fail(res, 'CPF/CNPJ já cadastrado');
    fail(res, err.message);
  }
});

app.put('/api/clientes/:id', (req, res) => {
  const { nome, cpf_cnpj, telefone, email, tipo, plano } = req.body;
  const result = db.prepare(`
    UPDATE clientes SET nome=?, cpf_cnpj=?, telefone=?, email=?, tipo=?, plano=?
    WHERE id=?
  `).run(nome, cpf_cnpj, telefone, email, tipo, plano || 'avulso', req.params.id);
  if (result.changes === 0) return fail(res, 'Cliente não encontrado', 404);
  ok(res, { mensagem: 'Cliente atualizado' });
});

app.delete('/api/clientes/:id', (req, res) => {
  const result = db.prepare('DELETE FROM clientes WHERE id = ?').run(req.params.id);
  if (result.changes === 0) return fail(res, 'Cliente não encontrado', 404);
  ok(res, { mensagem: 'Cliente removido' });
});

// ============================================
// VEÍCULOS
// ============================================
app.get('/api/veiculos', (req, res) => {
  ok(res, db.prepare(`
    SELECT v.*, c.nome as cliente_nome, c.plano as cliente_plano
    FROM veiculos v
    LEFT JOIN clientes c ON v.cliente_id = c.id
    ORDER BY v.placa
  `).all());
});

app.get('/api/veiculos/:id', (req, res) => {
  const v = db.prepare(`
    SELECT v.*, c.nome as cliente_nome, c.plano as cliente_plano
    FROM veiculos v LEFT JOIN clientes c ON v.cliente_id = c.id
    WHERE v.id = ?
  `).get(req.params.id);
  if (!v) return fail(res, 'Veículo não encontrado', 404);
  ok(res, v);
});

app.get('/api/veiculos/placa/:placa', (req, res) => {
  const v = db.prepare(`
    SELECT v.*, c.nome as cliente_nome, c.plano as cliente_plano
    FROM veiculos v LEFT JOIN clientes c ON v.cliente_id = c.id
    WHERE UPPER(v.placa) = UPPER(?)
  `).get(req.params.placa);
  if (!v) return fail(res, 'Veículo não encontrado', 404);
  ok(res, v);
});

app.post('/api/veiculos', (req, res) => {
  const { placa, marca, modelo, cor, ano, tipo, tamanho, cliente_id } = req.body;
  if (!placa) return fail(res, 'Placa é obrigatória');
  if (!validarPlaca(placa)) return fail(res, 'Placa inválida. Use formato ABC1234 ou ABC1D23');
  try {
    const result = db.prepare(`
      INSERT INTO veiculos (placa, marca, modelo, cor, ano, tipo, tamanho, cliente_id)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?)
    `).run(
      placa.replace(/[^A-Za-z0-9]/g, '').toUpperCase(),
      marca?.trim() || null,
      modelo?.trim() || null,
      cor?.trim() || null,
      ano || null,
      ['carro', 'moto', 'utilitario', 'caminhao'].includes(tipo) ? tipo : 'carro',
      ['pequeno', 'medio', 'grande'].includes(tamanho) ? tamanho : 'medio',
      cliente_id || null
    );
    ok(res, db.prepare('SELECT * FROM veiculos WHERE id = ?').get(result.lastInsertRowid), 201);
  } catch (err) {
    if (err.message.includes('UNIQUE')) return fail(res, 'Placa já cadastrada');
    fail(res, err.message);
  }
});

// ============================================
// VAGAS
// ============================================
app.get('/api/vagas', (req, res) => {
  ok(res, db.prepare('SELECT * FROM vagas ORDER BY setor, numero').all());
});

app.get('/api/vagas/livres', (req, res) => {
  const tipo = req.query.tipo;
  let query = `SELECT * FROM vagas WHERE status = 'livre'`;
  if (tipo) query += ` AND tipo = ?`;
  query += ` ORDER BY setor, numero`;
  ok(res, tipo ? db.prepare(query).all(tipo) : db.prepare(query).all());
});

app.post('/api/vagas', (req, res) => {
  const { numero, tipo, setor } = req.body;
  if (!numero) return fail(res, 'Número da vaga é obrigatório');
  try {
    const result = db.prepare(`
      INSERT INTO vagas (numero, tipo, status, setor)
      VALUES (?, ?, 'livre', ?)
    `).run(
      numero.trim().toUpperCase(),
      ['preferencial', 'moto', 'carga'].includes(tipo) ? tipo : 'normal',
      setor?.trim() || 'A'
    );
    ok(res, db.prepare('SELECT * FROM vagas WHERE id = ?').get(result.lastInsertRowid), 201);
  } catch (err) {
    if (err.message.includes('UNIQUE')) return fail(res, 'Já existe vaga com esse número');
    fail(res, err.message);
  }
});

app.put('/api/vagas/:id/status', (req, res) => {
  const { status } = req.body;
  if (!['livre', 'ocupada', 'reservada', 'bloqueada'].includes(status)) {
    return fail(res, 'Status inválido');
  }
  const result = db.prepare('UPDATE vagas SET status = ? WHERE id = ?').run(status, req.params.id);
  if (result.changes === 0) return fail(res, 'Vaga não encontrada', 404);
  ok(res, { mensagem: 'Status atualizado' });
});

// ============================================
// PREÇOS (hora, diária, mensal, anual)
// ============================================
app.get('/api/precos', (req, res) => {
  ok(res, db.prepare(`
    SELECT * FROM precos WHERE ativo = 1
    ORDER BY tipo_cobranca, tipo_veiculo
  `).all());
});

app.post('/api/precos', (req, res) => {
  const { descricao, tipo_cobranca, valor, tipo_veiculo } = req.body;
  if (!descricao || !tipo_cobranca || valor == null) {
    return fail(res, 'Campos obrigatórios: descricao, tipo_cobranca, valor');
  }
  if (!['hora', 'diaria', 'mensal', 'anual'].includes(tipo_cobranca)) {
    return fail(res, 'tipo_cobranca inválido (hora, diaria, mensal, anual)');
  }
  const result = db.prepare(`
    INSERT INTO precos (descricao, tipo_cobranca, valor, tipo_veiculo)
    VALUES (?, ?, ?, ?)
  `).run(descricao, tipo_cobranca, Number(valor), tipo_veiculo || 'todos');
  ok(res, db.prepare('SELECT * FROM precos WHERE id = ?').get(result.lastInsertRowid), 201);
});

app.put('/api/precos/:id', (req, res) => {
  const { descricao, valor, tipo_veiculo, ativo } = req.body;
  const result = db.prepare(`
    UPDATE precos SET descricao = COALESCE(?, descricao),
                      valor = COALESCE(?, valor),
                      tipo_veiculo = COALESCE(?, tipo_veiculo),
                      ativo = COALESCE(?, ativo)
    WHERE id = ?
  `).run(descricao, valor != null ? Number(valor) : null, tipo_veiculo, ativo, req.params.id);
  if (result.changes === 0) return fail(res, 'Preço não encontrado', 404);
  ok(res, db.prepare('SELECT * FROM precos WHERE id = ?').get(req.params.id));
});

app.delete('/api/precos/:id', (req, res) => {
  // Soft delete
  const result = db.prepare('UPDATE precos SET ativo = 0 WHERE id = ?').run(req.params.id);
  if (result.changes === 0) return fail(res, 'Preço não encontrado', 404);
  ok(res, { mensagem: 'Preço desativado' });
});

// ============================================
// ESTACIONAMENTO
// ============================================
app.get('/api/estacionamentos/ativos', (req, res) => {
  ok(res, db.prepare(`
    SELECT e.*,
           v.placa, v.marca, v.modelo, v.cor, v.tipo as tipo_veiculo,
           vg.numero as vaga_numero, vg.tipo as vaga_tipo, vg.setor,
           c.nome as cliente_nome, c.plano as cliente_plano, c.plano_validade as cliente_plano_validade
    FROM estacionamentos e
    JOIN veiculos v ON e.veiculo_id = v.id
    JOIN vagas vg ON e.vaga_id = vg.id
    LEFT JOIN clientes c ON v.cliente_id = c.id
    WHERE e.status = 'ativo'
    ORDER BY e.data_hora_entrada DESC
  `).all());
});

// Prévia do valor (antes de confirmar saída)
app.get('/api/estacionamentos/previa/:id', (req, res) => {
  const est = db.prepare(`
    SELECT e.*, v.tipo as tipo_veiculo, v.placa, c.plano as cliente_plano, c.plano_validade as cliente_plano_validade
    FROM estacionamentos e
    JOIN veiculos v ON e.veiculo_id = v.id
    LEFT JOIN clientes c ON v.cliente_id = c.id
    WHERE e.id = ? AND e.status = 'ativo'
  `).get(req.params.id);
  if (!est) return fail(res, 'Estacionamento ativo não encontrado', 404);

  const plano = est.cliente_plano || 'avulso';
  const validade = est.cliente_plano_validade || null;
  const planoOk = (plano === 'mensal' || plano === 'anual') && planoAindaValido(validade);
  const opcoes = sugerirCobranca(est.data_hora_entrada, est.tipo_veiculo);

  ok(res, {
    placa: est.placa,
    entrada: est.data_hora_entrada,
    plano_cliente: plano,
    plano_validade: validade,
    plano_valido: planoOk,
    opcoes: {
      hora: opcoes.porHora,
      diaria: opcoes.porDiaria
    },
    sugestao: planoOk ? plano : opcoes.sugestao
  });
});

app.post('/api/estacionamentos/entrada', (req, res) => {
  const { placa, vaga_id, observacao } = req.body;
  if (!placa || !vaga_id) return fail(res, 'Placa e vaga são obrigatórios');

  const placaLimpa = placa.replace(/[^A-Za-z0-9]/g, '').toUpperCase();
  if (!validarPlaca(placaLimpa)) return fail(res, 'Placa inválida');

  const veiculo = db.prepare('SELECT * FROM veiculos WHERE UPPER(placa) = ?').get(placaLimpa);
  if (!veiculo) return fail(res, 'Veículo não cadastrado. Cadastre o veículo primeiro.', 404);

  const ja = db.prepare(`SELECT id FROM estacionamentos WHERE veiculo_id = ? AND status = 'ativo'`).get(veiculo.id);
  if (ja) return fail(res, 'Este veículo já está estacionado');

  const vaga = db.prepare('SELECT * FROM vagas WHERE id = ?').get(vaga_id);
  if (!vaga) return fail(res, 'Vaga não encontrada', 404);
  if (vaga.status !== 'livre') return fail(res, 'Vaga não está disponível');

  try {
    const id = db.transaction(() => {
      const result = db.prepare(`
        INSERT INTO estacionamentos (veiculo_id, vaga_id, observacao)
        VALUES (?, ?, ?)
      `).run(veiculo.id, vaga_id, observacao?.trim() || null);
      db.prepare(`UPDATE vagas SET status = 'ocupada' WHERE id = ?`).run(vaga_id);
      return result.lastInsertRowid;
    })();

    const registro = db.prepare(`
      SELECT e.*, v.placa, vg.numero as vaga_numero, vg.tipo as vaga_tipo
      FROM estacionamentos e
      JOIN veiculos v ON e.veiculo_id = v.id
      JOIN vagas vg ON e.vaga_id = vg.id
      WHERE e.id = ?
    `).get(id);
    ok(res, registro, 201);
  } catch (err) {
    fail(res, err.message, 500);
  }
});

app.post('/api/estacionamentos/saida/:id', (req, res) => {
  const tipoCobrancaReq = req.body?.tipo_cobranca; // 'hora' | 'diaria' | auto

  const est = db.prepare(`
    SELECT e.*, v.tipo as tipo_veiculo, v.placa, c.plano as cliente_plano, c.plano_validade as cliente_plano_validade
    FROM estacionamentos e
    JOIN veiculos v ON e.veiculo_id = v.id
    LEFT JOIN clientes c ON v.cliente_id = c.id
    WHERE e.id = ? AND e.status = 'ativo'
  `).get(req.params.id);

  if (!est) return fail(res, 'Estacionamento ativo não encontrado', 404);

  const plano = est.cliente_plano || 'avulso';
  const validade = est.cliente_plano_validade || null;
  const planoOk = (plano === 'mensal' || plano === 'anual') && planoAindaValido(validade);
  let tipoFinal = tipoCobrancaReq || 'hora';

  if (planoOk) {
    tipoFinal = plano;
  } else if (!tipoCobrancaReq || tipoCobrancaReq === 'auto') {
    const s = sugerirCobranca(est.data_hora_entrada, est.tipo_veiculo);
    tipoFinal = s.sugestao;
  }

  const calc = calcularValor(est.data_hora_entrada, est.tipo_veiculo, tipoFinal, plano, validade);

  try {
    db.transaction(() => {
      db.prepare(`
        UPDATE estacionamentos
        SET data_hora_saida = CURRENT_TIMESTAMP,
            valor_calculado = ?,
            tipo_cobranca = ?,
            status = 'finalizado'
        WHERE id = ?
      `).run(calc.valor, calc.tipo_cobranca, req.params.id);
      db.prepare(`UPDATE vagas SET status = 'livre' WHERE id = ?`).run(est.vaga_id);
    })();

    const resultado = db.prepare(`
      SELECT e.*, v.placa, vg.numero as vaga_numero
      FROM estacionamentos e
      JOIN veiculos v ON e.veiculo_id = v.id
      JOIN vagas vg ON e.vaga_id = vg.id
      WHERE e.id = ?
    `).get(req.params.id);

    ok(res, { ...resultado, ...calc });
  } catch (err) {
    fail(res, err.message, 500);
  }
});

app.get('/api/estacionamentos/historico', (req, res) => {
  ok(res, db.prepare(`
    SELECT e.*, v.placa, v.marca, v.modelo, vg.numero as vaga_numero
    FROM estacionamentos e
    JOIN veiculos v ON e.veiculo_id = v.id
    JOIN vagas vg ON e.vaga_id = vg.id
    WHERE e.status = 'finalizado'
    ORDER BY e.data_hora_saida DESC
    LIMIT 100
  `).all());
});

// ============================================
// PAGAMENTOS DE PLANO
// ============================================
app.get('/api/pagamentos-plano', (req, res) => {
  ok(res, db.prepare(`
    SELECT p.*, c.nome as cliente_nome
    FROM pagamentos_plano p
    JOIN clientes c ON p.cliente_id = c.id
    ORDER BY p.data_pagamento DESC
    LIMIT 100
  `).all());
});

app.post('/api/pagamentos-plano/renovar/:clienteId', (req, res) => {
  const cliente = db.prepare('SELECT * FROM clientes WHERE id = ?').get(req.params.clienteId);
  if (!cliente) return fail(res, 'Cliente não encontrado', 404);
  if (cliente.plano !== 'mensal' && cliente.plano !== 'anual') {
    return fail(res, 'Cliente não possui plano mensal ou anual');
  }

  const valor = buscarPreco(cliente.plano, 'carro') ?? buscarPreco(cliente.plano, 'todos');
  if (valor == null) return fail(res, `Preço de plano ${cliente.plano} não cadastrado`);

  const hoje = new Date();
  const inicio = hoje.toISOString().slice(0, 10);
  const fim = new Date(hoje);
  if (cliente.plano === 'mensal') fim.setMonth(fim.getMonth() + 1);
  else fim.setFullYear(fim.getFullYear() + 1);
  const validade = fim.toISOString().slice(0, 10);

  db.transaction(() => {
    db.prepare(`
      INSERT INTO pagamentos_plano (cliente_id, tipo_plano, valor, validade_inicio, validade_fim, observacao)
      VALUES (?, ?, ?, ?, ?, ?)
    `).run(cliente.id, cliente.plano, valor, inicio, validade, 'Renovação de plano');
    db.prepare(`UPDATE clientes SET plano_inicio = ?, plano_validade = ? WHERE id = ?`)
      .run(inicio, validade, cliente.id);
  })();

  ok(res, {
    mensagem: `Plano ${cliente.plano} renovado`,
    valor,
    validade
  });
});

// ============================================
// RELATÓRIOS
// ============================================
app.get('/api/relatorios/ocupacao', (req, res) => {
  const total = db.prepare(`SELECT COUNT(*) as total FROM vagas`).get().total;
  const livres = db.prepare(`SELECT COUNT(*) as total FROM vagas WHERE status = 'livre'`).get().total;
  const ocupadas = db.prepare(`SELECT COUNT(*) as total FROM vagas WHERE status = 'ocupada'`).get().total;
  const bloqueadas = db.prepare(`SELECT COUNT(*) as total FROM vagas WHERE status = 'bloqueada'`).get().total;
  const porTipo = db.prepare(`
    SELECT tipo, status, COUNT(*) as quantidade FROM vagas
    GROUP BY tipo, status ORDER BY tipo, status
  `).all();

  ok(res, {
    total_vagas: total,
    livres,
    ocupadas,
    bloqueadas,
    percentual_ocupacao: total > 0 ? Number(((ocupadas / total) * 100).toFixed(1)) : 0,
    detalhe: porTipo
  });
});

app.get('/api/relatorios/faturamento', (req, res) => {
  const hoje = db.prepare(`
    SELECT COALESCE(SUM(valor_calculado),0) as total, COUNT(*) as quantidade
    FROM estacionamentos
    WHERE status='finalizado' AND date(data_hora_saida)=date('now')
  `).get();

  const mes = db.prepare(`
    SELECT COALESCE(SUM(valor_calculado),0) as total, COUNT(*) as quantidade
    FROM estacionamentos
    WHERE status='finalizado' AND strftime('%Y-%m', data_hora_saida)=strftime('%Y-%m','now')
  `).get();

  const planosHoje = db.prepare(`
    SELECT COALESCE(SUM(valor),0) as total, COUNT(*) as quantidade
    FROM pagamentos_plano WHERE date(data_pagamento)=date('now')
  `).get();

  const planosMes = db.prepare(`
    SELECT COALESCE(SUM(valor),0) as total, COUNT(*) as quantidade
    FROM pagamentos_plano WHERE strftime('%Y-%m', data_pagamento)=strftime('%Y-%m','now')
  `).get();

  const porTipo = db.prepare(`
    SELECT COALESCE(tipo_cobranca,'hora') as tipo_cobranca,
           COUNT(*) as quantidade,
           COALESCE(SUM(valor_calculado),0) as total
    FROM estacionamentos
    WHERE status='finalizado' AND strftime('%Y-%m', data_hora_saida)=strftime('%Y-%m','now')
    GROUP BY tipo_cobranca
  `).all();

  ok(res, {
    faturamento_hoje: hoje.total + planosHoje.total,
    qtd_hoje: hoje.quantidade,
    planos_hoje: planosHoje.total,
    faturamento_mes: mes.total + planosMes.total,
    qtd_mes: mes.quantidade,
    planos_mes: planosMes.total,
    por_tipo_cobranca: porTipo
  });
});

app.get('/api/relatorios/completo', (req, res) => {
  const ocupacao = {
    total: db.prepare(`SELECT COUNT(*) as t FROM vagas`).get().t,
    livres: db.prepare(`SELECT COUNT(*) as t FROM vagas WHERE status='livre'`).get().t,
    ocupadas: db.prepare(`SELECT COUNT(*) as t FROM vagas WHERE status='ocupada'`).get().t
  };

  const faturamento = {
    hoje: db.prepare(`SELECT COALESCE(SUM(valor_calculado),0) as t FROM estacionamentos WHERE status='finalizado' AND date(data_hora_saida)=date('now')`).get().t,
    mes: db.prepare(`SELECT COALESCE(SUM(valor_calculado),0) as t FROM estacionamentos WHERE status='finalizado' AND strftime('%Y-%m',data_hora_saida)=strftime('%Y-%m','now')`).get().t,
    total: db.prepare(`SELECT COALESCE(SUM(valor_calculado),0) as t FROM estacionamentos WHERE status='finalizado'`).get().t
  };

  const tempoMedio = db.prepare(`
    SELECT AVG(
      (julianday(data_hora_saida) - julianday(data_hora_entrada)) * 24 * 60
    ) as minutos
    FROM estacionamentos WHERE status='finalizado' AND data_hora_saida IS NOT NULL
  `).get().minutos;

  const rankingPlacas = db.prepare(`
    SELECT v.placa, v.marca, v.modelo, COUNT(*) as visitas,
           COALESCE(SUM(e.valor_calculado),0) as total_pago
    FROM estacionamentos e
    JOIN veiculos v ON e.veiculo_id = v.id
    WHERE e.status = 'finalizado'
    GROUP BY v.id
    ORDER BY visitas DESC
    LIMIT 10
  `).all();

  const vagasMaisUsadas = db.prepare(`
    SELECT vg.numero, vg.tipo, COUNT(*) as usos
    FROM estacionamentos e
    JOIN vagas vg ON e.vaga_id = vg.id
    WHERE e.status = 'finalizado'
    GROUP BY vg.id
    ORDER BY usos DESC
    LIMIT 10
  `).all();

  const porDia = db.prepare(`
    SELECT date(data_hora_saida) as dia,
           COUNT(*) as quantidade,
           COALESCE(SUM(valor_calculado),0) as total
    FROM estacionamentos
    WHERE status='finalizado' AND data_hora_saida >= date('now','-7 days')
    GROUP BY date(data_hora_saida)
    ORDER BY dia DESC
  `).all();

  const clientes = {
    total: db.prepare(`SELECT COUNT(*) as t FROM clientes`).get().t,
    mensalistas: db.prepare(`SELECT COUNT(*) as t FROM clientes WHERE plano='mensal'`).get().t,
    anuais: db.prepare(`SELECT COUNT(*) as t FROM clientes WHERE plano='anual'`).get().t
  };

  const veiculos = {
    total: db.prepare(`SELECT COUNT(*) as t FROM veiculos`).get().t,
    por_tipo: db.prepare(`SELECT tipo, COUNT(*) as qtd FROM veiculos GROUP BY tipo`).all()
  };

  ok(res, {
    ocupacao,
    faturamento,
    tempo_medio_minutos: tempoMedio ? Math.round(tempoMedio) : 0,
    ranking_placas: rankingPlacas,
    vagas_mais_usadas: vagasMaisUsadas,
    ultimos_7_dias: porDia,
    clientes,
    veiculos
  });
});

// ============================================
app.get('/', (req, res) => {
  res.sendFile(path.join(__dirname, '../frontend/index.html'));
});

app.use((req, res) => fail(res, 'Rota não encontrada', 404));

app.listen(PORT, () => {
  console.log(`\n  🚀  Sistema de Estacionamento`);
  console.log(`  ➜  Local:   http://localhost:${PORT}`);
  console.log(`  ➜  Banco:   backend/estacionamento.db\n`);
});
