const API = 'http://localhost:3000/api';

const TITULOS = {
  dashboard: 'Dashboard',
  entrada: 'Entrada de Veículo',
  saida: 'Saída de Veículo',
  vagas: 'Mapa de Vagas',
  veiculos: 'Veículos',
  clientes: 'Clientes',
  precos: 'Tabela de Preços',
  relatorios: 'Relatórios',
  historico: 'Histórico'
};

let saidaAtualId = null;
let saidaPrevia = null;

function toast(msg, tipo = 'success') {
  const el = document.getElementById('toast');
  el.textContent = msg;
  el.className = `toast ${tipo} show`;
  setTimeout(() => el.classList.remove('show'), 3500);
}

async function api(path, options = {}) {
  const res = await fetch(`${API}${path}`, {
    headers: { 'Content-Type': 'application/json', ...options.headers },
    ...options
  });
  const json = await res.json();
  if (!json.success) throw new Error(json.error || 'Erro desconhecido');
  return json.data;
}

function formatarData(str) {
  if (!str) return '—';
  return new Date(str).toLocaleString('pt-BR', {
    day: '2-digit', month: '2-digit', year: 'numeric',
    hour: '2-digit', minute: '2-digit'
  });
}

function formatarMoeda(v) {
  return 'R$ ' + Number(v || 0).toFixed(2).replace('.', ',');
}

function atualizarRelogio() {
  document.getElementById('clock').textContent = new Date().toLocaleString('pt-BR', {
    weekday: 'short', day: '2-digit', month: 'short',
    hour: '2-digit', minute: '2-digit', second: '2-digit'
  });
}
setInterval(atualizarRelogio, 1000);
atualizarRelogio();

document.querySelectorAll('.nav-item').forEach(btn => {
  btn.addEventListener('click', () => {
    document.querySelectorAll('.nav-item').forEach(b => b.classList.remove('active'));
    document.querySelectorAll('.page').forEach(p => p.classList.remove('active'));
    btn.classList.add('active');
    const page = btn.dataset.page;
    document.getElementById(page).classList.add('active');
    document.getElementById('page-title').textContent = TITULOS[page] || page;
    if (page === 'dashboard') carregarDashboard();
    if (page === 'entrada') carregarVagasLivres();
    if (page === 'saida') carregarAtivosParaSaida();
    if (page === 'vagas') carregarVagas();
    if (page === 'veiculos') carregarVeiculos();
    if (page === 'clientes') carregarClientes();
    if (page === 'precos') carregarPrecos();
    if (page === 'relatorios') carregarRelatorios();
    if (page === 'historico') carregarHistorico();
  });
});

async function carregarDashboard() {
  try {
    const [ocupacao, faturamento, ativos] = await Promise.all([
      api('/relatorios/ocupacao'),
      api('/relatorios/faturamento'),
      api('/estacionamentos/ativos')
    ]);
    document.getElementById('qtd-livres').textContent = ocupacao.livres;
    document.getElementById('qtd-ocupadas').textContent = ocupacao.ocupadas;
    document.getElementById('percentual').textContent = ocupacao.percentual_ocupacao + '%';
    document.getElementById('faturamento-hoje').textContent = formatarMoeda(faturamento.faturamento_hoje);
    document.getElementById('badge-ativos').textContent = ativos.length + ' ativos';
    const tbody = document.getElementById('tbody-ativos');
    if (!ativos.length) {
      tbody.innerHTML = '<tr><td colspan="5" class="empty">Nenhum veículo no pátio</td></tr>';
      return;
    }
    tbody.innerHTML = ativos.map(e => `
      <tr>
        <td><span class="placa">${e.placa}</span></td>
        <td>${[e.marca, e.modelo].filter(Boolean).join(' ') || '—'} ${e.cor ? '<span style="color:#94a3b8">(' + e.cor + ')</span>' : ''}</td>
        <td>${e.vaga_numero} <span style="color:#94a3b8;font-size:12px">${e.vaga_tipo}</span></td>
        <td>${formatarData(e.data_hora_entrada)}</td>
        <td>${e.cliente_nome || '—'} ${e.cliente_plano && e.cliente_plano !== 'avulso' ? '<span class="badge">' + e.cliente_plano + '</span>' : ''}</td>
      </tr>
    `).join('');
  } catch (err) { toast(err.message, 'error'); }
}

async function carregarVagasLivres() {
  const select = document.getElementById('entrada-vaga');
  select.innerHTML = '<option value="">Carregando...</option>';
  try {
    const vagas = await api('/vagas/livres');
    if (!vagas.length) { select.innerHTML = '<option value="">Nenhuma vaga livre</option>'; return; }
    select.innerHTML = '<option value="">Selecione a vaga...</option>' +
      vagas.map(v => '<option value="' + v.id + '">' + v.numero + ' — ' + v.tipo + ' (Setor ' + v.setor + ')</option>').join('');
  } catch { select.innerHTML = '<option value="">Erro ao carregar</option>'; }
}

document.getElementById('form-entrada').addEventListener('submit', async (e) => {
  e.preventDefault();
  const btn = e.target.querySelector('[type=submit]');
  btn.disabled = true; btn.textContent = 'Registrando...';
  try {
    const data = await api('/estacionamentos/entrada', {
      method: 'POST',
      body: JSON.stringify({
        placa: document.getElementById('entrada-placa').value.trim(),
        vaga_id: Number(document.getElementById('entrada-vaga').value),
        observacao: document.getElementById('entrada-obs').value.trim()
      })
    });
    toast('Entrada: ' + data.placa + ' → vaga ' + data.vaga_numero);
    e.target.reset();
    carregarVagasLivres();
  } catch (err) { toast(err.message, 'error'); }
  finally { btn.disabled = false; btn.textContent = 'Confirmar Entrada'; }
});

async function carregarAtivosParaSaida() {
  const tbody = document.getElementById('tbody-saida');
  tbody.innerHTML = '<tr><td colspan="6" class="empty">Carregando...</td></tr>';
  try {
    const ativos = await api('/estacionamentos/ativos');
    document.getElementById('badge-saida').textContent = ativos.length + ' veículos';
    if (!ativos.length) {
      tbody.innerHTML = '<tr><td colspan="6" class="empty">Nenhum veículo para saída</td></tr>';
      return;
    }
    tbody.innerHTML = ativos.map(e => `
      <tr>
        <td><span class="placa">${e.placa}</span></td>
        <td>${[e.marca, e.modelo].filter(Boolean).join(' ') || '—'}</td>
        <td>${e.vaga_numero}</td>
        <td>${formatarData(e.data_hora_entrada)}</td>
        <td>${e.cliente_plano && e.cliente_plano !== 'avulso' ? '<span class="badge">' + e.cliente_plano + '</span>' : 'avulso'}</td>
        <td><button class="btn btn-success" onclick="abrirSaida(${e.id})">Finalizar</button></td>
      </tr>
    `).join('');
  } catch { tbody.innerHTML = '<tr><td colspan="6" class="empty">Erro ao carregar</td></tr>'; }
}

async function abrirSaida(id) {
  saidaAtualId = id;
  try {
    saidaPrevia = await api('/estacionamentos/previa/' + id);
    let info = '<strong>' + saidaPrevia.placa + '</strong> — entrada em ' + formatarData(saidaPrevia.entrada);
    if (saidaPrevia.plano_valido) {
      info += '<br><span style="color:#059669">Cliente com plano <strong>' + saidaPrevia.plano_cliente + '</strong> válido até ' + (saidaPrevia.plano_validade || '—') + ' — sem cobrança</span>';
    } else if (saidaPrevia.plano_cliente !== 'avulso') {
      info += '<br><span style="color:#dc2626">Plano ' + saidaPrevia.plano_cliente + ' vencido — cobrança normal</span>';
    }
    document.getElementById('saida-info').innerHTML = info;
    const sel = document.getElementById('saida-tipo');
    if (saidaPrevia.plano_valido) {
      sel.innerHTML = '<option value="' + saidaPrevia.plano_cliente + '">Plano ' + saidaPrevia.plano_cliente + ' válido (R$ 0)</option>';
      sel.disabled = true;
    } else {
      sel.disabled = false;
      sel.innerHTML =
        '<option value="auto">Automático (melhor preço)</option>' +
        '<option value="hora">Por hora — ' + formatarMoeda(saidaPrevia.opcoes.hora.valor) + '</option>' +
        '<option value="diaria">Diária — ' + formatarMoeda(saidaPrevia.opcoes.diaria.valor) + '</option>';
    }
    atualizarPreviaSaida();
    document.getElementById('modal-saida').classList.add('open');
  } catch (err) { toast(err.message, 'error'); }
}

function atualizarPreviaSaida() {
  if (!saidaPrevia) return;
  const tipo = document.getElementById('saida-tipo').value;
  let texto = '';
  if (saidaPrevia.plano_valido) {
    texto = 'Valor a pagar: <strong>R$ 0,00</strong> (plano ' + saidaPrevia.plano_cliente + ' válido)';
  } else if (tipo === 'hora') {
    texto = 'Por hora: <strong>' + formatarMoeda(saidaPrevia.opcoes.hora.valor) + '</strong><br><small>' + saidaPrevia.opcoes.hora.detalhe + '</small>';
  } else if (tipo === 'diaria') {
    texto = 'Diária: <strong>' + formatarMoeda(saidaPrevia.opcoes.diaria.valor) + '</strong>';
  } else {
    const s = saidaPrevia.sugestao;
    const v = saidaPrevia.opcoes[s];
    texto = 'Sugestão: <strong>' + s + '</strong> — ' + formatarMoeda(v.valor) +
      '<br><small>Hora: ' + formatarMoeda(saidaPrevia.opcoes.hora.valor) + ' | Diária: ' + formatarMoeda(saidaPrevia.opcoes.diaria.valor) + '</small>';
  }
  document.getElementById('saida-previa').innerHTML = texto;
}

document.getElementById('saida-tipo').addEventListener('change', atualizarPreviaSaida);

document.getElementById('btn-confirmar-saida').addEventListener('click', async () => {
  if (!saidaAtualId) return;
  try {
    const tipo = document.getElementById('saida-tipo').value;
    const data = await api('/estacionamentos/saida/' + saidaAtualId, {
      method: 'POST',
      body: JSON.stringify({ tipo_cobranca: tipo })
    });
    toast('Saída OK — ' + data.placa + ' | ' + data.tipo_cobranca + ' | ' + formatarMoeda(data.valor));
    fecharModal('modal-saida');
    carregarAtivosParaSaida();
  } catch (err) { toast(err.message, 'error'); }
});

let todasVagas = [];
async function carregarVagas() {
  try { todasVagas = await api('/vagas'); renderVagas('todos'); }
  catch (err) { toast(err.message, 'error'); }
}
function renderVagas(filtro) {
  let lista = todasVagas;
  if (filtro === 'livre') lista = todasVagas.filter(v => v.status === 'livre');
  if (filtro === 'ocupada') lista = todasVagas.filter(v => v.status === 'ocupada');
  if (filtro === 'preferencial') lista = todasVagas.filter(v => v.tipo === 'preferencial');
  document.getElementById('grid-vagas').innerHTML = lista.map(v =>
    '<div class="vaga ' + v.status + (v.tipo === 'preferencial' ? ' preferencial' : '') + '">' +
    '<span class="vaga-num">' + v.numero + '</span>' +
    '<span class="vaga-tipo">' + v.tipo + '</span></div>'
  ).join('');
}
document.querySelectorAll('.chip').forEach(btn => {
  btn.addEventListener('click', () => {
    document.querySelectorAll('.chip').forEach(b => b.classList.remove('active'));
    btn.classList.add('active');
    renderVagas(btn.dataset.filtro);
  });
});

async function carregarVeiculos() {
  try {
    const [veiculos, clientes] = await Promise.all([api('/veiculos'), api('/clientes')]);
    const tbody = document.getElementById('tbody-veiculos');
    tbody.innerHTML = veiculos.length ? veiculos.map(v => `
      <tr>
        <td><span class="placa">${v.placa}</span></td>
        <td>${[v.marca, v.modelo].filter(Boolean).join(' ') || '—'}</td>
        <td>${v.cor || '—'}</td>
        <td>${v.ano || '—'}</td>
        <td>${v.tipo}</td>
        <td>${v.tamanho || '—'}</td>
        <td>${v.cliente_nome || '—'}</td>
      </tr>
    `).join('') : '<tr><td colspan="7" class="empty">Nenhum veículo</td></tr>';
    document.getElementById('vei-cliente').innerHTML =
      '<option value="">Sem vínculo</option>' +
      clientes.map(c => '<option value="' + c.id + '">' + c.nome + '</option>').join('');
  } catch (err) { toast(err.message, 'error'); }
}
function abrirModalVeiculo() {
  document.getElementById('form-veiculo').reset();
  document.getElementById('modal-veiculo').classList.add('open');
}
document.getElementById('form-veiculo').addEventListener('submit', async (e) => {
  e.preventDefault();
  try {
    await api('/veiculos', {
      method: 'POST',
      body: JSON.stringify({
        placa: document.getElementById('vei-placa').value.trim(),
        marca: document.getElementById('vei-marca').value.trim(),
        modelo: document.getElementById('vei-modelo').value.trim(),
        cor: document.getElementById('vei-cor').value.trim(),
        ano: document.getElementById('vei-ano').value || null,
        tipo: document.getElementById('vei-tipo').value,
        tamanho: document.getElementById('vei-tamanho').value,
        cliente_id: document.getElementById('vei-cliente').value || null
      })
    });
    toast('Veículo cadastrado');
    fecharModal('modal-veiculo');
    carregarVeiculos();
  } catch (err) { toast(err.message, 'error'); }
});

async function carregarClientes() {
  try {
    const clientes = await api('/clientes');
    document.getElementById('tbody-clientes').innerHTML = clientes.length ? clientes.map(c => `
      <tr>
        <td><strong>${c.nome}</strong></td>
        <td>${c.cpf_cnpj || '—'}</td>
        <td>${c.telefone || '—'}</td>
        <td>${c.email || '—'}</td>
        <td>${c.tipo}</td>
        <td><span class="badge">${c.plano || 'avulso'}</span>${c.plano_validade ? '<br><small style="color:#64748b">até ' + c.plano_validade + '</small>' : ''}</td>
      </tr>
    `).join('') : '<tr><td colspan="6" class="empty">Nenhum cliente</td></tr>';
  } catch (err) { toast(err.message, 'error'); }
}
function abrirModalCliente() {
  document.getElementById('form-cliente').reset();
  document.getElementById('modal-cliente').classList.add('open');
}
document.getElementById('form-cliente').addEventListener('submit', async (e) => {
  e.preventDefault();
  try {
    const data = await api('/clientes', {
      method: 'POST',
      body: JSON.stringify({
        nome: document.getElementById('cli-nome').value.trim(),
        cpf_cnpj: document.getElementById('cli-cpf').value.trim(),
        telefone: document.getElementById('cli-telefone').value.trim(),
        email: document.getElementById('cli-email').value.trim(),
        tipo: document.getElementById('cli-tipo').value,
        plano: document.getElementById('cli-plano').value
      })
    });
    if (data.pagamento_plano) {
      toast(data.pagamento_plano.mensagem);
    } else {
      toast('Cliente cadastrado (avulso)');
    }
    fecharModal('modal-cliente');
    carregarClientes();
  } catch (err) { toast(err.message, 'error'); }
});

async function carregarPrecos() {
  try {
    const precos = await api('/precos');
    document.getElementById('tbody-precos').innerHTML = precos.length ? precos.map(p => `
      <tr>
        <td>${p.descricao}</td>
        <td><span class="badge">${p.tipo_cobranca}</span></td>
        <td>${p.tipo_veiculo}</td>
        <td><strong>${formatarMoeda(p.valor)}</strong></td>
        <td><button class="btn btn-ghost btn-sm" onclick="desativarPreco(${p.id})">Desativar</button></td>
      </tr>
    `).join('') : '<tr><td colspan="5" class="empty">Nenhum preço</td></tr>';
  } catch (err) { toast(err.message, 'error'); }
}
function abrirModalPreco() {
  document.getElementById('form-preco').reset();
  document.getElementById('modal-preco').classList.add('open');
}
document.getElementById('form-preco').addEventListener('submit', async (e) => {
  e.preventDefault();
  try {
    await api('/precos', {
      method: 'POST',
      body: JSON.stringify({
        descricao: document.getElementById('pre-desc').value.trim(),
        tipo_cobranca: document.getElementById('pre-tipo').value,
        tipo_veiculo: document.getElementById('pre-veiculo').value,
        valor: Number(document.getElementById('pre-valor').value)
      })
    });
    toast('Preço cadastrado');
    fecharModal('modal-preco');
    carregarPrecos();
  } catch (err) { toast(err.message, 'error'); }
});
async function desativarPreco(id) {
  if (!confirm('Desativar este preço?')) return;
  try {
    await api('/precos/' + id, { method: 'DELETE' });
    toast('Preço desativado');
    carregarPrecos();
  } catch (err) { toast(err.message, 'error'); }
}

async function carregarRelatorios() {
  try {
    const r = await api('/relatorios/completo');
    document.getElementById('rel-stats').innerHTML =
      '<div class="stat-card"><div class="stat-label">Faturamento hoje</div><div class="stat-value text-primary">' + formatarMoeda(r.faturamento.hoje) + '</div></div>' +
      '<div class="stat-card"><div class="stat-label">Faturamento mês</div><div class="stat-value text-primary">' + formatarMoeda(r.faturamento.mes) + '</div></div>' +
      '<div class="stat-card"><div class="stat-label">Tempo médio</div><div class="stat-value">' + r.tempo_medio_minutos + ' min</div></div>' +
      '<div class="stat-card"><div class="stat-label">Ocupação</div><div class="stat-value">' + r.ocupacao.ocupadas + '/' + r.ocupacao.total + '</div></div>';
    document.getElementById('tbody-7dias').innerHTML = r.ultimos_7_dias.length
      ? r.ultimos_7_dias.map(d => '<tr><td>' + d.dia + '</td><td>' + d.quantidade + '</td><td>' + formatarMoeda(d.total) + '</td></tr>').join('')
      : '<tr><td colspan="3" class="empty">Sem dados</td></tr>';
    document.getElementById('tbody-ranking').innerHTML = r.ranking_placas.length
      ? r.ranking_placas.map(p => '<tr><td><span class="placa">' + p.placa + '</span></td><td>' + p.visitas + '</td><td>' + formatarMoeda(p.total_pago) + '</td></tr>').join('')
      : '<tr><td colspan="3" class="empty">Sem dados</td></tr>';
    document.getElementById('tbody-vagas-uso').innerHTML = r.vagas_mais_usadas.length
      ? r.vagas_mais_usadas.map(v => '<tr><td>' + v.numero + '</td><td>' + v.tipo + '</td><td>' + v.usos + '</td></tr>').join('')
      : '<tr><td colspan="3" class="empty">Sem dados</td></tr>';
  } catch (err) { toast(err.message, 'error'); }
}

async function carregarHistorico() {
  try {
    const historico = await api('/estacionamentos/historico');
    document.getElementById('tbody-historico').innerHTML = historico.length ? historico.map(e => `
      <tr>
        <td><span class="placa">${e.placa}</span></td>
        <td>${[e.marca, e.modelo].filter(Boolean).join(' ') || '—'}</td>
        <td>${e.vaga_numero}</td>
        <td>${formatarData(e.data_hora_entrada)}</td>
        <td>${formatarData(e.data_hora_saida)}</td>
        <td><span class="badge">${e.tipo_cobranca || 'hora'}</span></td>
        <td><strong>${formatarMoeda(e.valor_calculado)}</strong></td>
      </tr>
    `).join('') : '<tr><td colspan="7" class="empty">Nenhum registro</td></tr>';
  } catch (err) { toast(err.message, 'error'); }
}

function fecharModal(id) { document.getElementById(id).classList.remove('open'); }
document.querySelectorAll('.modal').forEach(m => {
  m.addEventListener('click', e => { if (e.target === m) m.classList.remove('open'); });
});

carregarDashboard();
